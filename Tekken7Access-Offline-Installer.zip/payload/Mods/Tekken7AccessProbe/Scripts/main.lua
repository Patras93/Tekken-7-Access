print("[Tekken7AccessProbe] GFx command listener loaded")

local access_modules = {
    Core = true, MainMenu = true, Offline = true, Online = true,
    Story = true, Options = true, Dialogs = true, Practice = true,
    CharacterSelect = true, StageSelect = true, Customization = true
}
pcall(function()
    local configured = dofile("Mods/Tekken7AccessProbe/Modules/module-settings.lua")
    if type(configured) == "table" then access_modules = configured end
end)
local function module_enabled(name)
    return access_modules.Core ~= false and access_modules[name] ~= false
end
local tekken_ui_manifest = {}
pcall(function()
    local manifest = dofile("Mods/Tekken7AccessProbe/Modules/tekken7-ui-manifest.lua")
    if type(manifest) == "table" then tekken_ui_manifest = manifest end
end)

local event_path = "Mods/Tekken7AccessProbe/nvda-events.txt"
local diagnostic_path = "Mods/Tekken7AccessProbe/gfx-path-diagnostic.txt"
local fighter_probe_path = "Mods/Tekken7AccessProbe/fighter-probe.txt"
local option_input_path = "Mods/Tekken7AccessProbe/option-input.txt"
local last_fighter_probe = ""
local last_option_input = ""
local last_spoken_message = ""
local last_spoken_time = -100
local gfx_bursts = {}
local dump_loaded_character_select
local dump_character_grid
local character_select_movie_name
local unwrap
local scan_character_select
local scan_game_options
local scan_story_mode_difficulty
local emit_nvda
local modular_ui_reader = nil
local game_options_pending = false
local game_options_active = false
local game_options_source = nil
local game_option_name = nil
local game_option_value = nil
local game_option_rows = {}
local story_difficulty_index = nil
local latest_difficulty_index = nil
local select_side_left_time = -100
local select_side_announced_time = -100

local function remember_character_select_movie(value)
    character_select_movie_name = unwrap(value)
    print("[T7A][CHAR-MOVIE] remembered " .. tostring(character_select_movie_name))
end

local function invoke_character_cursor_reader()
    if character_select_movie_name == nil then return false end
    local found_ok, movies = pcall(FindAllOf, "GFxMoviePlayer")
    if not found_ok or movies == nil then return false end
    local character_select_movie = nil
    for _, movie in ipairs(movies) do
        local name_ok, name = pcall(function() return movie:GetFullName() end)
        if name_ok and tostring(name) == character_select_movie_name then
            character_select_movie = movie
            break
        end
    end
    if character_select_movie == nil then
        print("[T7A][CHAR-INVOKE] active movie not found: " .. tostring(character_select_movie_name))
        return false
    end
    local ok, result = pcall(scan_character_select, character_select_movie, 0)
    print(string.format("[T7A][CHAR-READ-UI] ok=%s result=%s",
        tostring(ok), tostring(result)))
    return ok and result == true
end

local function is_continuously_updated_fight_text(message)
    local compact = tostring(message):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if compact == "" or compact == "-" then return true end
    if compact:match("^STAGE%s+%d+$") then return true end
    -- Stoper walki/treningu, np. 00'01\"68 lub 00'00\"00.
    if compact:match("^%d%d?'%d%d\"%d%d$") then return true end
    -- Liczniki klatkowe/liczbowe, które UI odświeża bez ruchu użytkownika.
    if compact:match("^%d%d%d$") then return true end
    return false
end

local function process_fighter_probe()
    if not module_enabled("CharacterSelect") then return end
    local file = io.open(fighter_probe_path, "r")
    if file then
        local serial = file:read("*a") or ""
        file:close()
        if serial ~= "" and serial ~= last_fighter_probe then
            last_fighter_probe = serial
            local ok, result = pcall(invoke_character_cursor_reader)
            print("[T7A][CHAR-PROBE] serial=" .. serial .. " ok=" .. tostring(ok)
                .. " result=" .. tostring(result))
        end
    end
end

local story_difficulty_names = {
    [1] = "Easy", [2] = "Normal", [3] = "Hard",
    [4] = "Very Hard", [5] = "Ultra Hard"
}

local function process_option_input()
    if not module_enabled("Options") then return end
    local file = io.open(option_input_path, "r")
    if not file then return end
    local event = file:read("*a") or ""
    file:close()
    if event == "" or event == last_option_input then return end
    last_option_input = event
    if game_options_active and game_option_name == "Story Mode Difficulty"
        and story_difficulty_index ~= nil then
        local direction = event:match(":([LR])$")
        if direction == "L" then
            story_difficulty_index = math.max(1, story_difficulty_index - 1)
        elseif direction == "R" then
            story_difficulty_index = math.min(5, story_difficulty_index + 1)
        else
            return
        end
        local value = story_difficulty_names[story_difficulty_index]
        game_option_value = value
        emit_nvda("Story Mode Difficulty, " .. value)
    end
end

local function write_story_difficulty_state()
    if story_difficulty_index == nil then return end
    pcall(function()
        local file = assert(io.open(event_path, "a"))
        file:write("[T7A_STATE]StoryDifficulty:", tostring(story_difficulty_index), "\n")
        file:flush()
        file:close()
    end)
end

local function write_character_select_state()
    pcall(function()
        local file = assert(io.open(event_path, "a"))
        file:write("[T7A_STATE]CharacterSelect\n")
        file:flush()
        file:close()
    end)
end

local function write_return_side_selection_state()
    pcall(function()
        local file = assert(io.open(event_path, "a"))
        file:write("[T7A_STATE]ReturnSideSelection\n")
        file:flush()
        file:close()
    end)
end

local function write_return_main_menu_state(state)
    pcall(function()
        local file = assert(io.open(event_path, "a"))
        file:write("[T7A_STATE]", state, "\n")
        file:flush()
        file:close()
    end)
end

LoopAsync(50, function()
    ExecuteInGameThread(process_fighter_probe)
    return false
end)

local fighter_tick_clock = -100
local fighter_tick_ok, fighter_tick_error = pcall(function()
    RegisterHook("/Script/Engine.Actor:ReceiveTick", function()
        local now = os.clock()
        if now - fighter_tick_clock >= 0.04 then
            fighter_tick_clock = now
            process_fighter_probe()
        end
    end)
end)
print("[Tekken7AccessProbe] fighter tick hook: " .. tostring(fighter_tick_ok)
    .. " " .. tostring(fighter_tick_error))

emit_nvda = function(message)
    message = tostring(message):gsub("[\r\n]", " ")
    local now = os.clock()
    -- Nie dodawaj wielokrotnie tego samego tekstu do kolejki NVDA.
    if message == last_spoken_message and now - last_spoken_time < 3.0 then return end
    last_spoken_message = message
    last_spoken_time = now
    local ok, err = pcall(function()
        local file = assert(io.open(event_path, "a"))
        file:write(message, "\n")
        file:flush()
        file:close()
    end)
    if not ok then
        print("[Tekken7AccessProbe] NVDA event error: " .. tostring(err))
    end
end

pcall(function()
    local router = dofile("Mods/Tekken7AccessProbe/Modules/lua/router.lua")
    modular_ui_reader = router.new({ emit = emit_nvda, enabled = module_enabled })
    print("[T7A][MODULES] wspólny router UI załadowany")
end)

local function append_diagnostic(message)
    pcall(function()
        local file = assert(io.open(diagnostic_path, "a"))
        file:write(tostring(message):gsub("[\r\n]", " "), "\n")
        file:flush()
        file:close()
    end)
end

local game_option_names = {
    ["Story Mode Difficulty"] = true,
    ["CPU Difficulty"] = true,
    ["No. of Rounds"] = true,
    ["Time Limit"] = true,
    ["Controller Vibration Settings"] = true,
    ["Tournament Settings"] = true,
    ["Data Analysis Settings"] = true,
    ["Streaming Mode"] = true,
    ["Restore Default Settings"] = true
}

local game_option_descriptions = {
    ["Select the difficulty level of the Story Mode."] = "Story Mode Difficulty",
    ["Adjust the CPU difficulty settings for Arcade Battle."] = "CPU Difficulty",
    ["Adjust the number of rounds required to win a match in VS Battle and Arcade Battle."] = "No. of Rounds",
    ["Adjust the time limit for one round."] = "Time Limit"
}

local function handle_game_options_event(source, arguments, ui_path)
    if not module_enabled("Options") then return false end
    if arguments == "Main Menu" or arguments == "Online" or arguments == "Offline"
        or arguments == "Customization" or arguments == "Gallery"
        or arguments == "Player Information" or arguments == "Store"
        or arguments == "ULTIMATE TEKKEN BOWL" or arguments == "Quit" then
        game_options_pending = false
        game_options_active = false
        game_options_source = nil
        game_option_name = nil
        game_option_value = nil
        story_difficulty_index = nil
        return false
    end
    for index, name in pairs(story_difficulty_names) do
        if arguments == name then latest_difficulty_index = index end
    end
    if arguments == "Game Options" then
        game_options_pending = true
        game_option_name = nil
        story_difficulty_index = nil
        return false
    end

    local controls = arguments:find("Select", 1, true)
        and arguments:find("Change", 1, true)
        and arguments:find("Back", 1, true)
    if controls then
        if game_options_pending or game_options_active then game_options_active = true end
        return game_options_active
    end
    if not game_options_active then return false end

    local row_id = ui_path and ui_path:match("Panel(%d+)") or nil
    if row_id and ui_path:find("OptionName", 1, true) then
        game_option_rows[row_id] = game_option_rows[row_id] or {}
        game_option_rows[row_id].name = arguments
        game_options_source = source
        return true
    end
    if row_id and (ui_path:find("OptionValue", 1, true)
        or ui_path:find("DifficultyValue", 1, true)
        or ui_path:find("SoundValue", 1, true)) then
        game_option_rows[row_id] = game_option_rows[row_id] or {}
        game_option_rows[row_id].value = arguments
        local row_name = game_option_rows[row_id].name
        if row_name and row_name == game_option_name then
            game_option_value = arguments
            emit_nvda(row_name .. ", " .. arguments)
        end
        return true
    end

    if game_option_names[arguments] then
        game_options_source = source
        return true
    end

    local selected_name = game_option_descriptions[arguments]
    if selected_name then
        game_option_name = selected_name
        local selected_value = nil
        for _, row in pairs(game_option_rows) do
            if row.name == selected_name then
                selected_value = row.value
                break
            end
        end
        if selected_name == "Story Mode Difficulty" then
            local initial_value = selected_value or game_option_value
            for index, name in pairs(story_difficulty_names) do
                if name == initial_value then story_difficulty_index = index end
            end
            if story_difficulty_index == nil then
                story_difficulty_index = latest_difficulty_index
            end
            write_story_difficulty_state()
        end
        if selected_value and selected_value ~= "" then
            game_option_value = selected_value
            emit_nvda(game_option_name .. ", " .. selected_value)
        else
            emit_nvda(game_option_name)
        end
        return true
    end

    -- SW_UI_Option wysyła aktualną wartość z tego samego odtwarzacza co nazwy
    -- ustawień. Po zmianie lewo/prawo zdarzenie wartości przychodzi natychmiast.
    if game_options_source == source and arguments ~= "" then
        game_option_value = arguments
        if game_option_name == "Story Mode Difficulty" then
            for index, name in pairs(story_difficulty_names) do
                if name == arguments then story_difficulty_index = index end
            end
        end
        local is_difficulty_value = false
        for _, name in pairs(story_difficulty_names) do
            if name == arguments then is_difficulty_value = true end
        end
        if game_option_name and (game_option_name ~= "Story Mode Difficulty"
            or is_difficulty_value) then
            emit_nvda(game_option_name .. ", " .. game_option_value)
        end
        return true
    end
    return false
end

unwrap = function(value)
    if value == nil then return "nil" end
    local ok, result = pcall(function() return value:get() end)
    if ok then value = result end
    if value == nil then return "nil" end
    local text_ok, text = pcall(function() return value:ToString() end)
    if text_ok then return tostring(text) end
    local name_ok, name = pcall(function() return value:GetFullName() end)
    if name_ok then return tostring(name) end
    return tostring(value)
end

local function register_trace(function_name)
    local hook_ok, hook_error = pcall(function()
        RegisterHook(
            "/Script/ScaleformUI.GFxMoviePlayer:" .. function_name,
            function(...)
                -- Menu wyboru postaci nie wykonuje Actor:ReceiveTick. Każda animacja
                -- Scaleform jest więc również bezpiecznym punktem odbioru sygnału
                -- ruchu zapisanego przez natywny moduł klawiatury/pada.
                process_fighter_probe()
                local values = { ... }
                local parts = {}
                for index, value in ipairs(values) do
                    parts[index] = string.format("arg%d=%s", index, unwrap(value))
                end
                print(string.format("[T7A][GFX][%s] %s", function_name, table.concat(parts, " | ")))
                if function_name == "ReceiveGFxCommand" then
                    local command = values[2] and unwrap(values[2]) or ""
                    local arguments = values[3] and unwrap(values[3]) or ""
                    if command:find("T7A_NVDA", 1, true) then
                        local ui_path = nil
                        if arguments:sub(1, 5) == "T7A2|" then
                            ui_path, arguments = arguments:match("^T7A2|([^|]*)|(.*)$")
                            arguments = arguments or ""
                            print("[T7A][UI-PATH] " .. tostring(ui_path))
                        end
                        arguments = arguments:gsub("<[^>]->", ""):gsub("^%s+", ""):gsub("%s+$", "")
                        local source = values[1] and unwrap(values[1]) or "unknown"
                        local handled_modular = false
                        if modular_ui_reader then
                            local modular_ok, modular_result = pcall(
                                modular_ui_reader.consume, source, arguments)
                            handled_modular = modular_ok and modular_result == true
                        end
                        local handled_game_option = handle_game_options_event(source, arguments, ui_path)
                        local ui_now = os.clock()
                        if arguments == "LEFT" then
                            select_side_left_time = ui_now
                            handled_modular = true
                        elseif arguments == "RIGHT" and ui_now - select_side_left_time <= 0.75 then
                            if ui_now - select_side_announced_time > 1.0 then
                                write_return_main_menu_state("SelectSideLeft")
                                select_side_announced_time = ui_now
                            end
                            handled_modular = true
                        end
                        local lower_arguments = arguments:lower()
                        if lower_arguments:find("return to the main menu", 1, true)
                            or lower_arguments:find("return to main menu", 1, true) then
                            if arguments:find("?", 1, true) then
                                write_return_main_menu_state("ReturnMainMenuDialog")
                                handled_modular = true
                            else
                                write_return_main_menu_state("ReturnMainMenuSelected")
                            end
                        elseif lower_arguments:find("exit game and return to main menu", 1, true) then
                            write_return_main_menu_state("ReturnMainMenuSelected")
                        end
                        if arguments:find("Return to Side Selection", 1, true) then
                            write_return_side_selection_state()
                            handled_modular = true
                        end
                        if game_option_name == "Story Mode Difficulty"
                            and scan_story_mode_difficulty then
                            local story_ok, story_result = pcall(scan_story_mode_difficulty)
                            print("[T7A][STORY-DIFFICULTY-READ] ok=" .. tostring(story_ok)
                                .. " result=" .. tostring(story_result))
                        end
                        if arguments:find("Customized Slots", 1, true) then
                            remember_character_select_movie(values[1])
                            write_character_select_state()
                        end
                        if arguments:find("Select", 1, true)
                            and arguments:find("Change", 1, true)
                            and arguments:find("Back", 1, true)
                            and scan_game_options then
                            local options_ok, options_error = pcall(scan_game_options)
                            print("[T7A][GAME-OPTIONS-TRIGGER] ok=" .. tostring(options_ok)
                                .. " error=" .. tostring(options_error))
                        end
                        local now = os.clock()
                        local burst = gfx_bursts[source]
                        if not burst or now - burst.started > 0.35 then
                            burst = { started = now, count = 0 }
                            gfx_bursts[source] = burst
                        end
                        burst.count = burst.count + 1
                        -- Ekrany ładowania/walki potrafią wysłać kilkanaście statycznych
                        -- opisów w jednej klatce. Pierwsze komunikaty wystarczą; reszta
                        -- nie może zapchać kolejki mowy NVDA.
                        if not handled_modular and not handled_game_option and arguments ~= ""
                            and not is_continuously_updated_fight_text(arguments)
                            and burst.count <= 4 then emit_nvda(arguments) end
                    end
                elseif function_name == "SetExternalTexture" then
                    local resource = values[2] and unwrap(values[2]) or ""
                    local texture = values[3] and unwrap(values[3]) or ""
                    if resource:find("ST_NAME", 1, true) and not resource:find("RANDOM", 1, true) then
                        local stage_key = texture:match("SS_ST_NAME_([%w]+)")
                        local stage_names = {
                            ["00"]="Mishima Dojo", ["01"]="Forgotten Realm", ["02"]="Jungle Outpost",
                            ["03"]="Arctic Snowfall", ["04"]="Twilight Conflict", ["05"]="Dragon's Nest",
                            ["06"]="Souq", ["07"]="Devil's Pit", ["08"]="Mishima Building",
                            ["09"]="Abandoned Temple", ["10"]="Duomo di Sirio", ["11"]="Arena",
                            ["12"]="G Corp Helipad", ["12a"]="G Corp Helipad Night",
                            ["14"]="Brimstone and Fire", ["15"]="Precipice of Fate",
                            ["16"]="Violet Systems", ["19"]="Kinder Gym", ["20"]="Infinite Azure",
                            ["21"]="Geometric Plane", ["23"]="Howard Estate", ["24"]="Hammerhead",
                            ["26"]="Jungle Outpost 2", ["27"]="Twilight Conflict 2",
                            ["28"]="Last Day on Earth", ["29"]="Infinite Azure 2",
                            ["30"]="Cave of Enlightenment", ["31"]="Vermilion Gates",
                            ["32"]="Island Paradise", ["80"]="Infinite Azure"
                        }
                        if stage_key and stage_names[stage_key] then emit_nvda(stage_names[stage_key]) end
                    elseif resource:find("ST_NAME", 1, true) and resource:find("RANDOM", 1, true) then
                        emit_nvda("Losowa mapa")
                    end
                end
            end
        )
    end)
    if hook_ok then
        print("[Tekken7AccessProbe] hook registered: " .. function_name)
    else
        print("[Tekken7AccessProbe] hook error " .. function_name .. ": " .. tostring(hook_error))
    end
end

for _, function_name in ipairs({
    "Invoke",
    "SetVariableValue",
    "SetVariableValueArray",
    "OpenMovie",
    "LoadAndStart",
    "GotoAndPlay",
    "GotoAndPlayI",
    "GotoAndStop",
    "GotoAndStopI",
    "SetExternalTexture",
    "ReceiveGFxCommand"
}) do
    register_trace(function_name)
end

local function register_character_hook(function_name)
    local ok, err = pcall(function()
        RegisterHook(
            "/Script/TekkenGame.TekkenCharacterLoadHelper:" .. function_name,
            function(...)
                local values = { ... }
                local parts = {}
                for index, value in ipairs(values) do
                    parts[index] = string.format("arg%d=%s", index, unwrap(value))
                end
                print(string.format("[T7A][CHARACTER][%s] %s", function_name, table.concat(parts, " | ")))
            end
        )
    end)
    if ok then
        print("[Tekken7AccessProbe] character hook registered: " .. function_name)
    else
        print("[Tekken7AccessProbe] character hook error " .. function_name .. ": " .. tostring(err))
    end
end

register_character_hook("SetLoadedCharacterId")
register_character_hook("SetLoadedCharacter")

local function register_full_character_hook(path, label)
    local ok, err = pcall(function()
        RegisterHook(path, function(...)
            local values = { ... }
            local parts = {}
            for index, value in ipairs(values) do
                parts[index] = string.format("arg%d=%s", index, unwrap(value))
            end
            print(string.format("[T7A][CHARACTER][%s] %s", label, table.concat(parts, " | ")))
        end)
    end)
    if ok then
        print("[Tekken7AccessProbe] character hook registered: " .. label)
    else
        print("[Tekken7AccessProbe] character hook error " .. label .. ": " .. tostring(err))
    end
end

for _, name in ipairs({
    "AsyncLoadItemSetFromCustomizeData",
    "LoadItemSetFromCustomizeData",
    "LoadItemSetFromXML",
    "SetAsyncLoadItemSet"
}) do
    register_full_character_hook("/Script/TekkenGame.CharacterManager:" .. name, "CharacterManager." .. name)
end
register_full_character_hook(
    "/Script/TekkenGame.TekkenCharacterLoadHelper:SetPendingLoad",
    "TekkenCharacterLoadHelper.SetPendingLoad"
)
local fighter_names = {
    [0]="Paul", [1]="Law", [2]="King", [3]="Yoshimitsu", [4]="Hwoarang",
    [5]="Ling Xiaoyu", [6]="Jin", [7]="Bryan", [8]="Heihachi", [9]="Kazuya",
    [10]="Steve", [11]="Jack-7", [12]="Asuka", [13]="Devil Jin", [14]="Feng",
    [15]="Lili", [16]="Dragunov", [17]="Leo", [18]="Lars", [19]="Alisa",
    [20]="Claudio", [21]="Katarina", [22]="Lucky Chloe", [23]="Shaheen", [24]="Josie",
    [25]="Gigas", [26]="Kazumi", [27]="Devil Kazumi", [28]="Nina", [29]="Master Raven", [30]="Lee",
    [31]="Bob", [32]="Akuma", [33]="Kuma", [34]="Panda", [35]="Eddy",
    [36]="Eliza", [37]="Miguel", [38]="Tekken Force Soldier", [39]="Young Kazuya",
    [40]="Jack-4", [41]="Young Heihachi", [42]="Practice Dummy",
    [43]="Geese", [44]="Noctis", [45]="Anna",
    [46]="Lei", [47]="Marduk", [48]="Armor King", [49]="Julia Chang", [50]="Negan",
    [51]="Zafina", [52]="Ganryu", [53]="Leroy", [54]="Fahkumram",
    [55]="Kunimitsu", [56]="Lidia"
}

local stage_names = {
    [0]="Mishima Dojo", [1]="Forgotten Realm", [2]="Jungle Outpost",
    [3]="Arctic Snowfall", [4]="Twilight Conflict", [5]="Dragon's Nest",
    [6]="Souq", [7]="Devil's Pit", [8]="Mishima Building",
    [9]="Abandoned Temple", [10]="Duomo di Sirio", [11]="Arena",
    [12]="G Corp Helipad", [13]="G Corp Helipad, noc", [14]="Brimstone and Fire",
    [15]="Precipice of Fate", [16]="Violet Systems", [19]="Kinder Gym",
    [20]="Infinite Azure", [21]="Geometric Plane", [23]="Howard Estate",
    [24]="Hammerhead", [26]="Jungle Outpost 2", [27]="Twilight Conflict 2",
    [28]="Last Day on Earth", [29]="Infinite Azure 2", [30]="Cave of Enlightenment",
    [31]="Vermilion Gates", [32]="Island Paradise", [80]="Infinite Azure"
}

local last_stage_id = nil

local stage_hook_ok, stage_hook_error = pcall(function()
    RegisterHook("/Script/TekkenGame.TekkenBlueprintLibrary:SetStageId", function(_, stage_id_param)
        local value = stage_id_param
        pcall(function() value = stage_id_param:get() end)
        local stage_id = tonumber(value)
        if stage_id ~= nil and stage_id ~= last_stage_id then
            last_stage_id = stage_id
            emit_nvda(stage_names[stage_id] or ("Arena, identyfikator " .. tostring(stage_id)))
        end
    end)
end)
print("[Tekken7AccessProbe] stage id hook: " .. tostring(stage_hook_ok) .. " " .. tostring(stage_hook_error))
local last_fighter_id = nil
local known_movies = {}
local last_gfx_selection = nil
local automatic_path_probe_done = false
local automatic_path_probe_ticks = 0
local describe_as_value
local as_string
local document_text_state = {}

local function as_number(value)
    if value == nil then return nil end
    local result = value
    pcall(function() result = value:get() end)
    if result == nil then return nil end
    for _, field_name in ipairs({ "ASNumber", "ASInt" }) do
        local ok, field = pcall(function() return result[field_name] end)
        if ok and field ~= nil then
            pcall(function() field = field:get() end)
            local number = tonumber(field)
            if number ~= nil then return number end
        end
    end
    return tonumber(result)
end

local function gfx_number(movie, clip, member)
    local ok, value = pcall(function()
        return movie:GetVariableValue(clip, member)
    end)
    if not ok then return nil end
    return as_number(value)
end

local function gfx_string(movie, clip, member)
    local ok, value = pcall(function()
        return movie:GetVariableValue(clip, member)
    end)
    if not ok then return nil end
    return as_string(value)
end

local function as_object(value)
    if value == nil then return nil end
    local result = value
    pcall(function() result = value:get() end)
    if result == nil then return nil end
    local ok, object = pcall(function() return result.ASObject end)
    if not ok or object == nil then return nil end
    pcall(function() object = object:get() end)
    return object
end

as_string = function(value)
    if value == nil then return nil end
    local result = value
    pcall(function() result = value:get() end)
    if result == nil then return nil end
    local ok, text = pcall(function() return result.ASString end)
    if not ok or text == nil then return nil end
    pcall(function() text = text:get() end)
    return tostring(text)
end

local function invoke_no_params(object, function_name)
    local ok, value = pcall(function() return object:Invoke(function_name, {}) end)
    if not ok then return nil end
    return value
end

local function make_as_index(index)
    -- EASValueType::AS_Int is wartością 6 w ScaleformUI UE4.
    return { ASType = 6, ASInt = index, ASNumber = index }
end

local function scan_tk_document(movie, movie_index)
    local root_ok, root = pcall(function() return movie.Root end)
    if not root_ok or root == nil then return false end
    pcall(function() root = root:get() end)
    if root == nil then return false end

    local count_value = invoke_no_params(root, "GetNumOfTkTexts")
    local count = as_number(count_value)
    if count == nil or count < 1 or count > 1000 then return false end

    local texts = {}
    for index = 0, math.floor(count) - 1 do
        local item_ok, item_value = pcall(function()
            return root:Invoke("GetTkText", { make_as_index(index) })
        end)
        if item_ok then
            local text_object = as_object(item_value)
            if text_object ~= nil then
                local visible = true
                pcall(function() visible = text_object:GetVisible() end)
                if visible then
                    local text = as_string(invoke_no_params(text_object, "GetText"))
                    if text ~= nil then
                        text = text:gsub("<[^>]->", ""):gsub("^%s+", ""):gsub("%s+$", "")
                        if text ~= "" then texts[#texts + 1] = text end
                    end
                end
            end
        end
    end

    local combined = table.concat(texts, " | ")
    local state_key = tostring(movie_index)
    if combined ~= "" and document_text_state[state_key] ~= combined then
        document_text_state[state_key] = combined
        print(string.format("[T7A][TKDOCUMENT] movie=%d count=%d text=%s", movie_index, count, combined))
        emit_nvda(combined)
    end
    return true
end

scan_character_select = function(movie, movie_index)
    if not module_enabled("CharacterSelect") then return false end
    for slot = 0, 75 do
        local panel = string.format("_root.SelectPanel_mc.Panel_%02d_mc", slot)
        local character_panel = panel .. ".PanelSet_mc.CharaPanel_mc"
        local selection_frame = gfx_number(movie, character_panel, "currentFrame")
        local selected = selection_frame ~= nil and (
            (selection_frame >= 77 and selection_frame <= 80) or
            (selection_frame >= 101 and selection_frame <= 104) or
            (selection_frame >= 125 and selection_frame <= 128) or
            (selection_frame >= 203 and selection_frame <= 206)
        )
        if selected then
            local portrait_frame = gfx_number(
                movie, character_panel .. ".Rep_CS_CH_PANEL_mc", "currentFrame")
            local fighter_id = portrait_frame ~= nil and (math.floor(portrait_frame) - 2) or nil
            local key = string.format("%d:%d:%s", movie_index, slot, tostring(fighter_id))
            if fighter_id ~= nil and fighter_id >= 0 and fighter_id <= 56 and key ~= last_gfx_selection then
                last_gfx_selection = key
                print(string.format(
                    "[T7A][GFX-SELECTION] movie=%d slot=%d selectionFrame=%d portraitFrame=%s FighterId=%d",
                    movie_index, slot, selection_frame, tostring(portrait_frame), fighter_id
                ))
                emit_nvda(fighter_names[fighter_id] or ("Postać, identyfikator " .. tostring(fighter_id)))
            end
            return fighter_id ~= nil
        end
    end
    return false
end

local last_game_option = nil
local last_story_difficulty_frame = nil
scan_story_mode_difficulty = function()
    if not module_enabled("Options") or game_option_name ~= "Story Mode Difficulty" then
        return false
    end
    local movies_ok, movies = pcall(FindAllOf, "GFxMoviePlayer")
    if not movies_ok or movies == nil then return false end
    for movie_index, movie in ipairs(movies) do
        -- W SW_UI_Option Story Mode Difficulty jest pierwszym wierszem Panel0.
        -- Jego wartość nie jest tekstem OptionValue (ten tekst należy do CPU),
        -- lecz klatką 1..5 osobnego klipu DifficultyValue_mc.
        local panel = "_root.ListArea_mc.List1_mc.List1_Panel_mc.Panel0"
        local frame = gfx_number(movie, panel .. ".DifficultyValue_mc", "currentFrame")
        if frame ~= nil then
            frame = math.floor(frame)
            local name = story_difficulty_names[frame]
            if name ~= nil then
                if frame ~= last_story_difficulty_frame then
                    last_story_difficulty_frame = frame
                    game_option_value = name
                    print(string.format(
                        "[T7A][STORY-DIFFICULTY] movie=%d frame=%d value=%s",
                        movie_index, frame, name))
                    emit_nvda("Story Mode Difficulty, " .. name)
                end
                return true
            end
        end
    end
    return false
end

scan_game_options = function()
    local movies_ok, movies = pcall(FindAllOf, "GFxMoviePlayer")
    if not movies_ok or movies == nil then return false end
    for movie_index, movie in ipairs(movies) do
        for row = 0, 12 do
            local panel = string.format(
                "_root.ListArea_mc.List1_mc.List1_Panel_mc.Panel%d", row)
            local frame = gfx_number(movie, panel, "currentFrame")
            if frame == 4 or frame == 13 then
                local name = gfx_string(movie,
                    panel .. ".OptionName_mc.DT_OptionName_mc", "text")
                    or gfx_string(movie,
                        panel .. ".OptionName_mc.DT_OptionName_mc.DT_OptionName", "text")
                local value = gfx_string(movie,
                    panel .. ".OptionValue_mc.DT_OptionValue_mc", "text")
                    or gfx_string(movie,
                        panel .. ".OptionValue_mc.DT_OptionValue_mc.DT_OptionValue", "text")
                if name ~= nil then name = name:gsub("^%s+", ""):gsub("%s+$", "") end
                if value ~= nil then value = value:gsub("^%s+", ""):gsub("%s+$", "") end
                if name ~= nil and name ~= "" then
                    local message = name
                    if value ~= nil and value ~= "" then message = message .. ", " .. value end
                    if message ~= last_game_option then
                        last_game_option = message
                        print(string.format(
                            "[T7A][GAME-OPTION] movie=%d row=%d frame=%d text=%s",
                            movie_index, row, frame, message))
                        emit_nvda(message)
                    end
                    return true
                end
            end
        end
    end
    print("[T7A][GAME-OPTION] selected row not found")
    return false
end

local character_grid_dumped = false
dump_character_grid = function()
    if character_grid_dumped then return end
    local ok, movies = pcall(FindAllOf, "GFxMoviePlayer")
    if not ok or movies == nil then
        print("[T7A][CHAR-GRID] FindAllOf error=" .. tostring(movies))
        return
    end
    for movie_index, movie in ipairs(movies) do
        local found = 0
        local entries = {}
        for slot = 0, 75 do
            local clip = string.format(
                "_root.SelectPanel_mc.Panel_%02d_mc.PanelSet_mc.CharaPanel_mc.Rep_CS_CH_PANEL_mc",
                slot
            )
            local frame = gfx_number(movie, clip, "currentFrame")
            if frame ~= nil and frame >= 2 then
                local fighter_id = math.floor(frame) - 2
                entries[#entries + 1] = string.format("%02d=%d", slot, fighter_id)
                found = found + 1
            end
        end
        if found > 0 then
            print(string.format("[T7A][CHAR-GRID] movie=%d count=%d %s",
                movie_index, found, table.concat(entries, ",")))
            character_grid_dumped = true
            return
        end
    end
    print("[T7A][CHAR-GRID] no-loaded-panel-values")
end

RegisterKeyBind(Key.F11, function()
    character_grid_dumped = false
    local ok, err = pcall(dump_character_grid)
    print("[T7A][CHAR-GRID-MANUAL] ok=" .. tostring(ok) .. " error=" .. tostring(err))
    if not character_grid_dumped then emit_nvda("Dane postaci nie są jeszcze gotowe") end
end)

local function automatic_path_probe(movies)
    append_diagnostic("BEGIN movies=" .. tostring(#movies))
    local tests = {
        { "_root", "_currentframe" },
        { "", "_root._currentframe" },
        { "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc", "_xscale" },
        { "SelectPanel_mc.Panel_00_mc.PanelSet_mc", "_xscale" },
        { "_root", "SelectPanel_mc.Panel_00_mc.PanelSet_mc._xscale" },
        { "", "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc._xscale" },
        { "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc.CharaPanel_mc.Rep_CS_CH_PANEL_mc", "_currentframe" },
        { "", "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc.CharaPanel_mc.Rep_CS_CH_PANEL_mc._currentframe" }
    }
    for movie_index, movie in ipairs(movies) do
        local name_ok, full_name = pcall(function() return movie:GetFullName() end)
        local root_ok, root_value = pcall(function() return movie.Root end)
        append_diagnostic(string.format(
            "MOVIE %d name=%s root=%s",
            movie_index,
            name_ok and tostring(full_name) or "name-error",
            root_ok and unwrap(root_value) or "read-error"
        ))
        for test_index, test in ipairs(tests) do
            local call_ok, value = pcall(function() return movie:GetVariableValue(test[1], test[2]) end)
            append_diagnostic(string.format(
                "TEST %d.%d clip=%s member=%s ok=%s value=%s",
                movie_index, test_index, test[1], test[2], tostring(call_ok),
                call_ok and describe_as_value(value) or tostring(value)
            ))
        end
    end
    append_diagnostic("END")
    automatic_path_probe_done = true
    emit_nvda("Automatyczna diagnostyka ekranu zapisana")
end

local function read_player_one_fighter(context)
    local object = context
    pcall(function() object = context:get() end)
    if object == nil then return nil end
    local ok, selection = pcall(function() return object.Player1Selections end)
    if not ok or selection == nil then return nil end
    local field_ok, field = pcall(function()
        return selection["Fighter_5_BBC3F9BC475D21DF591B44AA9E29892B"]
    end)
    if not field_ok or field == nil then return nil end
    local value = field
    pcall(function() value = field:get() end)
    return tonumber(value)
end

local function announce_real_fighter(object, source)
    local fighter_id = read_player_one_fighter(object)
    if fighter_id ~= nil and fighter_id ~= last_fighter_id then
        last_fighter_id = fighter_id
        local name = fighter_names[fighter_id] or ("Postać, identyfikator " .. tostring(fighter_id))
        print("[T7A][REAL-FIGHTER-ID][" .. source .. "] " .. tostring(fighter_id) .. " " .. name)
        emit_nvda(name)
    end
end

local pending_ok, pending_error = pcall(function()
    RegisterHook(
        "/Game/Character/Common/BP_CharacterManager.BP_CharacterManager_C:UpdatePendingLoads",
        function(context)
            announce_real_fighter(context, "hook")
        end
    )
end)
print("[Tekken7AccessProbe] real fighter hook: " .. tostring(pending_ok) .. " " .. tostring(pending_error))

-- Blueprint wyboru postaci jest ładowany dopiero po wejściu na ekran, dlatego
-- stan odczytujemy również dynamicznie. Kod dotykający UObject działa w wątku gry.
LoopAsync(350, function()
    ExecuteInGameThread(function()
        local ok, objects = pcall(FindAllOf, "BP_CharacterManager_C")
        if ok and objects ~= nil then
            for _, object in ipairs(objects) do
                announce_real_fighter(object, "poll")
            end
        end


        local movies_ok, movies = pcall(FindAllOf, "GFxMoviePlayer")
        if movies_ok and movies ~= nil then
            automatic_path_probe_ticks = automatic_path_probe_ticks + 1
            if not automatic_path_probe_done and #movies >= 23 and automatic_path_probe_ticks >= 10 then
                automatic_path_probe(movies)
            end
            local current = {}
            for movie_index, movie in ipairs(movies) do
                local asset_ok, asset = pcall(function() return movie.SwfAssetName end)
                local asset_name = asset_ok and unwrap(asset) or "nil"
                if asset_name ~= "nil" and asset_name ~= "" then
                    current[asset_name] = true
                    if not known_movies[asset_name] then
                        known_movies[asset_name] = true
                        print("[T7A][SCREEN-OPEN] " .. asset_name)
                    end
                end
                scan_tk_document(movie, movie_index)
                scan_character_select(movie, movie_index)
            end
            for asset_name, _ in pairs(known_movies) do
                if not current[asset_name] then
                    known_movies[asset_name] = nil
                    print("[T7A][SCREEN-CLOSE] " .. asset_name)
                end
            end
        end
    end)
    return false
end)

local function dump_character_manager()
    local ok, objects = pcall(FindAllOf, "BP_CharacterManager_C")
    local count = (ok and objects ~= nil) and #objects or 0
    print(string.format("[T7A][MANAGER] BP_CharacterManager_C count=%d", count))
    if not ok or objects == nil then return end

    for index, object in ipairs(objects) do
        local name_ok, full_name = pcall(function() return object:GetFullName() end)
        print(string.format("[T7A][MANAGER][%d] %s", index, name_ok and tostring(full_name) or "name-error"))

        local selection_ok, selection = pcall(function() return object.Player1Selections end)
        print(string.format("[T7A][MANAGER][%d] Player1Selections=%s", index, selection_ok and unwrap(selection) or "read-error"))
        if selection_ok and selection ~= nil then
            for _, field_name in ipairs({
                "Fighter_5_BBC3F9BC475D21DF591B44AA9E29892B",
                "CostumeSet_3_6314FBAB409638D5BD4D86909A3F93C1"
            }) do
                local field_ok, field_value = pcall(function() return selection[field_name] end)
                print(string.format("[T7A][MANAGER][%d] %s=%s", index, field_name, field_ok and unwrap(field_value) or "read-error"))
            end
        end
    end
end

RegisterKeyBind(Key.F9, function()
    local ok, objects = pcall(FindAllOf, "GFxMoviePlayer")
    local count = (ok and objects ~= nil) and #objects or 0
    print(string.format("[T7A][SNAPSHOT] GFxMoviePlayer count=%d", count))
    if ok and objects ~= nil then
        for index, object in ipairs(objects) do
            local name_ok, full_name = pcall(function() return object:GetFullName() end)
            print(string.format("[T7A][OBJECT][%d] %s", index, name_ok and tostring(full_name) or "name-error"))
        end
    end
    emit_nvda("Tekken 7 Access działa. Znaleziono obiektów interfejsu: " .. tostring(count))
end)

RegisterKeyBind(Key.F10, function()
    if invoke_character_cursor_reader() then return end
    dump_character_manager()
    local manager_ok, managers = pcall(FindAllOf, "BP_CharacterManager_C")
    if manager_ok and managers ~= nil then
        for _, manager in ipairs(managers) do announce_real_fighter(manager, "F10-native-input") end
    end
    local ok, objects = pcall(FindAllOf, "GFxMoviePlayer")
    local count = (ok and objects ~= nil) and #objects or 0
    print(string.format("[T7A][PROPERTIES] GFxMoviePlayer count=%d", count))
    if not ok or objects == nil then return end
    for index, object in ipairs(objects) do
        local class = object:GetClass()
        while class and class:IsValid() do
            class:ForEachProperty(function(property)
                local property_name = property:GetFName():ToString()
                local property_type = property:GetClass():GetFName():ToString()
                local value_ok, value = pcall(function() return object[property_name] end)
                if value_ok then
                    local value_text = unwrap(value)
                    if value_text ~= "nil" then
                        print(string.format("[T7A][PROP][%d] %s %s=%s", index, property_type, property_name, value_text))
                    end
                end
            end)
            class = class:GetSuperStruct()
        end
    end
end)

describe_as_value = function(value)
    if value == nil then return "nil" end
    local result = value
    pcall(function() result = value:get() end)
    if result == nil then return "nil" end
    local parts = {}
    for _, field_name in ipairs({ "ASType", "ASBoolean", "ASInt", "ASNumber", "ASString", "ASObject" }) do
        local ok, field = pcall(function() return result[field_name] end)
        if ok then
            pcall(function() field = field:get() end)
            parts[#parts + 1] = field_name .. "=" .. unwrap(field)
        end
    end
    return #parts > 0 and table.concat(parts, ",") or unwrap(result)
end

RegisterKeyBind(Key.F11, function()
    ExecuteInGameThread(function()
        local ok, movies = pcall(FindAllOf, "GFxMoviePlayer")
        print("[T7A][PATH-PROBE] movie-count=" .. tostring(ok and movies and #movies or 0))
        if not ok or movies == nil then return end
        local tests = {
            { "_root", "_currentframe" },
            { "", "_root._currentframe" },
            { "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc", "_xscale" },
            { "SelectPanel_mc.Panel_00_mc.PanelSet_mc", "_xscale" },
            { "_root", "SelectPanel_mc.Panel_00_mc.PanelSet_mc._xscale" },
            { "", "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc._xscale" },
            { "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc.CharaPanel_mc.Rep_CS_CH_PANEL_mc", "_currentframe" },
            { "", "_root.SelectPanel_mc.Panel_00_mc.PanelSet_mc.CharaPanel_mc.Rep_CS_CH_PANEL_mc._currentframe" }
        }
        for movie_index, movie in ipairs(movies) do
            local name_ok, full_name = pcall(function() return movie:GetFullName() end)
            print(string.format("[T7A][PATH-PROBE][%d] %s", movie_index, name_ok and tostring(full_name) or "name-error"))
            for test_index, test in ipairs(tests) do
                local call_ok, value = pcall(function() return movie:GetVariableValue(test[1], test[2]) end)
                print(string.format(
                    "[T7A][PATH-PROBE][%d][%d] clip=%s member=%s ok=%s value=%s",
                    movie_index, test_index, test[1], test[2], tostring(call_ok),
                    call_ok and describe_as_value(value) or tostring(value)
                ))
            end
        end
        emit_nvda("Diagnostyka ekranu zapisana")
    end)
end)

emit_nvda("Tekken 7 Access. Mod UE4SS uruchomiony.")

-- Zrzuca dokładny GFX odszyfrowany przez grę. Dzięki temu poprawki ekranu
-- wyboru powstają z assetu faktycznie załadowanego przez obecną wersję Steam.
local character_gfx_dumped = false
local character_gfx_attempt = 0
local character_asset_names = {
    "/Game/UI_common/flash/SW_UI_CharacterSelect/SW_UI_CharacterSelect.SW_UI_CharacterSelect",
    "SwfMovie /Game/UI_common/flash/SW_UI_CharacterSelect/SW_UI_CharacterSelect.SW_UI_CharacterSelect",
    "SW_UI_CharacterSelect"
}

local function find_character_swf()
    for _, object_name in ipairs(character_asset_names) do
        local ok, object = pcall(StaticFindObject, object_name)
        if ok and object ~= nil and object:IsValid() then
            print("[T7A][RUNTIME-GFX-FIND] StaticFindObject=" .. object_name)
            return object
        end
    end

    local ok, movies = pcall(FindAllOf, "SwfMovie")
    if not ok then
        print("[T7A][RUNTIME-GFX-FIND] FindAllOf error=" .. tostring(movies))
        return nil
    end
    print("[T7A][RUNTIME-GFX-FIND] FindAllOf count=" .. tostring(movies and #movies or 0))
    for _, movie in ipairs(movies or {}) do
        local name_ok, full_name = pcall(function() return movie:GetFullName() end)
        if name_ok then
            print("[T7A][RUNTIME-GFX-CANDIDATE] " .. tostring(full_name))
            if tostring(full_name):find("SW_UI_CharacterSelect", 1, true) then return movie end
        end
    end
    return nil
end

dump_loaded_character_select = function()
    if character_gfx_dumped then return end
    character_gfx_attempt = character_gfx_attempt + 1
    -- Log co dziesiątą próbę, aby diagnostyka była widoczna bez zalewania pliku.
    if character_gfx_attempt % 10 ~= 1 then return end
    print("[T7A][RUNTIME-GFX-TRY] attempt=" .. tostring(character_gfx_attempt))
    local movie = find_character_swf()
    if movie == nil then return end
    local raw_ok, raw = pcall(function() return movie.RawData end)
    if not raw_ok or raw == nil then
        print("[T7A][RUNTIME-GFX-RAW] error=" .. tostring(raw))
        return
    end
    local count_ok, count = pcall(function() return raw:GetArrayNum() end)
    if not count_ok then count_ok, count = pcall(function() return #raw end) end
    print("[T7A][RUNTIME-GFX-RAW] count=" .. tostring(count) .. " ok=" .. tostring(count_ok))
    if not count_ok or count == nil or count < 1000 then return end
    local output_path = "Mods/Tekken7AccessProbe/SW_UI_CharacterSelect.runtime.gfx"
    local out, open_error = io.open(output_path, "wb")
    if not out then
        print("[T7A][RUNTIME-GFX-OPEN] error=" .. tostring(open_error))
        return
    end
            local buffer = {}
            -- UE4SS wystawia elementy RawData w Lua pod indeksami 1..Num.
            for index = 1, count do
                local value = raw[index]
                pcall(function() value = value:get() end)
                buffer[#buffer + 1] = string.char((tonumber(value) or 0) % 256)
                if #buffer >= 4096 then
                    out:write(table.concat(buffer))
                    buffer = {}
                end
            end
            if #buffer > 0 then out:write(table.concat(buffer)) end
            out:close()
            character_gfx_dumped = true
            print("[T7A][RUNTIME-GFX-DUMP] bytes=" .. tostring(count))
            emit_nvda("Zapisano właściwy ekran wyboru postaci z pamięci gry")
end

-- Diagnostyczny zrzut RawData SWF jest celowo wyłączony. Odczyt dużej tablicy
-- na ekranie postaci powodował crash UE4SS; postacie czyta osobny, bezpieczny
-- moduł tylko do odczytu pamięci.
