@{
    Core = $true
    MainMenu = $true
    Offline = $true
    Online = $true
    Story = $true
    Options = $true
    Dialogs = $true
    Practice = $true
    CharacterSelect = $true
    StageSelect = $true
    Customization = $true
}
