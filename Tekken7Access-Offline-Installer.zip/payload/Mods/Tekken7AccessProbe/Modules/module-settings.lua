return {
    CharacterSelect = true,
    Core = true,
    Customization = true,
    Dialogs = true,
    MainMenu = true,
    Offline = true,
    Online = true,
    Options = true,
    Practice = true,
    StageSelect = true,
    Story = true,
}
