@{
    Core = @{
        Kind = 'UE4SS'
        Description = 'Wspólny zapis komunikatów NVDA, filtrowanie powtórzeń i obsługa wejścia.'
    }
    MainMenu = @{ Kind = 'Lua'; Description = 'Menu główne i menu trybów.' }
    Offline = @{ Kind = 'Lua'; Description = 'Arcade, Treasure, VS i wejście do Practice.' }
    Online = @{ Kind = 'Lua'; Description = 'Ranked, Player Match, pokoje i wyszukiwanie sesji.' }
    Story = @{ Kind = 'Lua'; Description = 'Story Mode, rozdziały i komunikaty fabularne.' }
    Options = @{ Kind = 'Lua'; Description = 'Game Options, opisy oraz wartości lewo/prawo.' }
    Dialogs = @{ Kind = 'Lua'; Description = 'Are you sure, Yes/No, Quit i powrót do menu.' }
    Practice = @{ Kind = 'Lua'; Description = 'Menu treningu i wybór przeciwnika CPU.' }
    CharacterSelect = @{ Kind = 'External'; Description = 'Nazwy postaci gracza i CPU.' }
    StageSelect = @{ Kind = 'Lua'; Description = 'Nazwy aren.' }
    Customization = @{ Kind = 'Lua'; Description = 'Postacie, stroje i zapisane sloty.' }
}
