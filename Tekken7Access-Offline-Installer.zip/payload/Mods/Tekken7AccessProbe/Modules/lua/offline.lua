return {
    ["Arcade Battle"] = "SW_UI_MainMenu",
    ["Treasure Battle"] = "SW_UI_MainMenu",
    ["VS Battle"] = "SW_UI_MainMenu",
    ["Practice"] = "SW_UI_Practice"
}
