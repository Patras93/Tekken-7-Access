return {
    ["Main Menu"] = "SW_UI_MainMenu",
    ["Story: \"The Mishima Saga\""] = "SW_UI_MainMenu",
    ["Online"] = "SW_UI_MainMenu",
    ["Offline"] = "SW_UI_MainMenu",
    ["Customization"] = "SW_UI_MainMenu",
    ["Gallery"] = "SW_UI_MainMenu",
    ["Options"] = "SW_UI_MainMenu",
    ["Player Information"] = "SW_UI_MainMenu",
    ["Quit"] = "SW_UI_MainMenu"
}
