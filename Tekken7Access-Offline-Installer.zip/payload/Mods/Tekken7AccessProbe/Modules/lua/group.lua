local Group = {}

function Group.new(core, module_name, markers)
    return {
        consume = function(_, raw)
            if not core.enabled(module_name) then return false end
            local text = core.normalize(raw)
            local screen = markers[text]
            if screen then
                core.state.module = module_name
                core.state.screen = screen
            end
            return false
        end
    }
end

return Group
