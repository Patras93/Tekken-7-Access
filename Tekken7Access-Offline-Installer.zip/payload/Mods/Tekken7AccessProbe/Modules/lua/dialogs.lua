local Dialogs = {}

function Dialogs.new(core)
    local active = false
    local function is_question(text)
        local lower = text:lower()
        return text:find("?", 1, true)
            or lower:find("are you sure", 1, true)
            or lower:find("really want", 1, true)
    end
    local function consume(_, raw)
        if not core.enabled("Dialogs") then return false end
        local text = core.normalize(raw)
        if is_question(text) then
            active = true
            core.state.screen, core.state.module = "Dialog", "Dialogs"
            core.state.description = text
            return core.speak(text)
        end
        if active and (text == "Yes" or text == "No" or text == "OK" or text == "Cancel") then
            core.state.selected = text
            return core.speak(text)
        end
        if active and text:find("Confirm", 1, true) and text:find("Back", 1, true) then
            return true
        end
        return false
    end
    return { consume = consume }
end

return Dialogs
