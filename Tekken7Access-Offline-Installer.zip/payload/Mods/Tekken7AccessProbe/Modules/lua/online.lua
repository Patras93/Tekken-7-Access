return {
    ["Ranked Match"] = "SW_UI_RankMatch_MatchList",
    ["Player Match"] = "SW_UI_PlayerMatch_SessionList",
    ["Create Session"] = "SW_UI_PlayerMatch_SessionRoom",
    ["Search Sessions"] = "SW_UI_PlayerMatch_SessionList",
    ["Tournament"] = "SW_UI_OnlineTournament_SessionList",
    ["Player List"] = "SW_UI_Online_PlayerList"
}
