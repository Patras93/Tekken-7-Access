return {
    ["Story: \"The Mishima Saga\""] = "SW_UI_StoryMode",
    ["Select Story Mode Difficulty"] = "SW_UI_StoryMode_Option",
    ["Switch to Main Story"] = "SW_UI_StoryMode_Episode"
}
