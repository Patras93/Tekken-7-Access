local Router = {}

function Router.new(api)
    local core = dofile("Mods/Tekken7AccessProbe/Modules/lua/core.lua").new(api)
    local group = dofile("Mods/Tekken7AccessProbe/Modules/lua/group.lua")
    local handlers = {
        dofile("Mods/Tekken7AccessProbe/Modules/lua/dialogs.lua").new(core),
        dofile("Mods/Tekken7AccessProbe/Modules/lua/options.lua").new(core),
        group.new(core, "MainMenu", dofile("Mods/Tekken7AccessProbe/Modules/lua/main_menu.lua")),
        group.new(core, "Offline", dofile("Mods/Tekken7AccessProbe/Modules/lua/offline.lua")),
        group.new(core, "Online", dofile("Mods/Tekken7AccessProbe/Modules/lua/online.lua")),
        group.new(core, "Story", dofile("Mods/Tekken7AccessProbe/Modules/lua/story.lua")),
        group.new(core, "Practice", dofile("Mods/Tekken7AccessProbe/Modules/lua/practice.lua")),
        group.new(core, "CharacterSelect", dofile("Mods/Tekken7AccessProbe/Modules/lua/character_select.lua")),
        group.new(core, "StageSelect", dofile("Mods/Tekken7AccessProbe/Modules/lua/stage_select.lua")),
        group.new(core, "Customization", dofile("Mods/Tekken7AccessProbe/Modules/lua/customization.lua"))
    }
    return {
        consume = function(source, text)
            for _, handler in ipairs(handlers) do
                local ok, handled = pcall(handler.consume, source, text)
                if ok and handled then return true end
            end
            return false
        end,
        state = core.state
    }
end

return Router
