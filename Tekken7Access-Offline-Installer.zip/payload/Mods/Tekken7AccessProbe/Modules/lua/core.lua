local Core = {}

function Core.new(api)
    local state = {
        screen = "Unknown", module = "Core", selected = nil,
        value = nil, description = nil, last = nil, last_time = -100
    }
    local function normalize(text)
        return tostring(text or ""):gsub("<[^>]->", ""):gsub("[\r\n]", " ")
            :gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    end
    local function speak(text)
        text = normalize(text)
        if text == "" then return false end
        local now = os.clock()
        if state.last == text and now - state.last_time < 0.35 then return true end
        state.last, state.last_time = text, now
        api.emit(text)
        return true
    end
    return { state = state, normalize = normalize, speak = speak, enabled = api.enabled }
end

return Core
