local Options = {}

function Options.new(core)
    local names = {
        ["Story Mode Difficulty"] = true, ["CPU Difficulty"] = true,
        ["No. of Rounds"] = true, ["Time Limit"] = true,
        ["Controller Vibration Settings"] = true, ["Tournament Settings"] = true,
        ["Data Analysis Settings"] = true, ["Streaming Mode"] = true,
        ["Restore Default Settings"] = true
    }
    local values = {
        ["Easy"] = true, ["Normal"] = true, ["Hard"] = true,
        ["Very Hard"] = true, ["Ultra Hard"] = true,
        ["On"] = true, ["Off"] = true, ["Infinity"] = true
    }
    local function consume(_, raw)
        if not core.enabled("Options") then return false end
        local text = core.normalize(raw)
        if text == "Game Options" then
            core.state.screen, core.state.module = "SW_UI_Option", "Options"
            return false
        end
        if core.state.module ~= "Options" then return false end
        if names[text] then
            core.state.selected, core.state.value = text, nil
            return false
        end
        if values[text] and core.state.selected and core.state.selected ~= "Story Mode Difficulty" then
            core.state.value = text
            -- Na etapie zgodności tylko zapamiętujemy stan. Dotychczasowy,
            -- sprawdzony handler wypowiada wartość i nie może zostać zdublowany.
            return false
        end
        return false
    end
    return { consume = consume }
end

return Options
