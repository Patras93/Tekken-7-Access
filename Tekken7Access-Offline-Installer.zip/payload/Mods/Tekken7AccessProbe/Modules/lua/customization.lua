return {
    ["Character Customization"] = "SW_UI_CharacterCustomize",
    ["Player Customization"] = "SW_UI_PlayerCustomize"
}
