return {
    ["Random"] = "SW_UI_StageSelect",
    ["Mishima Dojo"] = "SW_UI_StageSelect",
    ["Infinite Azure"] = "SW_UI_StageSelect",
    ["Infinite Azure 2"] = "SW_UI_StageSelect"
}
