return {
    ["Practice"] = "SW_UI_Practice",
    ["Move List"] = "SW_UI_Practice_CommandList",
    ["Repeat Action"] = "SW_UI_Practice",
    ["CPU Opponent Action 1"] = "SW_UI_Practice",
    ["Record"] = "SW_UI_Practice"
}
