return {
    ["Customized Slots"] = "SW_UI_CharacterSelect",
    ["Favorite"] = "SW_UI_CharacterSelect",
    ["Select Side"] = "SW_UI_PlaySideSelect"
}
