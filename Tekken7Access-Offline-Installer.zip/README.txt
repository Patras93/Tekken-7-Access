TEKKEN 7 ACCESS
===============

1. Uruchom install-launcher.bat.
2. Instalator automatycznie znajdzie Tekken 7 w bibliotekach Steam.
3. Uruchamiaj grę plikiem:
   TekkenGame\Binaries\Win64\Tekken7Access\Tekken 7 Access.exe

Wszystkie zwykłe pliki programu znajdują się w jednym folderze Tekken7Access.
W Win64\Mods instalowane są tylko dwa moduły wymagane przez UE4SS:
Tekken7AccessProbe oraz Tekken7AccessNative.

Pakiet jest kompletny i działa offline. Zawiera UE4SS, biblioteki NVDA,
launcher, czytnik postaci i wszystkie moduły dostępności. Użytkownik nie musi
niczego dodatkowo pobierać.

Instalator dodaje własne PAK-i dostępności do TekkenGame\Content\Paks.
Nie zastępuje i nie modyfikuje żadnego oryginalnego PAK-a gry.

Instalator nie modyfikuje oryginalnych plików ani PAK-ów Tekkena 7.
