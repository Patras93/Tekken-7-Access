param([string]$GameRoot)
$ErrorActionPreference = 'Stop'

function Find-TekkenRoot {
    $libraries = [Collections.Generic.List[string]]::new()
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        $steam = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
        if ($steam.SteamPath) { $libraries.Add([string]$steam.SteamPath) }
        if ($steam.InstallPath) { $libraries.Add([string]$steam.InstallPath) }
    }
    foreach ($steamRoot in @($libraries)) {
        $vdf = Join-Path $steamRoot 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in Get-Content -LiteralPath $vdf) {
                if ($line -match '"path"\s+"([^"]+)"') {
                    $libraries.Add(($Matches[1] -replace '\\\\','\'))
                }
            }
        }
    }
    foreach ($library in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $library 'steamapps\common\TEKKEN 7'
        $exe = Join-Path $candidate 'TekkenGame\Binaries\Win64\TekkenGame-Win64-Shipping.exe'
        if (Test-Path -LiteralPath $exe) { return $candidate }
    }
    throw 'Nie znaleziono Tekken 7. Uruchom: powershell -File install.ps1 -GameRoot "X:\...\TEKKEN 7"'
}

if (-not $GameRoot) { $GameRoot = Find-TekkenRoot }
$win64 = Join-Path $GameRoot 'TekkenGame\Binaries\Win64'
if (-not (Test-Path -LiteralPath (Join-Path $win64 'TekkenGame-Win64-Shipping.exe'))) {
    throw "Nieprawidlowy katalog Tekken 7: $GameRoot"
}

$payload = Join-Path $PSScriptRoot 'payload'
$accessSource = Join-Path $payload 'Tekken7Access'
$modsSource = Join-Path $payload 'Mods'
$runtimeSource = Join-Path $payload 'UE4SS'
$paksSource = Join-Path $payload 'Paks'
if (-not (Test-Path -LiteralPath (Join-Path $accessSource 'Tekken 7 Access.exe'))) {
    throw 'Pakiet jest niekompletny: brak launchera.'
}

$accessTarget = Join-Path $win64 'Tekken7Access'
$modsTarget = Join-Path $win64 'Mods'
New-Item -ItemType Directory -Force -Path $accessTarget,$modsTarget | Out-Null
Copy-Item -Path (Join-Path $accessSource '*') -Destination $accessTarget -Recurse -Force
Copy-Item -Path (Join-Path $modsSource '*') -Destination $modsTarget -Recurse -Force

# Kompletny runtime UE4SS jest częścią pakietu — instalator nie pobiera niczego.
foreach ($file in @('dwmapi.dll','UE4SS.dll')) {
    Copy-Item -LiteralPath (Join-Path $runtimeSource $file) -Destination (Join-Path $win64 $file) -Force
}
$settingsTarget = Join-Path $win64 'UE4SS-settings.ini'
if (-not (Test-Path -LiteralPath $settingsTarget)) {
    Copy-Item -LiteralPath (Join-Path $runtimeSource 'UE4SS-settings.ini') -Destination $settingsTarget
}
foreach ($directory in @('MemberVarLayoutTemplates','UE4SS_Signatures','VTableLayoutTemplates')) {
    $source = Join-Path $runtimeSource $directory
    $target = Join-Path $win64 $directory
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    Copy-Item -Path (Join-Path $source '*') -Destination $target -Recurse -Force
}

# Dodatkowe PAK-i moda udostępniają tekst Scaleform dla NVDA. Nie zastępują
# ani nie modyfikują żadnego oryginalnego PAK-a gry.
$paksTarget = Join-Path $GameRoot 'TekkenGame\Content\Paks'
Copy-Item -Path (Join-Path $paksSource '*.pak') -Destination $paksTarget -Force

$modsFile = Join-Path $modsTarget 'mods.txt'
$lines = [Collections.Generic.List[string]]::new()
if (Test-Path -LiteralPath $modsFile) {
    foreach ($line in Get-Content -LiteralPath $modsFile) { $lines.Add([string]$line) }
}
foreach ($name in @('Tekken7AccessProbe','Tekken7AccessNative')) {
    $pattern = '^\s*' + [regex]::Escape($name) + '\s*:'
    $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match $pattern) { $lines[$i] = "$name : 1"; $found = $true }
    }
    if (-not $found) { $lines.Add("$name : 1") }
}
Set-Content -LiteralPath $modsFile -Value $lines -Encoding UTF8

Write-Host "Zainstalowano folder: $accessTarget"
Write-Host 'W Mods umieszczono wylacznie pliki wymagane przez UE4SS.'
Write-Host 'Pakiet zawiera UE4SS i biblioteki NVDA; internet nie jest potrzebny.'
Write-Host 'Dodano PAK-i moda; nie zmieniono oryginalnych PAK-ow gry.'
