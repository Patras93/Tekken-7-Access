@echo off
setlocal
chcp 65001 >nul
fltmc >nul 2>&1
if errorlevel 1 (
  echo Instalator wymaga uprawnien administratora.
  powershell.exe -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo Instalowanie Tekken 7 Access...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Instalacja nie powiodla sie.
  pause
  exit /b 1
)
echo.
echo Instalacja zakonczona.
echo Uruchamiaj: TekkenGame\Binaries\Win64\Tekken7Access\Tekken 7 Access.exe
pause
