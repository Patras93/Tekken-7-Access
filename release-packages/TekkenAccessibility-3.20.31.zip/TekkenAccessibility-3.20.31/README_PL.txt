Tekken 7 Access 3.20.31

Opcje pokoju po X: odczyt zaznaczonej pozycji, pierwszego wyboru po otwarciu i zmienianej wartości.
Potwierdzenie nazwy pokoju: odczyt pytania z wpisaną nazwą i aktualnego Tak/Nie; strzałki odczytują nowy wybór.
Czat: przechwytywanie faktycznych wiadomości z nadawcą i odczyt historii przy przewijaniu. Pierwszy ruch czyta najnowszą wiadomość; następne ruchy w górę czytają starsze, w dół nowsze. Własny kursor dostępności nie odzwierciedla pikselowego położenia widocznej listy.

Historia czatu obejmuje do 100 wiadomości przechwyconych od załadowania moda; wyczyszczenie historii w grze usuwa też zapisane wiadomości. Samo schowanie i ponowne pokazanie czatu zachowuje pozycję odczytu.

Zamknij grę przed instalacją. Skopiuj pliki paczki do TekkenGame\Binaries\Win64. Zachowaj kopię poprzedniej wersji DLL.

Weryfikacja w grze z NVDA jest nadal wymagana: utwórz pokój, otwórz menu X i użyj strzałek; wpisz nazwę i sprawdź Tak/Nie; po pojawieniu się wiadomości sprawdź przewijanie czatu.
