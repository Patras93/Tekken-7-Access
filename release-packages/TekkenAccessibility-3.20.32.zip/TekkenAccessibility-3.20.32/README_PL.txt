# Tekken 7 Access 3.20.32

NVDA odczytuje nick gracza, który dołączył do pokoju lub z niego wyszedł. Osoby obecne przy otwarciu pokoju nie są ogłaszane jako nowi gracze.

Aby zainstalować aktualizację, zamknij Tekken 7, zachowaj kopię obecnej instalacji moda i skopiuj zawartość folderu paczki do `TekkenGame/Binaries/Win64`.

Wydanie stabilne na wyraźną prośbę właściciela. Test tego wydania w grze z NVDA nie został potwierdzony.
