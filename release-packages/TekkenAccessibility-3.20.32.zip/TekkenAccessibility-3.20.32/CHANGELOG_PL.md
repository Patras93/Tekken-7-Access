# Tekken 7 Access 3.20.32

NVDA odczytuje nick gracza, który dołączył do pokoju lub z niego wyszedł. Osoby obecne przy otwarciu pokoju nie są ogłaszane jako nowi gracze.

Aby zainstalować aktualizację, zamknij Tekken 7, zachowaj kopię obecnej instalacji moda i skopiuj zawartość folderu paczki do `TekkenGame/Binaries/Win64`.

Wydanie stabilne na wyraźną prośbę właściciela. Test tego wydania w grze z NVDA nie został potwierdzony.

# 3.20.31

Opcje pokoju po X: odczyt zaznaczonej pozycji, pierwszego wyboru po otwarciu i zmienianej wartości.
Potwierdzenie nazwy pokoju: odczyt pytania z wpisaną nazwą i aktualnego Tak/Nie; strzałki odczytują nowy wybór.
Czat: przechwytywanie faktycznych wiadomości z nadawcą i odczyt historii przy przewijaniu. Pierwszy ruch czyta najnowszą wiadomość; następne ruchy w górę czytają starsze, w dół nowsze. Własny kursor dostępności nie odzwierciedla pikselowego położenia widocznej listy.

# 3.20.30

Graphics Options: odczyt aktualnej wartości po zmianie lewo/prawo, bez powtarzania przy niezmienionym odświeżeniu.

## 3.20.29 — poprawki po audycie

- Pokoje i lobby anulują oczekujący odczyt natychmiast po utracie aktywnego okna. Komunikaty starsze niż sekunda są odrzucane; dane do ręcznego odczytu pozostają.
- Filtr postaci w Leaderboard zbiera numerowane nazwy, także pozycję „wszystkie postacie”, i odczytuje wyłącznie wybór kursora w natywnej siatce 9 kolumn. Wypełnianie całej siatki pozostaje ciche.
- Szybkie ruchy wybierają ostatnią pozycję. Zamknięcie filtra usuwa jego oczekujący odczyt, a ponowne otwarcie pozwala powtórzyć wybór.
- Dodano dwa sprawdzane podłączenia: otwarcie filtra i przesunięcie kursora. Wymagany test w grze z NVDA.

## 3.20.28 — pełne informacje przy przewijaniu pokoi

- Poprawiono dobór rekordu pokoju podczas przewijania wyników wyszukiwania. Argument funkcji oznacza kierunek animacji, a nie początek listy.
- Ujemny kierunek nie pomija już uzupełniania postaci, rangi, połączenia i obszaru. Dane są wiązane z panelem według indeksu używanego przez grę, również poza pierwszą stroną.
- Zachowano odczyt gospodarza, nazwy sesji i języka oraz szybkie przewijanie. Nie dodano nowych hooków.
- Wymagany test w grze: przejście listy w dół i w górę, także po zmianie strony.

## 3.20.27 — lista rankingowa Online

- Poprawiono rozpoznawanie numerowanych pól nicków i dodano odczyt zaznaczonego wiersza: nick, miejsce oraz dostępny wynik liczbowy.
- Wybór pochodzi z natywnego Select1, z uwzględnieniem przesunięcia panelu podczas przewijania. Odczyt po krótkim scaleniu zmian obejmuje ostatnią wybraną pozycję.
- Dodano obsługę tekstów filtrów w obu istniejących ścieżkach ustawiania tekstu. Zmiana filtra usuwa poprzednie dane listy; pusty nick usuwa dane wiersza.
- Nie dodano nowych podłączeń do gry. Test w grze z NVDA pozostaje wymagany, zwłaszcza przewijanie między stronami i zmiany filtrów. Ikony postaci/rangi w wierszu nie są objęte tą poprawką.

## 3.20.26 — napisy dialogowe

- Dodano odczyt napisów w natywnym mechanizmie filmów i walki, dopiero gdy gra je wyświetla.
- Kolejne klatki tego samego napisu nie powtarzają komunikatu. Nowy napis przerywa poprzednią wypowiedź, aby nie tworzyć opóźnionej kolejki.
- Odczyt respektuje Ctrl+Shift+F4 i działa tylko przy aktywnym oknie gry. Napisy muszą być włączone w ustawieniach gry.
- Treść dialogów pozostaje w języku napisów gry. Ctrl+L zmienia język moda, nie tłumaczy dialogów gry.
- Nie dodano audiodeskrypcji filmów ani nowych celów specjalnych Story. Test w grze z NVDA pozostaje do wykonania.

## Launcher / Updater v5 — PL

- Pobieranie changelogów PL/EN w formatach MD i TXT, z pierwszeństwem aktualnego MD.
- Możliwość uzupełnienia changelogów dla już zainstalowanej wersji bez podmiany DLL.
- Wybór paczki TekkenAccessibility-NUMER.zip zamiast archiwum źródeł.
- Przygotowanie plików i kopii zapasowych przed podmianą; brak oznaczenia nieudanej aktualizacji jako zakończonej.
- Launcher czeka na zakończenie updatera, także po przekroczeniu dwóch minut. Nie uruchamia gry po błędzie aktualizacji; brak sieci pozwala na uruchomienie istniejącej instalacji.
- Narzędzia nie podmieniają samych siebie. Wersja DLL moda pozostaje 3.20.25.

## Launcher / Updater v5 — EN

- Download PL/EN changelogs in MD and TXT formats, preferring the current Markdown files.
- Repair changelogs for an already installed release without replacing DLLs.
- Select TekkenAccessibility-VERSION.zip instead of a source archive.
- Stage files and backups before replacement; failed updates are not marked complete.
- Wait for the updater to finish, including runs longer than two minutes. Update failure blocks game launch; offline checking permits startup of the existing installation.
- The tools do not replace themselves. The mod DLL version remains 3.20.25.


# Tekken Accessibility 3.20.25 — Story reading controls

## Polski

- Ctrl+Shift+F1 powtarza przechwycony tekst Story, również tytuł i numer rozdziału.
- Ctrl+Shift+F2/F3 czyta następny/poprzedni fragment narracji, z numerem fragmentu. Fragmenty mają do 400 znaków; preferowane są granice słów i zdań. Po ostatnim następuje pierwszy.
- Ctrl+Shift+F4 obejmuje teraz automatyczną narrację Story oraz tytuły rozdziałów. Wyłączenie nie usuwa tekstu dostępnego ręcznie. Ustawienie obowiązuje w bieżącej sesji gry i domyślnie jest włączone.
- Zmiana tekstu lub języka rozpoczyna przeglądanie fragmentów od początku. Zwykłe odświeżenie nie zmienia pozycji.

Jeśli nie ma przechwyconej narracji Story, F1/F2/F3 obsługują dotychczasowe opisy ekranu. F4 nie wyłącza nawigacji menu ani poleceń QTE. Napisy dialogowe, specjalne cele walk i audiodeskrypcja filmów pozostają poza zakresem tej poprawki.

Przed podmianą DLL zamknij grę. Do sprawdzenia w Story: długi prolog, F2/F3, wyłączenie F4 przed kolejnym tekstem, ręczny odczyt F1 i powrót do menu.

## English

- Ctrl+Shift+F1 repeats captured Story text, including the chapter title and number.
- Ctrl+Shift+F2/F3 reads the next/previous narrative fragment with its position. Fragments contain up to 400 characters, preferring word and sentence boundaries. Navigation wraps around.
- Ctrl+Shift+F4 now controls automatic Story narration and chapter titles as well as descriptions. Muting preserves manual reading. This setting lasts for the current game session and defaults to on.
- New text or a language change resets fragment navigation. Identical redraws preserve the current position.

Without captured Story narration, F1/F2/F3 retain their existing description behavior. F4 does not disable menu navigation or QTE prompts. Dialogue subtitles, special battle objectives and cutscene audio description are outside this update.

Close the game before replacing the DLL. Live checks: a long prologue, F2/F3, disabling F4 before the next text, manual F1 reading and returning to menus.


# Tekken Accessibility 3.20.24 — Story text replay

## Polski

- Ctrl+Shift+F1 ponownie odczytuje ostatni przechwycony tekst prologu lub planszy fabularnej, dopóki ekran pozostaje aktywny.
- Identyczna treść na innym obiekcie ekranu lub w innym typie planszy nie jest już pomijana przez wspólną pamięć ostatniego tekstu.
- Zamknięcie bieżącego ekranu, rozpoczęcie ekranu i wyczyszczenie tekstu usuwają zapamiętaną narrację. Zwykłe odświeżenia identycznej treści pozostają ciche.

Dotyczy istniejących pól $prologue_text oraz $story. Nie dodaje audiodeskrypcji filmów ani rozpoznawania wszystkich specjalnych celów walki. QTE pozostaje przy wcześniejszym odczycie natywnych ikon; nie tłumaczy ich na własne przypisania klawiatury. Potrzebne są testy w grze: prolog epizodu, plansza fabularna, ponowny odczyt, powrót do menu i ponowne wejście.

Zamknij grę przed aktualizacją DLL. Wcześniejsze poprawki, w tym rewanże, pozostają dostępne.

## English

- Ctrl+Shift+F1 repeats the last captured prologue or story-panel text while its screen remains active.
- Identical text from a different screen object or narrative type is no longer suppressed by shared text deduplication.
- Closing the current screen, starting a screen or clearing the text discards the stored narrative. Identical redraws stay silent.

Applies to the existing $prologue_text and $story routes. This does not add cutscene audio description or recognition of every special battle objective. QTE retains its existing native icon announcements, without mapping custom keyboard bindings. Live checks are still needed for prologues, story panels, repeat reading, menu return and re-entry.

Close the game before updating the DLL. Earlier fixes, including revenge prompts, are retained.


# Tekken Accessibility 3.20.23

## Polski

Poprawiono odczytywanie znaczników koloru w pytaniu o rewanż. Zgłoszony komunikat „Request Revenge Match <font color = '#cc0000'>9</font> secs left, 1 z 4” jest teraz przekazywany do czytnika jako „Request Revenge Match 9 secs left, 1 z 4”. Liczba oznacza pozostały czas, nie nick gracza.

Usuwanie sparowanych znaczników font/color działa przed wysłaniem mowy do NVDA i Tolk, również dla komunikatów dopisywanych do kolejki. Nie zmienia tekstu wyświetlanego przez grę. Zachowuje liczby, treść komunikatu i zwykłe nazwy z nawiasami kątowymi. Obejmuje odczyt używany w Ranked i Quick Match; wymaga potwierdzenia obu trybów w grze.

Zamknij grę przed podmianą TekkenAccessibility.dll. Zachowano funkcje wersji 3.20.22.

## English

Fixed color markup being spoken in the revenge-match prompt. The reported text is now sent to the screen reader as “Request Revenge Match 9 secs left, 1 z 4”, without the font tags. The number is the countdown, not a player name.

Paired font/color tags are removed before speech reaches NVDA or Tolk, including appended speech. The game's display is unchanged. Numbers, message content and ordinary angle-bracket names are preserved. This covers the speech path used by Ranked and Quick Match; both modes still need live confirmation.

Close the game before replacing TekkenAccessibility.dll. Version 3.20.22 features are retained.


# Tekken Accessibility 3.20.22 — combat speech controls

## English

- Ctrl+Shift+F10 now reads a short distance and side summary. Add Alt for the full coordinates.
- Ctrl+Shift+Alt+F12 toggles automatic down-state announcements. The setting lasts for the current game session and defaults to on. Ctrl+Shift+F12 still reads combat status.
- Automatic side and down-state readers discard pending observations when the game loses focus, preventing an old transition from being announced on return.
- English and Polish speech remain available through Ctrl+L.

Distance uses the game's native position scale; it is not a claim about attack range or metres. Leaving the down state does not necessarily mean standing up.

These changes improve existing combat readers. Wall proximity, throw-break cues, attack height and complete combat audio guidance are not implemented in this release. Full accessibility is not yet verified; live testing with a screen reader is still required.

Close the game before updating TekkenAccessibility.dll in TekkenGame/Binaries/Win64. Keep a backup of your previous DLL.

## Polski

- Ctrl+Shift+F10 odczytuje krótką informację o odległości i stronach. Dodanie Alt odczytuje pełne współrzędne.
- Ctrl+Shift+Alt+F12 włącza lub wyłącza automatyczne komunikaty powalenia. Ustawienie obowiązuje do zamknięcia gry; domyślnie komunikaty są włączone. Ctrl+Shift+F12 nadal odczytuje stan walki.
- Czytniki zmiany stron i powalenia usuwają oczekujące obserwacje po opuszczeniu okna gry, aby nie ogłaszać starej zmiany po powrocie.
- Ctrl+L nadal przełącza odczyt polski i angielski.

Odległość korzysta z natywnej skali pozycji gry. Nie oznacza metrów ani zasięgu ciosu. Zakończenie stanu powalenia nie musi oznaczać stania.

Ta wersja usprawnia istniejące czytniki walki. Nie dodaje wykrywania bliskości ściany, podpowiedzi zrywania rzutów, wysokości ataków ani pełnego prowadzenia dźwiękiem podczas walki. Pełna dostępność pozostaje niepotwierdzona; potrzebne są testy w grze z czytnikiem ekranu.

Przed aktualizacją zamknij grę i zachowaj kopię starej DLL. Nową TekkenAccessibility.dll skopiuj do TekkenGame/Binaries/Win64.


# Ekrany wczytywania — 3.20.21

- Główna zapowiedź VS pobiera klucze nazw przez natywny resolver postaci gry (ten sam, którego używa Makuai), zamiast ręcznej tabeli nazw. Nieudane odczyty nie wypowiadają kluczy technicznych.
- Odczyt zapasowy rozróżnia pola $playername_L i $playername_R. Dwa odświeżenia tej samej strony nie tworzą już fałszywej pary. Zachowano walki lustrzane i kolejność lewa/prawa, również gdy pola dotrą w odwrotnej kolejności.
- Tworzenie nowego Makuai resetuje pamięć pary, nawet gdy gra ponownie używa tego samego adresu. Prawidłowe dane przeciwnika przekazywane z listy Online są zachowane.
- Dodano obsługę rzeczywistego zakończenia Makuai_mc / End, którego gra nie wysyła obserwowaną wcześniej ścieżką _root / End. Powiązane oczekujące komunikaty i strony pary są czyszczone.
- Nowa obsługa zakończenia wymaga jednego dodatkowego podłączenia pod 004557F0. Działa wyłącznie dla potwierdzonego wywołania 004D53EA i właściwej ścieżki/stanu. Liczba aktywnych podłączeń wzrosła z 48 do 49; instalator wycofuje nowe podłączenie, jeśli instalacja głównego czytnika Makuai się nie powiedzie.
- Zachowano poprawki Online 3.20.20, Customization 3.20.19 i oba języki.


# Poprawki Online — 3.20.20

- Zaznaczony wiersz bez danych postaci nie jest już zastępowany innym wierszem. Automatyczny wybór pojedynczego przeciwnika działa tylko przed pierwszym zdarzeniem kursora. Jawne unieważnienie kursora także wyłącza taki wybór.
- Odczyt postaci czeka na zakończenie budowania wierszy. Pusta lub niejednoznaczna lista czyści poprzedniego przeciwnika tej samej rodziny ekranów.
- Zapowiedź VS jest usuwana po utracie fokusu i po zamknięciu jej ekranu. Wygasa po 5 sekundach od zakolejkowania. Dotychczasowe opóźnienie 1,1 sekundy pozostaje.
- Zamknięcie źródłowej listy usuwa zapasową pamięć przeciwnika, lecz zachowuje poprawną parę już odczytaną bezpośrednio z ekranu VS. Zamknięcie starego VS nie usuwa nowszego przeciwnika z kolejnej listy.
- Zamknięcie VS pozwala ponownie odczytać identyczną parę, jeśli kolejny ekran użyje tego samego adresu pamięci.
- Wspólny stan czytnika VS jest chroniony mutexem. Gra i wątek mowy nie modyfikują równocześnie tego samego tekstu. Wywołania mowy pozostają poza blokadą.
- Nie dodano adresów gry ani nowych podłączeń. Zachowano poprawki Customization 3.20.19 i oba języki.


# Customization — wersja 3.20.19

- Dodano odczyt Copy/Delete oraz właściwego kursora miejsca docelowego kopiowania (zdarzenie 22). Stara obsługa błędnie korzystała z kursora zwykłych slotów (18).
- Dodano odczyt palety: 72 próbki w siatce 8×9, współrzędne gradientu, 15 zapisanych kolorów i numer obszaru kolorowania.
- Nowe komunikaty działają po polsku i angielsku (Ctrl+L).
- Funkcja gry przekazuje tylko liczby do czytnika. Nowa mowa jest wykonywana przez istniejący wątek dostępności po powrocie z funkcji gry. Powtórzenia są pomijane; szybkie ruchy łączą się w ostatnią pozycję z maksymalnym oczekiwaniem 200 ms przy regularnym odpytywaniu.
- Zamknięcie palety, zmiana właściciela ekranu, utrata fokusu i zbyt stary komunikat usuwają oczekujący odczyt. Nie zakładamy pozycji pierwszego koloru przed otrzymaniem danych gry.

## Pozostałe ograniczenia

Pozycja próbki nie jest nazwą koloru. Nie odczytujemy jeszcze zweryfikowanych RGB/HSV ani nazw kolorów. Zapowiedź Copy/Delete oznacza zaznaczoną opcję, a nie potwierdzenie wykonania operacji. Ogólne okna potwierdzeń pozostają obsługiwane przez dotychczasowy moduł. Pełny przebieg zapisu, kopiowania, usuwania i powrotów wymaga testu w grze z NVDA. Stary połączony moduł CharacterCustomizeSlotSelect nadal jest wyłączony.


## 3.20.18 — 2026-09-09

Naprawiono odczyt metadanych turniejów przy niezmienionym wierszu, sześć problemów testów audytu i obsługę błędów skryptu budowania. Dodano test rzeczywistych funkcji czytnika turniejów, zależności runtime i skrypt wydania wymagający poprawnych testów. Ograniczenia pełnej dostępności pozostają jawne.

## V3.20.17 SAFE — jakość połączenia i obszar w Tournament Session List — 2026-09-09

- Bazą jest live-potwierdzone V3.20.16. Online/Offline VS, szybkie Pause Menu, ULTIMATE TEKKEN BOWL, nazwy graczy Online i Character Customization pozostają bez zmian.
- Sweep Online znalazł użyteczny brak w Tournament Session List, który można uzupełnić bez nowego hooka: zaznaczony wiersz nie podawał jakości połączenia ani obszaru z ikon gry.
- `tekken.zip` potwierdza natywny model rekordów listy turniejów. `self+0x480` to liczba rekordów, `self+0x484` to absolutny zaznaczony rekord (gra używa go również bezpośrednio pod `0x004F07C4` przy wejściu do wybranej sesji), `self+0x510` to tablica rekordów, a stride jednego rekordu wynosi `0xE0`.
- Jakość połączenia jest czytana z `record+0x28`, dokładnie jak robi to gra pod `0x004F2D87` (natywne 0..5 => `Jakość połączenia 1..6 z 6`). Obszar jest czytany z `record+0xA8`, dokładnie jak gra pod `0x004F378B` (natywne 1..8 => `Obszar 1..8 z 8`).
- Wykorzystany zostaje istniejący hook kursora Tournament pod `0x004F02B0`. Przy każdym natywnym callbacku kursora mod odświeża wyłącznie ikonowe dane zaznaczonego wiersza; działa to również podczas przewijania, gdy widoczny kursor pozostaje na skrajnym wierszu, ale zmienia się rekord absolutny.
- Wszystkie odczyty natywne są zabezpieczone przez `ReadProcessMemory`. Nieprawidłowy owner/count/index/wskaźnik/zakres czyści lub pomija dane zamiast przenosić stare wartości albo zgadywać.
- Statusy członków pokoju `Loading / Stand / Battle / Pause` pozostają celowo nietknięte: potwierdzony helper `0x0050EBF0` opisuje tylko dwa specjalne sloty statusu i nie dowodzi mapowania 1:1 dla wszystkich sześciu członków pokoju Player Match.
- Nie dodano hooka ani wątku. `Patch::Install` pozostaje `43`, liczba wywołań Rel8 pozostaje `1`, a `InitThread` pozostaje na `36` instalacjach. Nazwane definicje i wartości RVA/OFF są identyczne z V3.20.16.
- Regresja portable: **71 PASS, 0 FAIL**; 5 testów Windows/MSVC uruchamia builder.

## V3.20.16 SAFE — postacie na ekranie VS we wszystkich walkach Offline — 2026-09-09

- Bazą jest live-potwierdzone V3.20.15. Szybkie Pause Menu, Online VS, ULTIMATE TEKKEN BOWL, Online nicki i Character Customization pozostają bez zmian.
- Przyczyna braku odczytu Offline była konkretna: istniejący hook `SwfMakuai` `0x004D55F0` odczytywał natywne ID z `self+0x110` i `self+0x1D8`, ale cały detour był objęty warunkiem `OnlineVersusLoadingReader::IsOnlineMode()`. W Offline bezpośrednia para była więc odrzucana.
- `tekken.zip` potwierdza, że helper `0x004D55F0` należy do wspólnej inicjalizacji `SW_UI_Makuai`: w `.text` istnieje dokładnie jedno wywołanie do tego helpera, z `0x004D42F7`. W środku helpera pętla czyta pierwsze ID z `self+0x110`, zwiększa stronę o `0xC8` i czyta drugie z `self+0x1D8`.
- V3.20.16 usuwa tylko bramkę „Online only”. Ten sam już zainstalowany hook zbiera teraz parę postaci również dla Arcade/Practice/Treasure i pozostałych walk korzystających z `SW_UI_Makuai`.
- Para nadal korzysta z istniejącego opóźnienia `1100 ms` i formatu z pauzą zdaniową, np. `Lili. Kontra Kazuya.`, aby NVDA zdążyło ją przeczytać.
- Gdy bezpośredni Makuai już rozpozna właściciela ekranu, stary szybki collector V3.20.9 jest blokowany dla tego samego ownera, więc nie ma podwójnej mowy. Fallback pozostaje dla nieoczekiwanej ścieżki, której helper bezpośredni nie zobaczy.
- Nie dodano hooka ani wątku. `Patch::Install` pozostaje `43`, Rel8 `1`, `InitThread` `36`.
- Regresja portable: **69 PASS, 0 FAIL**; 5 testów Windows/MSVC uruchamia builder.

## V3.20.15 SAFE — szybkie Pause Menu we wszystkich potwierdzonych trybach — 2026-09-09

- Bazą jest live-potwierdzone V3.20.14. Online VS, ULTIMATE TEKKEN BOWL, Online nicki, offline VS oraz Character Customization pozostają bez zmian.
- `tekken.zip` potwierdza, że normalny ruch kursora `SwfPauseMenu` we wszystkich wariantach przechodzi przez ten sam natywny `Select`: wywołanie settera animacji `RVA 0x00453950` z returnem `0x004F4AD1`.
- Rozszerzono istniejącą natychmiastową ścieżkę Treasure na wszystkie tryby z potwierdzoną natywną tabelą kursor→akcja: mode 0 `0x02845B48` (8), mode 1 `0x02845B68` (6), mode 2 `0x02845B80` (8), mode 3 `0x02845BA0` (8), mode 4 `0x02845BC0` (8), mode 5 `0x02845BE0` (4), mode 6 `0x02845BF0` (6), mode 8 `0x02845C08` (4).
- Pozycja jest wypowiadana **przed** oryginalną animacją Scaleform, więc NVDA nie czeka na zakończenie dużej funkcji Pause Menu ani redraw wybranego wiersza.
- Mode 7 celowo pozostaje na starym fallbacku: natywny helper `0x004F3F20` dla mode 7 nie używa tabeli kursor→akcja, więc mod nie zgaduje mapowania.
- Nie dodano hooka ani wątku. `Patch::Install` pozostaje `43`, Rel8 `1`, `InitThread` `36`.
- Regresja portable: **67 PASS, 0 FAIL**; 5 testów Windows/MSVC uruchamia builder.

## V3.20.14 SAFE — spokojniejszy odczyt postaci na Online VS — 2026-09-09

- Bazą jest live-potwierdzone V3.20.13. Bezpośredni odczyt obu natywnych ID postaci z `SwfMakuai` pozostaje bez zmian.
- Para postaci nie jest już wypowiadana natychmiast wewnątrz hooka Makuai. Jest zapisywana do małej kolejki i przekazywana przez **istniejący worker dostępności** po `1100 ms`, gdy pierwszy redraw ekranu VS zdąży się uspokoić.
- Komunikat ma teraz wyraźną pauzę zdaniową, np. `Lili. Kontra Kazuya.` zamiast szybkiego `Lili kontra Kazuya`.
- Późniejsze `$playername_L/$playername_R` nadal są blokowane jako nicki kont i nie mogą uruchomić starego fallbacku przeciwnika po wykryciu bezpośredniej pary.
- Nie dodano hooka ani wątku. `Patch::Install` pozostaje `43`, Rel8 pozostaje `1`, a `InitThread` pozostaje przy `36` instalacjach.
- Online nicki, ULTIMATE TEKKEN BOWL, Treasure Pause, offline VS i Character Customization pozostają bez zmian.
- Regresja portable: **65 PASS, 0 FAIL**; 5 testów zależnych od Windows/MSVC pozostaje do uruchomienia przez builder.

## V3.20.13 SAFE
- Online VS/loading odczytuje obie postacie bezpośrednio z natywnego `SwfMakuai`.
- Jeden izolowany hook `0x004D55F0`; ID postaci: `self+0x110` i `self+0x1D8`.
- Cache V3.20.12 pozostaje jako fallback.
- Bowl, Pause, Online nicki i Customization bez zmian.

## 3.20.12 — SAFE: postać przeciwnika na ekranie Online VS / wczytywania — 2026-09-09

- Bazą jest live-potwierdzone V3.20.11; działające Treasure Pause, ULTIMATE TEKKEN BOWL, Online names, offline VS oraz Character Customization pozostają bez zmian.
- Online VS nie korzysta z nicków `$playername_L/$playername_R` jako nazw postaci. Te pola są traktowane wyłącznie jako sygnał wejścia w natywny ekran Makuai.
- Istniejące czytniki Ranked/Quick Match i Player Match przekazują do małego cache wyłącznie natywnie odczytaną, już zlokalizowaną nazwę postaci przeciwnika.
- Gdy istnieje potwierdzony zaznaczony wiersz, używana jest jego postać. Quick/automatyczny matchmaking może użyć jedynego dostępnego kandydata; przy wielu kandydatach bez zaznaczenia mod milczy zamiast zgadywać.
- Na ekranie Online VS NVDA mówi raz np. `Przeciwnik: Kazuya`. Powtórny redraw tego samego właściciela Makuai jest tłumiony.
- Nie dodano nowego hooka ani wątku; funkcja korzysta z już istniejących czytników Online i wspólnego settera Makuai.

## 3.20.11 — SAFE: Treasure Battle pause przed animacją Scaleform — 2026-09-09

- Naprawiono dalsze opóźnienie NVDA przy szybkim poruszaniu kursorem w menu pauzy Treasure Battle.
- `tekken.zip` potwierdza, że po zmianie kursora gra wywołuje globalny setter animacji `RVA 0x00453950` z `Select` w `0x004F4ACC` (return `0x004F4AD1`). V3.20.10 wypowiadało pozycję dopiero po powrocie z tego settera.
- V3.20.11 dla dokładnego `Treasure mode 4 + Select + 0x004F4AD1` wypowiada nową pozycję **przed** wykonaniem oryginalnej animacji Scaleform. Pozostałe ścieżki globalnego hooka zachowują dotychczasową kolejność.
- Nie zmieniono tabeli akcji `RVA 0x02845BC0`, mapowania tekstów ani starego PauseMenu fallback.
- Brak nowych hooków, brak nowych wątków; Bowl, Online, VS i Customization bez zmian.

## 3.20.10 — SAFE: natychmiastowy kursor pauzy Treasure Battle — 2026-09-09

- Test w grze wykazał, że w Treasure Battle menu pauzy nadal reagowało z opóźnieniem podczas szybkiego przewijania. Stary czytnik `PauseMenu` mówił dopiero po zakończeniu dużej natywnej funkcji wejścia `RVA 0x004F4A00`.
- `tekken.zip` potwierdza, że po zmianie kursora wybrany wiersz wywołuje już istniejący globalny setter animacji `RVA 0x00453950`; dokładny return po natywnym stanie `Select` to `0x004F4AD1`.
- Dla Treasure Battle (`mode 4`) V3.20.10 odczytuje akcję natychmiast z natywnej tabeli gry kursor→akcja `RVA 0x02845BC0`, zanim gra później zaktualizuje `self+0x460`. Dzięki temu NVDA reaguje na sam ruch kursora, a nie dopiero po zakończeniu całej obsługi pauzy.
- Stara ścieżka `PauseMenu` pozostaje jako fallback. Bezpośrednia ścieżka zapisuje ten sam stan do cache, więc późniejszy fallback nie powtarza wypowiedzi.
- Zmiana jest ograniczona do Treasure Battle. Online, ULTIMATE TEKKEN BOWL, ekran VS/loading oraz działające Character Customization nie zostały zmienione.
- Nie dodano nowego hooka ani wątku. `Patch::Install` pozostaje 42, Rel8 pozostaje 1, a `InitThread` nadal ma 35 wywołań `::Install()`.
- Regresja portable: 57 PASS, 0 FAIL; 5 testów Windows-only pozostaje do uruchomienia w MSVC.

## 3.20.9 — SAFE: nazwy obu postaci na ekranie VS / wczytywania walki — 2026-09-09

- Bazą kodu jest potwierdzone live V3.20.8. Działające ULTIMATE TEKKEN BOWL, Online oraz Character Customization pozostają bez zmian.
- Jedynym źródłem danych gry jest `tekken.zip` (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- `tekken.zip` potwierdza, że ekran `SW_UI_Makuai` pobiera ID postaci z `Makuai + side*0xC8 + 0x110`, wywołuje resolver nazw przy `0x004D45FD`, lokalizację przy `0x004D460C`, a gotową nazwę wyświetlaną wysyła przez już hookowany wspólny setter `0x00458250`. Dokładny return tego wywołania VS to `0x004D4646`.
- V3.20.9 korzysta wyłącznie z tego istniejącego hooka setterowego. Zbiera dwie końcowe, zlokalizowane nazwy postaci i raz wypowiada parę, np. `Lili kontra Kazuya`.
- Nie zgadujemy, która strona ekranu jest lokalnym graczem; zachowujemy kolejność wyświetlaną przez grę. Dzięki temu działa także mirror match, np. `Lili kontra Lili`.
- Powtórny redraw tej samej pary w tym samym filmie Scaleform jest tłumiony.
- Nowe hooki: 0. Nowe wątki: 0. Pełny problematyczny `CharacterCustomizeSlotSelect::Install()` pozostaje nieuruchamiany.
- Regresja portable: 55 PASS, 0 FAIL; 5 testów Windows-only pozostaje do MSVC.
- Wersja publiczna: V3.20.9.

## 3.20.8 — SAFE: bezpośrednie czytanie natywnego kursora ULTIMATE TEKKEN BOWL — 2026-09-09

- Bazą kodu jest stabilne V3.20.7. Online celowo pozostaje bez zmian, ponieważ live test potwierdził, że działa. Jedynym źródłem danych gry pozostaje `tekken.zip` (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Live test wykazał, że V3.20.7 nadal reaguje zbyt wolno w ULTIMATE TEKKEN BOWL. Głównym opóźnieniem nie było 3 ms scalania mowy: stara ścieżka Bowl czekała, aż późniejszy redraw button-help/HUD w ogóle dostarczy tekst do wypowiedzenia.
- `tekken.zip` potwierdza, że `SwfBowlingMenu` zmienia kursor głównego menu przez już hookowany setter animacji `RVA 0x00453950`; wywołanie zaznaczonej pozycji wraca pod `0x0045A74A` ze stanem `Select`. Podmenu korzysta z tego samego settera i wraca pod `0x0045A7FA`.
- V3.20.8 wypowiada więc zaznaczoną pozycję Bowl bezpośrednio z tego natywnego eventu `Select`. Nie czeka na `DescriptionRuntime`, rytm workera 40 ms, 3 ms settle ani późniejszy redraw button-help.
- Nazwy nie są zgadywane. Są cache'owane z już hookowanego wspólnego renderera tekstu gry `RVA 0x004570E0`: etykiety główne wracają pod `0x0045BCAE`, a zweryfikowane gałęzie etykiet podmenu pod `0x0045A95D` i `0x0045AAAD`. Pola towarzyszące `$MainN_Glow` / `$SubN_Glow` są celowo ignorowane.
- Nie dodano nowego hooka ani wątku. Pięć nowych RVA to wyłącznie filtry callerów wewnątrz dwóch już istniejących globalnych hooków, a nie nowe miejsca patchowania. Żaden istniejący RVA/OFF nie został zmieniony.
- Podczas bezpośredniego ruchu kursora stare oczekujące wypowiedzi Bowl są porzucane, a najnowszy wtórny redraw button-help jest odkładany do chwili zatrzymania kursora, żeby nie mógł przerwać świeżo zaznaczonej pozycji. Podstawowe informacje Bowl o graczu/HUD nadal działają.
- Działające Online z V3.20.7 oraz działające Character Customization z czytaniem postaci i slotów pozostają bez zmian.
- Regresja portable: 53 PASS, 0 FAIL; 5 testów Windows-only pozostaje do MSVC.
- Wersja publiczna: V3.20.8.

## 3.20.7 — SAFE: Quick Match bez `online_other_088` i natychmiastowa reakcja Ultimate Tekken Bowl — 2026-09-09

- Bazą kodu jest stabilne V3.20.6. Jedynym źródłem danych gry pozostaje `tekken.zip` (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Live test wykazał, że Quick Match nadal potrafił wypowiedzieć wewnętrzny identyfikator `online_other_088`. V3.20.7 blokuje nierozwiązane `online_other_###` na końcowej warstwie `T7Speech`, więc taki techniczny klucz nie może już trafić do NVDA/Tolk.
- Natywne końcowe pola nazw `$playername_l` i `$playername_r` korzystają teraz z tego samego `OnlinePlayerText::RawName`, co pozostałe naprawione pola graczy. Tymczasowy `online_other_###` nie jest zapisywany do cache jako nick; następny prawdziwy nick nadal może zostać wypowiedziany natychmiast.
- Bezpośrednie odczyty natywnego obiektu `std::string` Online również przechodzą przez `RawName`, a pole gracza w Player Match Session Room ignoruje tymczasowy placeholder zamiast nadpisywać nim prawdziwą nazwę.
- Ultimate Tekken Bowl nie czeka już na następny 40-ms polling istniejącego wątku i dodatkowe 20 ms debounce. `BowlNavigationReader::Put()` budzi ten sam istniejący worker przez `condition_variable`; po tylko 3 ms na scalenie zapisów tego samego redraw od razu wypowiadana jest najnowsza pozycja.
- Nie dodano nowego wątku ani hooka. Gdy Bowl nic nie publikuje, normalny rytm pozostałej dostępności nadal ma maksymalny timeout 40 ms.
- Stabilne Character Customization pozostaje bez zmian: pełny `CharacterCustomizeSlotSelect::Install()` ma nadal 0 wywołań, a `CharacterCustomizeCharacterCursorSafe::Install()` dokładnie 1.
- Audit produkcyjny względem V3.20.6: `Patch::Install` 42 -> 42, Rel8 1 -> 1, `InitThread` 35 -> 35; 0 dodanych, usuniętych lub zmienionych nazwanych adresów RVA/OFF.
- Regresja portable: 51 PASS, 0 FAIL; 5 testów Windows-only pozostaje do uruchomienia przez MSVC.
- Wersja publiczna: V3.20.7.

## 3.20.6 — SAFE: szybsze przewijanie Ultimate Tekken Bowl i prawdziwe nazwy graczy Online — 2026-09-09

- Bazą kodu jest stabilne V3.20.5. Jedynym źródłem danych gry jest `tekken.zip` (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Ultimate Tekken Bowl nie wysyła już kilku synchronicznych wypowiedzi NVDA z jednego szybkiego redraw. Istniejące natywne pola pomocy i danych gracza publikują tylko najnowszą wartość do małego bufora `latest wins`, a już istniejący 40-ms wątek dostępności wykonuje właściwą mowę. Szybkie przewijanie porzuca starsze oczekujące pozycje.
- Nie dodano żadnego hooka do kręgli. Zmieniono wyłącznie sposób dostarczania mowy z już obsługiwanych natywnych callerów, a cache jest czyszczony przy prawdziwej zmianie ownera/ekranu.
- Naprawiono rozdzielenie nicków Online od lokalizacji. Pola `$PlayerName...` / `$HostPlayerName...` zawierają końcowe nazwy kont i nie są już przepuszczane przez resolver językowy. Nierozwiązane identyfikatory UI typu `online_other_083` nie są wypowiadane jako nazwa gracza.
- `tekken.zip` potwierdza trzy bezpośrednie źródła prawdziwych nazw: Ranked Match MatchList — natywny `std::string` `record+0x08`, setter return `0x0052812F`; Player Match search rooms — host `record+0x78`, setter return `0x0050D15C`; Player Match Session Room — członek pokoju `record+0x10`, setter return `0x0050F3B4`.
- Te trzy pola są odczytywane wewnątrz już istniejących hooków wierszy/kursora. Nie ma nowego hooka, nowego RVA ani zmiany istniejącej wartości adresu gry.
- Stabilna ścieżka Character Customization z V3.20.5 pozostaje bez zmian: `CharacterCustomizeSlotSelect::Install()` nadal ma 0 wywołań, a `CharacterCustomizeCharacterCursorSafe::Install()` dokładnie 1.
- Audit: `Patch::Install` 42 -> 42, Rel8 1 -> 1, nazwane RVA/OFF 574 -> 574; 0 dodanych, 0 usuniętych, 0 zmienionych wartości.
- Regresja portable: 49 PASS, 0 FAIL; 5 testów Windows-only pozostaje do uruchomienia przez MSVC.
- Wersja publiczna: V3.20.6.

## 3.20.5 — SAFE: odczyt slotów stroju w Character Customization przez działający hook V3.20.4 — 2026-09-09

- Bazą kodu jest stabilne live V3.20.4. Jedynym źródłem danych gry dla tej zmiany jest `tekken.zip` (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`).
- Nie dodano nowego hooka. Już działający `CharacterCustomizeCharacterCursorSafe` na `RVA 0x0046DF20` dostał tylko jedną dodatkową, ściśle filtrowaną obsługę natywnego eventu `18`.
- `tekken.zip` potwierdza, że event `18` trafia do `RVA 0x0046E788`, przesuwa `CharaSlot_Select_mc.Cursor_mc` i po oryginalnym dispatcherze zapisuje kolumnę/wiersz slotu do `self+0xB8` / `self+0xBC`.
- Ten sam EXE potwierdza układ `5 x 2`: natywny kod wylicza slot jako `column + 1 + 5*row`. Konstruktor tworzy `Slot_01..Slot_10`, pola `$slot_01..$slot_10` i mapuje je odpowiednio na `chasel_msg_002..chasel_msg_011`.
- Nowa ścieżka wypowiada wyłącznie natywną lokalizację zaznaczonego slotu. Nie uruchamia `PaletteReader`, Copy/Delete, `NavigationContext` ani pełnego `CharacterCustomizeSlotSelect`.
- `CharacterCustomizeSlotSelect::Install()` nadal ma 0 wywołań w `InitThread`; bezpieczny hook ma dokładnie 1 instalację.
- `Patch::Install` pozostaje 42, Rel8 pozostaje 1; nazwane RVA/OFF: 0 dodanych, 0 usuniętych, 0 zmienionych wartości.
- Regresja portable: 47 PASS, 0 FAIL; 5 testów Windows-only pozostaje do uruchomienia przez MSVC.
- Wersja publiczna: V3.20.5.

## 3.20.4 — HOTFIX: przywrócenie odczytu postaci w Character Customization bez pełnego modułu slotów — 2026-09-09

- Punkt odniesienia to działające live V2.88: nazwa zaznaczonej postaci była wypowiadana z natywnego dispatchera Character Customization `0x0046DF20`.
- V3.20.4 NIE włącza ponownie `CharacterCustomizeSlotSelect::Install()`. Pełna późniejsza ścieżka palety, slotów, copy/delete i `NavigationContext` pozostaje odłączona po regresjach blokujących sterowanie.
- Dodano osobny `CharacterCustomizeCharacterCursorSafe`, który na tym samym zweryfikowanym RVA wywołuje najpierw oryginalny dispatcher, a potem obsługuje wyłącznie eventy `1`, `2` i zweryfikowany ruch kursora `6`. Event `5` oraz cała logika palety/slotów są pomijane.
- `tekken(4).zip` potwierdza, że event `6` trafia do RVA `0x0046E2DA`, przesuwa `Character_Select_mc.Cursor_mc` i zapisuje kolumnę/wiersz do `self+0xB0` / `self+0xB4`.
- Naprawiono ważny błąd cache: ponowne batchowe wypełnienie `$chara_name_00` w tym samym `movie` może odświeżyć tablicę nazw, ale nie czyści już `gLastCharacter`. Dzięki temu identyczna postać nie jest ponownie uzbrajana do mowy przy każdym redraw.
- Pozostałe moduły Customization pozostają aktywne jak w V3.20.3. Pełny moduł slotów nadal pozostaje w źródłach do późniejszego, powolnego przywracania element po elemencie.
- Dodano `test_v3204_customization_character_restore.cpp`.
- Wersja publiczna: V3.20.4.

## 3.20.3 — HOTFIX: pełny rollback blokującego observera Character Customization — 2026-09-09

- Live test V3.20.2 wykazał ponownie całkowitą blokadę sterowania po wejściu do Character Customization. Minimalny observer oparty na dispatcherze `0x0046DF20` nie jest bezpieczny nawet bez bezpośredniej mowy NVDA/Tolk.
- V3.20.3 całkowicie usuwa produkcyjny `CharacterCustomizeCharacterCursor` dodany w V3.20.2 i przywraca ścieżki `TekkenAccessibility.cpp`, `FocusedUi.h` oraz `DescriptionRuntime.h` do dokładnie działającego zachowania V3.20.1.
- `CharacterCustomizeSlotSelect::Install()` nadal pozostaje wyłączone. Nie jest instalowany żaden dispatcher-observer postaci ani slotów w Character Customization.
- Pozostałe moduły Customization nadal są aktywne: liczba przedmiotów, zaznaczony przedmiot, kategorie i rzadkość/stany UI.
- Hotfix nie dodaje żadnego hooka, RVA ani OFF. W kodzie produkcyjnym liczba `Patch::Install` wraca do stanu V3.20.1.
- Odczyt nazwy postaci pozostaje celowo wyłączony do czasu znalezienia sygnału, który nie przechodzi przez blokujący dispatcher. Stabilne sterowanie ma pierwszeństwo.
- Dodano `test_v3203_customization_observer_rollback.cpp`, który pilnuje obu zakazanych instalatorów oraz zachowania pozostałej dostępności Customization.
- Wersja publiczna: V3.20.3.

## 3.20.2 — HOTFIX: odczyt postaci w Character Customization bez przywracania blokady — 2026-09-09

- Live test V3.20.1 potwierdził, że wyłączenie `CharacterCustomizeSlotSelect::Install()` naprawia sterowanie, ale jednocześnie usuwa jedyny aktywny sygnał wywołujący odczyt zaznaczonej postaci.
- `CharacterCustomizeSlotSelect::Install()` nadal pozostaje wyłączone. V3.20.2 dodaje osobny minimalny `CharacterCustomizeCharacterCursor`, który ponownie wykorzystuje wcześniej zweryfikowany dispatcher `RVA 0x0046DF20`.
- `tekken(4).zip` potwierdza natywne eventy: `5` ustawia `Character_Select_mc.Cursor_mc` w stan `Normal_Select`, a `6` przesuwa ten kursor i zapisuje kolumnę/wiersz do `self+0xB0/self+0xB4`. Observer przyjmuje wyłącznie eventy `1/2/5/6`.
- Detour observera nie wywołuje NVDA/Tolk i nie uruchamia logiki palety, slotów, kopiowania ani usuwania. Wybrana nazwa jest tylko kolejkowana, a istniejący runtime dostępności odbiera ją poza wątkiem dispatchera gry.
- Nazwy postaci nadal pochodzą wyłącznie z natywnego `$chara_name_%02d` przy callerze `0x00472E1F`; nie dodano zgadywanych nazw ani nowej wartości adresu gry.
- Dodano `test_v3202_customization_character_cursor.cpp`; regresja V3.20.1 nadal sprawdza, że slotowy installer nie wrócił.
- Wersja publiczna: V3.20.2.

## 3.20.1 — HOTFIX: wyłączenie blokującego hooka slotów Character Customization — 2026-09-09

- Live test V3.20 wykazał, że po wejściu do Character Customization sterowanie może zostać całkowicie zablokowane.
- Wyłączono wyłącznie wywołanie startowe `CharacterCustomizeSlotSelect::Install()`. Kod modułu pozostaje w źródłach, ale jego hook event dispatch nie jest instalowany przy uruchomieniu moda.
- Pozostała dostępność Customization pozostaje aktywna: liczba przedmiotów, wybrany przedmiot, kategorie oraz rzadkość/stany UI nadal wywołują swoje istniejące instalatory.
- Nie dodano nowego hooka, RVA ani OFF i nie zmieniono żadnej wartości adresu gry. Hotfix nie korzysta z żadnego nowego źródła danych gry.
- Dodano regresję `test_v3201_customization_slot_hotfix.cpp`, która sprawdza rzeczywistą funkcję `InitThread` i pilnuje, aby wyłączony był tylko ten jeden instalator.
- Wersja publiczna: V3.20.1.

## 3.20 — VERY HUGE: globalna ochrona mowy przed pętlami i zweryfikowana nawigacja Create Session — 2026-09-08

- Dodano centralną warstwę ochronną przed lawiną powtórzeń za każdym wejściem do NVDA/Tolk. Dwie szybkie identyczne wypowiedzi po renderowaniu są dozwolone; trzecia i kolejne identyczne próby są tłumione, dopóki trwa ten sam strumień aktywności. Inny tekst albo ponad 1,5 sekundy ciszy ponownie uzbraja tę samą wypowiedź.
- Guard jest celowo ostatnią barierą bezpieczeństwa backendu. Istniejące semantyczne cache poszczególnych ekranów nadal są nadrzędne, w tym naprawa Character Customization z V3.10.1.
- Domknięto kontekst pozycji Player Match Create Session wyłącznie z już potwierdzonego natywnego stanu: 11 wybieralnych pozycji to `Panel0..Panel9` plus natywny przycisk akcji, a istniejący hook kursora odczytuje zaznaczony indeks. Zwykłe wiersze, przycisk akcji i natywny początkowy panel 0 mówią teraz `X z 11`.
- Dodano `SpeechRepeatGuard.h`, `test_v320_speech_repeat_guard.cpp` oraz `test_v320_navigation_completion.cpp`.
- Nie dodano nowego hooka ani nie dodano/zmieniono żadnej wartości RVA/OFF gry. Niepotwierdzone owner/state walki, wall distance, prawdziwe RGB/HSV/nazwy kolorów palety, anonimowe znaczenia glyphów poleceń oraz niejednoznaczne stany graczy Online pozostają bez zgadywania.
- Publiczna wersja przechodzi z V3.10.1 do V3.20 jako kolejny duży milestone.
- Finalna regresja portable: 42 PASS, 5 testów Windows-only pominiętych w tym środowisku, 0 FAIL.

## 3.10.1 — HOTFIX: zapętlenie NVDA w Character Customization — 2026-09-08

- Jest to celowy awaryjny hotfix do V3.10, ponieważ live test wykazał blokujący regres: Character Customization potrafiło zasypywać NVDA powtarzaną mową tak szybko, że nie dało się normalnie sterować ekranem. Następny zwykły milestone pozostaje dużym V3.20 VERY HUGE.
- Usunięto błędne używanie adresu `self` gorących rendererów Customization jako ownera czasu życia cache. Zmiana/recykling tych obiektów nie może już sama zwiększać `generation` i ponownie uzbrajać tej samej wypowiedzi przy redraw.
- `CharacterCustomizeItemCount` zwiększa generację wyłącznie przy rzeczywistej zmianie natywnego indeksu/liczby elementów. `CharacterCustomizeSelectedItem` robi to wyłącznie przy zmianie wybranego iconu lub natywnego stanu przedmiotu.
- Kategorie i siatka slotów stroju nie czyszczą już deduplikacji tylko dlatego, że zmienił się pointer `self` callbacku. Zachowane są natywne indeksy, nazwy i kontekst `X z Y`.
- Powtarzany event Start/re-entry `1/2` na tej samej instancji Scaleform nie czyści już `gLastCharacter`/cache przed każdym redraw. Prawdziwa zmiana `movie` nadal uzbraja świeży ekran.
- Hook resolvera nazw postaci pozostaje zainstalowany i byte-verified, ale nie wypowiada już nazw podczas batchowego wypełniania `$chara_name_%02d`. Właściwa zaznaczona postać nadal jest wypowiadana przez istniejący cache nazw + natywny event kursora.
- Dodano `test_v3101_customization_loop.cpp` oraz rozszerzono `test_focused_ui.cpp` o przypadek powtórzonego Start na tym samym movie. Historyczny test V2.90 został skorygowany tak, aby nie wymuszał już błędnego ownera hot-renderera.
- Hotfix nie dodaje nowego hooka, RVA ani OFF i nie zmienia żadnej wartości adresu gry.

## 3.10 — VERY HUGE: rozszerzona nawigacja całej gry i legacy re-entry — 2026-09-08

- Kolejny milestone jest celowo dużym buildem. V3.10 rozwija jednocześnie szeroką nawigację ekranów oraz niezawodność ponownego wejścia na starsze rodziny UI; nie powstawały pośrednie małe wersje.
- Rozszerzono kontekst pozycji `X z Y`, wyłącznie z natywnych indeksów/liczników gry, na kolejne zweryfikowane powierzchnie: Play Side Select, główne i podrzędne Practice, Standard Dialog, Rematch, Button Mapping, Controller Setup, kategorie i sloty Character Customization, natywny 2-opcyjny popup stroju, Story photo/episode grid, Tournament Session List, Player Match Session List oraz Ranked Match List/wybrane pole gracza.
- Standard Dialog wylicza liczbę przycisków z rzeczywistego natywnego wektora `self+0/self+8` o stride `0x20`; Practice korzysta bezpośrednio z `rowCount/itemCount` przekazywanych przez callback gry. Pozostałe stałe liczności są używane tylko tam, gdzie rozmiar odpowiada dokładnej zweryfikowanej tabeli/panelom SWF gry.
- Dodano route-scoped owner-aware re-entry dla starszych rodzin renderera: Story/PictureStory/chapter/prologue, Playing Stats, Profile, JukeBox, Ultimate Tekken Bowl oraz News. Cache każdej rodziny jest czyszczony dopiero po dopasowaniu jej dokładnego caller RVA i zmianie rzeczywistego `movie`.
- Rozszerzono ten sam model na shared setter: natywne pola Profile i Ultimate Tekken Bowl mają osobne owner-aware cache, dzięki czemu ponowne otwarcie świeżego ekranu może ponownie wypowiedzieć ten sam prawdziwy tekst gry bez globalnego resetowania pozostałego UI.
- Button Mapping, Controller Setup oraz Tournament Session List dostały dodatkową ochronę re-entry opartą na rzeczywistym ownerze/cursorze.
- Naprawiono błąd dokumentacyjno-RE w źródle: cztery stałe `0x00515810/37/5E/85` były historycznie nazwane `PLAYINGSTATS_*`, ale dokładny constructor `SW_UI_PlaySideSelect` potwierdza `$Left/$Left_Effect/$Right/$Right_Effect` z `chasel_msg_012/013`. Stałe przemianowano na `RVA_PLAYSIDE_*`; wartości adresów nie zmieniły się, a duplikujące statyczne etykiety nadal pozostają ciche, bo właściwy wybór strony jest już czytany z natywnego stanu.
- Nie dodano nowego hooka ani nowego adresu gry. V3.10 nadal nie zgaduje niepotwierdzonego ownera hit/guard/wall-hit, postawy/airborne, wall distance, RGB/HSV palety ani anonimowych Command List `$03..$34`.
- Finalna regresja portable po zmianach funkcjonalnych: 39 PASS, 5 testów zależnych od Windows pominiętych w tym środowisku, 0 FAIL.

## 3.00 — VERY HUGE: kontekst nawigacji i route-scoped re-entry — 2026-09-08

- Podniesiono kolejny duży milestone do V3.00, ponieważ jednocześnie przebudowuje dwie szerokie podstawy dostępności: kontekst nawigacji dla niewidomego użytkownika oraz czas życia cache mowy w dużych natywnych batchach UI.
- Przywrócono kontekst `X z Y` wszędzie tam, gdzie obie liczby pochodzą z natywnego indeksu/liczby elementów Tekkena: Main Menu, podmenu Offline/Options, Online root/submenu, Graphics, Sound, Game Options, My Replays/Battle Log i Practice Command List.
- Liczby Main/Offline/Online/Options pochodzą z dokładnych natywnych tabel menu lub bieżących pól count już zweryfikowanych w obsługiwanym EXE. Graphics/Sound/Game Options używają potwierdzonych liczebności wierszy, a Replay i Command List bieżących natywnych rozmiarów list/wektorów. Z pozycji nie są wymyślane żadne nazwy ani znaczenia.
- Dodano route-scoped owner-aware lifetime cache dla dziewięciu dużych grup potwierdzonych pól: V248 current-package, customization/input, controller/viewer help, online/tournament reliability, residual native fields, duże bloki opcji/kategorii, Profile rank list, Playing Stats stage oraz Playing Stats PanelValue10..16.
- Powiązanie z ownerem następuje dopiero po rozpoznaniu dokładnego caller/path danej grupy. Niepowiązany ruch przez shared renderer/setter nie resetuje tych cache.
- Ponowne otwarcie świeżej natywnej instancji Scaleform może więc ponownie wypowiedzieć ten sam prawdziwy tekst gry zamiast odziedziczyć tłumienie duplikatu z poprzedniego ekranu.
- Dodano `NavigationContext.h`, `BatchOwnerReentry.h`, `test_v300_navigation_context.cpp` i `test_v300_batch_reentry.cpp`.
- Pełna regresja portable: 37 PASS, 5 testów Windows-only pominiętych tutaj, 0 FAIL.
- Nie dodano nowego hooka ani nowej/zmienionej wartości RVA/OFF gry. Liczba istniejących instalacji hooków pozostaje taka sama jak w V2.90.
- Publiczna wersja przechodzi z V2.90 do V3.00; test updatera jawnie potwierdza, że V3.00 jest nowsze od V2.90.

## 2.90 — bardzo duży wieloobszarowy build dostępności i ponownego wejścia — 2026-09-08

- Połączono kolejne prace w jeden duży milestone zamiast wydawać pojedynczą małą poprawkę.
- Battle HUD: natywny `_root.SetBattleTime` mówi teraz końcowe odliczanie przy 30, 10, 5, 3, 2, 1 i 0 sekundach; powtórne zapisy są ciche, a wzrost czasu/reset/tryb bez limitu czyści stare oczekujące komunikaty.
- Ponownie zweryfikowano dokładnego caller-a zegara `0x004C2C6E` w obsługiwanym EXE: kod gry ogranicza sekundy do `0..99`, używa `-1` dla braku limitu, buduje argument GFx typu integer i wysyła go do `_root.SetBattleTime` istniejącą ścieżką queued invoke.
- Rozbudowano `Ctrl+Shift+F12`: zweryfikowany snapshot logicznych P1/P2 zdrowie/down/Rage dodaje teraz bieżący czas walki i autorytatywny wynik rund P1/P2.
- Dodano owner-aware reset ponownego wejścia dla My Replays/Battle Log, Rewanżu, Rank Promotion, finalnego komunikatu Revenge, szczegółów Fight Money i Result Total.
- Rozszerzono owner-aware generation/reset w Character Customization: kategoria, slot/copy UI stroju, licznik przedmiotów oraz wybrany przedmiot/status. Ponowne otwarcie świeżej natywnej listy na tym samym elemencie ponownie uzbraja mowę bez wymyślania nazw przedmiotów lub kolorów.
- Cache Fight Money/Result Total wiąże się z natywnym movie dopiero po dokładnym dopasowaniu caller/path, więc niepowiązany ruch we wspólnym rendererze nie resetuje tych domen mowy.
- V2.90 nie dodaje nowego hooka, RVA ani offsetu pola fightera; wszystkie zmiany używają istniejących hooków oraz wcześniej zweryfikowanych ownerów i danych HUD.
- Dodano `BattleTimerReader.h`, `test_v290_battle_timer.cpp`, `test_v290_mass_reentry.cpp` oraz rozszerzono regresję HUD/runtime.
- Finalna regresja portable po wszystkich zmianach V2.90: 35 PASS, 5 testów Windows-only pominiętych tutaj, 0 FAIL. Rozszerzona ścieżka HUD przechodzi też kompilację/uruchomienie ze stubem API Windows.
- Publiczna wersja przeskakuje bezpośrednio z V2.88 do V2.90, ponieważ jest to duży milestone; porównanie numeryczne updatera jawnie testuje pominięte V2.89.

## 2.88 — logiczna tożsamość stanu powalenia i aktualna strona — 2026-09-08

- Automatyczne komunikaty `powalony / już nie jest powalony` zachowują zweryfikowaną logiczną tożsamość P1/P2 i dodają aktualną lewą/prawą stronę, gdy `PlayerOnRightSide` jest dostępne. Cross-up w trakcie istniejącego 80 ms filtra stabilności nie zmienia właściciela zdarzenia.
- `Ctrl+Shift+F12` dodaje aktualną stronę do każdego poprawnie odczytanego P1/P2 w snapshotcie zdrowie + down + Rage. Gdy orientacja jest chwilowo niedostępna, pozostaje wcześniejsze bezpieczne P1/P2 bez zgadywania strony.
- Odczyt strony korzysta wyłącznie z już zweryfikowanego `fighter+0x14D4`; nie dodano nowego hooka, RVA ani offsetu fightera. Fighter pointers i battle context są ponownie weryfikowane po odczycie tak jak wcześniej.
- Ponownie sprawdzono paletę Customization: event 45 przekazuje tylko współrzędne kursora gradientu, a eventy 46/48/53 wybór próbki/zapisanego koloru/obszaru. Brak potwierdzonej wartości RGB/HSV, więc V2.88 nadal nie wymyśla nazw kolorów.
- Dodano `test_v288_down_identity.cpp`; pełna regresja portable: 33 PASS, 5 testów Windows-only pominiętych, 0 FAIL.
- Publiczną wersję podniesiono do `V2.88`.

## 2.87 — logiczna tożsamość zdrowia P1/P2 po cross-upie — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Potwierdzono istniejący renderer zdrowia `0x004C6930`: natywne argumenty to bieżące zdrowie, maksymalne zdrowie i indeks strony ekranu; renderer przekazuje te trzy wartości do `_root.SetHealth`.
- Potwierdzono natywnego caller-a `0x004C36A4..0x004C36E6`: iteruje logiczny indeks fightera, rozwiązuje tego fightera, pobiera jego bieżące HP przez obiekt zdrowia i maksymalne HP z tego samego fightera, osobno wylicza stronę HUD, a następnie wywołuje `0x004C6930`. Dowodzi to, że strona jest stanem prezentacji, a nie stałą tożsamością gracza.
- Przebudowano `HealthReader`: zweryfikowane próbki są przechowywane dla logicznego P1/P2, gdy dostępna jest już potwierdzona orientacja `PlayerOnRightSide`. Przy mowie aktualna lewa/prawa strona jest rozwiązywana osobno.
- Naprawiono błąd snapshotu po cross-upie: zdrowie zapisane przed zmianą stron nie jest już później interpretowane jako HP gracza, który zajął tę stronę ekranu. Natywny redraw po zmianie stron pozostaje cichy, chyba że zdrowie logicznego gracza rzeczywiście przekroczy próg komunikatu.
- Gdy orientacja jest chwilowo niedostępna, próbka pozostaje w osobnym cache side-only i nigdy nie jest później zgadywana jako P1/P2. Oczekujące ostrzeżenia side-only są czyszczone po powrocie pewnej orientacji, aby nie przenosić starej tożsamości.
- Nie dodano nowego hooka, RVA ani offsetu pola fightera; istniejący hook `SetHealth` pozostaje bez zmian.
- Dodano `test_v287_health_logical_identity.cpp`. Regresja portable po zmianie logiki: 32 PASS, 5 testów zależnych od Windows pominiętych tutaj, 0 logicznych FAIL. Zmieniona ścieżka `_WIN32` HealthReader przechodzi też kompilację ze stubem API Windows.
- Publiczną wersję podniesiono do `V2.87`.

## 2.86 — logiczna identyfikacja P1/P2 dla Rage po zmianie stron — 2026-09-08

- Ponownie sprawdzono natywną ścieżkę Rage w Battle HUD w obsługiwanym `TekkenGame-Win64-Shipping.exe`. HUD przechodzi po dwóch fighterach, wylicza aktualną stronę ekranu i przekazuje właśnie indeks strony do `_root.RageOn` / `_root.RageOff`.
- Dodano logiczny tracker Rage P1/P2 oparty na już zweryfikowanych danych `PlayerOnRightSide`. Prawdziwy start/koniec Rage podaje teraz gracza oraz odświeża jego aktualną lewą/prawą stronę przed mową.
- Redraw HUD po cross-upie, np. `RageOff` na starej stronie i `RageOn` na nowej, nie jest już traktowany jako fałszywa zmiana Rage między graczami, jeżeli logiczny stan Rage się nie zmienił.
- Gdy orientacja fighterów jest chwilowo niedostępna podczas budowania HUD-u, pozostaje bezpieczny wcześniejszy fallback tylko po stronie ekranu.
- Nie dodano nowego hooka, RVA ani offsetu fightera.

## 2.85 — natywny wynik rund P1/P2 w Battle HUD — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Potwierdzono natywnego caller-a `0x00307190`: ładuje tabelę przy `RVA 0x034CD500`, iteruje dwa rekordy graczy ze stride `0xF0`, a dword `+0x00` jest liczbą widocznych znaczników wygranych rund.
- Caller wykonuje dla każdego gracza pętlę `markIndex = 0 .. wins-1` i wywołuje renderer `0x004C5850`; dlatego pojedynczy redraw wyniku 3 może generować callbacki markerów 0, 1 i 2.
- Potwierdzono, że `0x004C5850` dopiero po otrzymaniu logicznego indeksu gracza mapuje go na bieżącą stronę ekranu i wywołuje `_root.TurnWinMarkOn`. Tabela `0x034CD500` jest więc lepszym źródłem P1/P2 niż fizyczna strona HUD.
- V2.85 traktuje istniejący `TurnWinMarkOn` tylko jako sygnał odświeżenia. Przed mową czyta autorytatywne liczniki P1/P2 i wypowiada jeden końcowy wynik, np. `Wynik rund. Gracz 1: 3. Gracz 2: 1.` zamiast sekwencji `1, 2, 3`.
- Powtórny redraw z niezmienionym wynikiem jest wyciszany. Gdy wynik spadnie po rematchu i później wzrośnie, zmiana zostanie wykryta z bieżących liczników, bez założenia monotoniczności indeksu markera.
- `Ctrl+Shift+F7` zawiera teraz zweryfikowany wynik rund, gdy aktywna jest prawidłowa tożsamość walki i tabela jest czytelna.
- Jeśli bezpośredni odczyt tabeli chwilowo się nie powiedzie, pozostaje bezpieczny fallback najwyższego markera dla strony ekranu, z deduplikacją.
- Nie dodano nowego hooka. Dodano tylko jeden nowy, byte-verified RVA tabeli wyniku rund; istniejące hooki i wcześniejsze wartości RVA/OFF pozostają bez zmian.

## 2.84 — tożsamość P1/P2 w zdrowiu po zmianie stron — 2026-09-08

- Komunikaty zdrowia z istniejącego hooka `_root.SetHealth` nie są już ograniczone do `Lewa/Prawa strona`; gdy zweryfikowana orientacja fighterów jest dostępna, NVDA mówi także `Gracz 1` lub `Gracz 2`.
- Mapowanie wykorzystuje wyłącznie istniejące, potwierdzone dane `PlayerOnRightSide` / `fighter+0x14D4`; nie dodano nowego hooka, RVA ani offsetu.
- Tożsamość jest rozwiązywana przy `Flush`, tuż przed mową, dzięki czemu cross-up podczas 200 ms grupowania komunikatu nie pozostawia starego przypisania strony.
- Audyt combat potwierdził, że `OnGuard`, `OnReceivedHit`, `OnPlayerDown` i `OnJumpLanding` należą do `BattleEventItemInterface`. Interfejs sam nie dowodzi, który fighter jest odbiorcą, więc nadal nie dodajemy ryzykownego przypisania event -> P1/P2.
- `GetFloorNo` / `GetStagePositionType` należą do `TekkenPlayerStart`, więc nie są używane jako dynamiczny stan walki. `GetWallAttribute` należy do `TekkenWallActor`, lecz jego wartości nie mają w EXE potwierdzonej mapy nazw — nie zgadujemy ich znaczenia.

## 2.83 — przywrócone natywne etykiety Practice Attack Data — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Potwierdzono pięć natywnych rodzin wartości `SW_UI_AttackData`: `$TotalDamage_%s`, `$MaxComboDamage_%s`, `$Damage_%s`, `$HitCombo_%s` i `$ComboDamage_%s`.
- Potwierdzono, że setup RVA `0x0044D500` ładuje klucze lokalizacji `prc_573`, `prc_574`, `prc_575`, `prc_576` i `prc_577` dokładnie w tej samej kolejności.
- Naprawiono stratę dostępności w istniejącym podsumowaniu Attack Data: mod miał już pięć zweryfikowanych wartości, ale odrzucał etykiety i wypowiadał tylko ciąg liczb/wartości.
- Dodano `AttackDataSummarySpeech.h`: NVDA mówi natywną stronę panelu L/R oraz każdą dostępną parę **etykieta z lokalizacji gry + wartość**. Najpierw rozwiązywane są prawdziwe klucze `prc_573..577`; etykiety awaryjne są używane tylko przy braku lokalizacji.
- Nie dodano żadnego nowego hooka, definicji RVA/OFF ani offsetu pamięci gry. Liczby hooków i wszystkie istniejące wartości adresów pozostają bez zmian względem V2.82.
- Dodano `test_v283_attackdata_summary.cpp`. Regresja portable: 28 PASS, 5 testów zależnych od Windows pominiętych tutaj, 0 FAIL.
- Zachowano utwardzenie buildera z V2.82 BUILD FIX 2: pliki BAT CRLF bez BOM i brak zależności od podprocedur etykietowych.
- Publiczną wersję podniesiono do `V2.83`.

## 2.82 — przywrócone etykiety Practice Frame Data w mowie — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Potwierdzono, że natywny ekran Frame Data tworzy `$p1_item_1..4` / `$p2_item_1..4` i zasila je kluczami lokalizacji gry `S3_002_frm_000`, `S3_002_frm_001`, `S3_002_frm_004` oraz `S3_002_frm_005`.
- Potwierdzono odpowiadające ścieżki wartości `$p1_number_1..4` / `$p2_number_1..4`. V2.81 zapisywało już zarówno etykiety, jak i wartości, ale końcowy komunikat odrzucał etykiety i wypowiadał tylko niejednoznaczny ciąg liczb.
- Dodano `FrameDataSpeech.h`: NVDA mówi teraz natywną tożsamość panelu (`gracz 1` / `gracz 2`) oraz każdą dostępną parę **natywna etykieta gry + wartość**. Jeżeli etykiety chwilowo brakuje, bezpieczny fallback mówi samą wartość; mod nie wymyśla znaczenia pola.
- Nie dodano żadnego nowego hooka, RVA, wartości OFF ani offsetu pola pamięci gry. Wszystkie istniejące nazwane RVA/OFF mają identyczne wartości jak w V2.81; `Patch::Install` pozostaje 41, a `Patch::InstallRel8Jcc` 1.
- Dodano `test_v282_frame_data_speech.cpp`. Regresja portable: 27 PASS, 5 testów zależnych od Windows pominiętych tutaj, 0 FAIL.
- Zachowano poprawkę pakowania z V2.80: historyczne audyty są opcjonalne i nie mogą zatrzymać tworzenia ZIP-a release.
- Publiczną wersję podniesiono do `V2.82`.

## 2.81 — potwierdzone zdarzenia Practice Attack Data — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Potwierdzono, że natywna tabela ścieżek `SW_UI_AttackData` po pięciu liczbowych metrykach zawiera cztery rodziny dynamicznych wskaźników: `CleanHit`, `CounterHit`, `WallHit` i `Punish` dla natywnych paneli L/R. Odpowiadające klucze lokalizacji gry to `prc_578`–`prc_581`.
- Potwierdzono dokładne helpery wyzwalające: Clean Hit RVA `0x0044E280` używa ścieżki `+0x600`; Counter Hit `0x0044E8C0` używa `+0x700`; Wall Hit `0x0044EDE0` używa `+0x800`; Punish `0x0044ED40` używa `+0x900`. Dla obu stron używany jest stride `0x1370`.
- Wszystkie cztery helpery ładują dokładny stan animacji `Start` i kończą skokiem do settera RVA `0x00453950`, który Tekken Accessibility już hookuje. V2.81 rozszerza więc istniejący hook i **nie instaluje nowego**.
- NVDA ogłasza natywną stronę wizualną oraz tekst zdarzenia z lokalizacji gry tylko po wykryciu dokładnej ścieżki ze stanem `Start`. Stany `On`, `Off`, `End`, pomieszane strony i niezwiązane ścieżki Attack Data są odrzucane, aby nie gadało przy samym tworzeniu/resetowaniu ekranu.
- Nie dodano żadnej nowej definicji RVA/OFF ani offsetu pola pamięci gry. Wszystkie 577 nazwanych `RVA_*`/`OFF_*` i ich wartości są identyczne jak w V2.80; liczba istniejących instalacji hooków pozostaje bez zmian.
- Eventów refleksji typu `OnReceivedHit` / `OnGuard` celowo nadal nie przypisujemy do fightera, dopóki nie zostanie potwierdzona tożsamość odbiorcy.
- Dodano `AttackDataEvents.h` i `test_v281_attackdata_events.cpp`. Regresja portable: 26 PASS, 5 testów zależnych od Windows pominiętych tutaj, 0 FAIL; zmieniona integracja FocusedUi przechodzi również test składni/działania ze stubem API Windows.
- Publiczną wersję podniesiono do `V2.81`.

## 2.80 — poprawne natywne tokeny Command List — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Odczytano natywną 64-elementową tabelę formattera tokenów komend przy VA `0x14282F6F0`. Potwierdza ona m.in. `rs>` → `$RS`, `screw>` → `$ART_SCREW`, `lsb>` → `$L` oraz `rsb>` → `$R`.
- Naprawiono rzeczywisty błąd V2.77–V2.79: `<#rs>` nie oznacza Tailspin, tylko prawy drążek. NVDA mówi teraz `Prawy drążek`; Tailspin pozostaje przypisany wyłącznie do `<#screw>`.
- Natywny renderer zaznaczonej komendy potwierdza dotychczasową semantykę flagi `record+0x1C`: helper `0x1404C9870` zwraca dokładnie `<#screw>`. Sąsiednie flagi nadal używają `<#power>`, `<#homing>` i `<#wallbound>`.
- Dodano potwierdzone klasy obrazków `$L` / `$R` dla naciśnięcia lewego/prawego drążka oraz jednoznaczne znaczniki z tej samej tabeli, m.in. Rage Art, Rage Drive, Infinity, Wall/Wall Break/Balcony Break/Floor Break, Assist, Difficulty, View i Save.
- Anonimowe klasy `GAIJI/$03..$34` nadal **nie otrzymują zgadywanych nazw**. Jeśli wystąpią, pozostają słyszalne jako identyfikator symbolu.
- Nie dodano żadnego hooka, RVA ani offsetu pamięci gry. Wszystkie 577 istniejących nazwanych stałych `RVA_*`/`OFF_*` mają identyczne wartości jak w V2.79; liczba `Patch::Install` pozostaje 41, a `Patch::InstallRel8Jcc` 1.
- Dodano `test_v280_command_tokens.cpp` i rozszerzono test dekodera Command List. Regresja portable: 25 PASS, 5 testów zależnych od Windows pominiętych tutaj, 0 FAIL.
- Publiczną wersję podniesiono do `V2.80`.

## 2.79 — potwierdzony tekst dynamicznej wartości Practice — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`), aby usunąć ostatni surowy numer na głównej stronie ustawień Practice.
- Potwierdzono, że `prc_713` / natywny typ wiersza `0x09` nie jest statyczną listą. Gra odczytuje `settings+0x1C`, przeszukuje dynamiczny wektor `0x1434D6BD8..0x1434D6BE0` i używa rekordów po 0x20 bajtów.
- Potwierdzono znaczenie pól rekordu z kodu natywnego: `+0x00` to ID porównywane z `settings+0x1C`, a `+0x08` to wskaźnik prawdziwego tekstu gry przekazywanego do wspólnego renderera `0x1404570E0`.
- Główna pozycja Practice mapuje teraz bieżące natywne ID na ten dokładny tekst. Odpowiadające submenu wartości korzysta z natywnego indeksu w tym samym wektorze, więc typ `0x09` nie pozostaje już bez odczytu.
- Dodano zabezpieczone odczyty `ReadProcessMemory` dla globali wektora, rekordów i tekstu. Uszkodzone/niepełne dane są odrzucane, a główny wiersz zachowuje stary fallback liczbowy, gdy dynamiczna lista jest chwilowo niedostępna.
- Dodano dokładnie dwa potwierdzone RVA danych (`0x034D6BD8`, `0x034D6BE0`) i **żadnego nowego hooka**. Istniejące hooki kursora Practice pozostają bez zmian.
- Dodano `test_v279_practice_dynamic.cpp` oraz osobne audyty danych natywnych i wydania.
- Regresja portable: 24 testy PASS, 5 testów zależnych od Windows pozostaje do MSVC/live, 0 błędów portable.
- Odczyt Command List z V2.78 i wszystkie wcześniejsze poprawki Online/Combat/ponownego wejścia/polskiego pozostają bez zmian.
- Publiczną wersję podniesiono do `V2.79`.

## 2.78 — zachowanie natywnych obrazkowych symboli Command List — 2026-09-08

- Ponownie przeanalizowano dokładnie obsługiwany `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`) i prześledzono natywny loader `commandimage_struct`, zamiast przypisywać znaczenia na podstawie wyglądu ikon.
- Potwierdzono klasę danych obrazków komend przy vtable `0x1427BADD0`: parser `0x140322260` relokuje rekordy z `Binary/list/commandimage_struct.bin`, a getter `0x14033A6A0` zwraca dokładnie tę ścieżkę danych gry.
- Potwierdzono, że natywny parser `0x140321F80` obsługuje znaczniki `<img src='...'>` i wyszukuje je w `commandimage_struct`. V2.77 traktował zwykłe `<img>` jak HTML do usunięcia, więc taki symbol mógł zniknąć z mowy NVDA.
- V2.78 zachowuje obrazkowe symbole Command List w mowie. Nazwane klasy kontrolera potwierdzone w eksporcie `gfxgaijilib` są wypowiadane jako rzeczywiste przyciski/drążki/krzyżak i kierunki dla Xbox/PlayStation. Jawnie nazwane klasy Tekkena, np. Homing/Screw/Power Crush/Rage Art/Rage Drive, również są odczytywane.
- Anonimowe klasy numeryczne `$03..$34` **nie dostają zgadywanych nazw**. Jeśli wystąpią, pozostają słyszalne jako `symbol $NN`, dopóki `commandimage_struct.bin` albo właściwy asset nie potwierdzi ich znaczenia.
- Odwzorowano natywną listę pomijanych klas `$01`, `$02`, `$35`, `$TRIANGLE_RIGHT`, `$TRIANGLE_LEFT`, żeby dekoracyjne/nawigacyjne obrazy nie zaśmiecały mowy.
- Dodano testy regresji dla obrazków Xbox, PlayStation, właściwości ruchu, anonimowego symbolu numerycznego i natywnej listy pomijanej.
- Nie dodano żadnego hooka, RVA ani offsetu pamięci gry. Wszystkie istniejące deklaracje `RVA_*` / `OFF_*` oraz miejsca instalacji hooków w `TekkenAccessibility.cpp` są identyczne jak w V2.77.
- Regresja portable: 23 testy PASS, 5 testów zależnych od Windows pozostaje do MSVC/live, 0 błędów portable.
- Publiczna wersja została podniesiona do `V2.78`.

## 2.77 — potwierdzony odczyt symboli Practice Command List — 2026-09-08

- Ponownie sprawdzono Practice Command List względem dokładnie obsługiwanego `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Dodano wyłącznie warstwę mowy dekodującą natywne znaczniki `<#...>` obecne już w dostarczanym przez grę tekście `$command`. Potwierdzone znaczniki A/B/X/Y, bumperów, spustów, naciśnięć drążków, Menu, potwierdzenia/anulowania i kierunków są teraz wypowiadane jako czytelne etykiety zamiast surowego markup.
- Zaznaczona komenda nadal pochodzi z wcześniej potwierdzonego pola rekordu Command List `+0x08`; nie dodano zewnętrznej bazy ruchów ani zgadywanego mapowania komend.
- Nieznane znaczniki `<#...>` pozostają słyszalne jako `symbol <token>`. Niejednoznaczne zasoby obrazów komend (`GAIJI` / `$03..$34`) celowo pozostają bez nazw semantycznych, dopóki nie uda się ich potwierdzić z danych gry.
- Ponownie sprawdzono pola prezentacyjne rekordu: natywny renderer `0x14048E720` używa `+0x16` i `+0x1A` do wyglądu/stanu wiersza, a `+0x19` steruje ikoną wyposażenia. V2.77 nie ogłasza ich jako właściwości ruchu.
- Wcześniej potwierdzone flagi semantyczne pozostają bez zmian: trudność/powtórzenia `+0x17/+0x18`, Power Crush `+0x1B`, Tailspin/Screw `+0x1C`, Homing `+0x1E`, Wall Bound `+0x1F`. Etykieta trudności jest teraz dwujęzyczna.
- Dodano `PracticeCommandText.h` i `test_practice_command_text.cpp`, obejmujący polski/angielski odczyt, bezpieczny fallback nieznanych tokenów i czyszczenie markup.
- Nie dodano ani nie zmieniono żadnego hooka, RVA ani offsetu pamięci gry. Wszystkie 576 nazwanych stałych `RVA_*`/`OFF_*` są identyczne jak w V2.76; liczba `Patch::Install` / Rel8 pozostaje bez zmian.
- 23 testy przenośne przechodzą, 5 testów zależnych od Windows pozostaje do MSVC, 0 błędów testów przenośnych.
- Publiczna wersja została podniesiona do `V2.77`.

## 2.76 — pewniejsze ponowne wejście do Practice i ekranów wyboru — 2026-09-08

- Rozszerzono ochronę cache po tożsamości natywnego obiektu `self` na kolejne istniejące czytniki: Character Select, wybór stroju/slotu, Stage Select, główne Practice, podmenu wartości Practice oraz Pause Menu.
- Nowo utworzony ekran może teraz rozpocząć się na dokładnie tej samej postaci, arenie, pozycji Practice, wartości podmenu lub pozycji pauzy co poprzedni ekran i nadal odczyta pierwszy element zamiast odziedziczyć stary filtr duplikatów.
- Practice nadal odczytuje wyłącznie wcześniej odzyskane natywne strony, wiersze, pola ustawień i tabele wartości. V2.76 nie dodaje nowych nazw ani znaczeń pól z przypuszczeń.
- Stage Select zeruje cache nowego właściciela przed wywołaniem oryginalnej funkcji, aby nie utracić potwierdzonego callbacku stanu blokady bieżącej areny.
- Dodano lekki `OwnerToken` do `ScreenOwnerCache.h` oraz test `test_v276_reentry.cpp`. Test sprawdza zmianę właściciela i obecność ochrony w sześciu grupach ekranów.
- Zmiana korzysta wyłącznie z już istniejących hooków oraz przekazywanych przez nie wskaźników `self`. Nie dodano żadnego hooka, RVA ani offsetu pamięci gry.
- Wszystkie funkcje V2.75, V2.74.2, Online, Combat i polska wersja językowa pozostają bez zmian.
- 22 testy przenośne przechodzą poprawnie, 5 testów zależnych od Windows pozostaje do uruchomienia w MSVC; 0 błędów w zestawie przenośnym.
- Numer wersji podniesiono do `V2.76`.

## 2.75 — pewny odczyt po ponownym wejściu do menu — 2026-09-08

- Naprawiono przypadek, w którym nowo utworzony ekran menu mógł pozostać cichy, jeśli startował na tym samym indeksie, który był ostatnio odczytany na poprzedniej instancji ekranu.
- Main Menu, wspólne podmenu Offline/Options, główne menu Online i drugie podmenu Online wiążą teraz cache ostatniego wyboru z natywnym wskaźnikiem `self`. Zmiana obiektu ekranu ustawia świeży cache, więc pierwsza pozycja nowej instancji jest ponownie odczytywana.
- Wspólne podmenu zachowują również rozdzielenie po natywnym `mode`, więc przejście między potwierdzonymi gałęziami menu nadal ponownie uzbraja odczyt nawet przy tym samym indeksie.
- Dodano `ScreenOwnerCache.h` oraz test `test_screen_owner_cache.cpp`, obejmujący duplikaty w tej samej instancji, ponowne wejście z nowym właścicielem, zmianę trybu i jawny reset. Test sprawdza również podpięcie helpera do czterech istniejących czytników.
- Zmiana używa wyłącznie czterech już istniejących hooków kursora i wcześniej potwierdzonych pól menu. Nie dodano hooka, RVA ani offsetu pamięci gry.
- Ochrona tożsamości walki z V2.74.2 oraz wszystkie wcześniejsze poprawki Online/Combat/Polish pozostają bez zmian.
- 21 testów przenośnych przechodzi poprawnie, 0 błędów; pięć testów zależnych od Windows oraz końcową kompilację DLL należy uruchomić przez `RUN_FULL_TESTS_V2.75.bat` / `BUILD_RELEASE_V2.75.bat`.
- Numer wersji podniesiono do `V2.75`.

## 2.74.2 — hotfix stanu walki między pojedynkami — 2026-09-08

- Naprawiono możliwość przeniesienia punktu odniesienia automatycznych komunikatów walki do następnego pojedynku, gdy nowa walka pojawiała się szybciej niż 500 ms okresu nieważnych danych.
- Tracker zmiany stron wiąże teraz swój stabilny stan z już potwierdzonym zestawem: kontekst walki + wskaźnik 1P + wskaźnik 2P. Zmiana tego zestawu ustawia nowy punkt odniesienia po cichu zamiast mówić fałszywe `Zmiana stron`.
- Tracker `IsDown2` korzysta z tej samej ochrony, więc nowa walka nie dziedziczy `powalony / już nie jest powalony` z poprzedniego zestawu fighterów.
- Prawdziwe przejścia w obrębie tej samej walki nadal używają istniejącego filtra stabilności 80 ms; dłuższy brak prawidłowych danych nadal zeruje baseline po 500 ms.
- Zmiana używa wyłącznie wcześniej potwierdzonego kontekstu walki i tabeli fighterów. Nie dodano żadnego hooka, RVA, offsetu fightera ani zgadywanego stanu postawy/ściany.
- Rozszerzono testy orientacji i powalenia o zmianę tożsamości fighterów; 20 testów przenośnych przechodzi poprawnie. Pięć testów zależnych od Windows/MSVC oraz kompilację DLL należy uruchomić na Windows przez `RUN_FULL_TESTS_V2.74.2.bat` / `BUILD_RELEASE_V2.74.2.bat`.
- Numer wersji podniesiono do `V2.74.2`.

## 2.74.1 — poprawa polskiego języka moda — 2026-09-08

- Poprawiono skrypt wydania: DLL jest teraz budowana przed opcjonalnymi pelnymi testami; nieudany test nie blokuje juz utworzenia DLL/ZIP. Dodano osobny `RUN_FULL_TESTS_V2.74.1.bat` oraz czytelne logi builda.

- Przeprowadzono osobny przegląd polskich komunikatów generowanych przez mod. Nie zmieniano nazw graczy, nazw postaci ani tekstów dostarczanych bezpośrednio przez grę, jeśli mod nie ma pewnej podstawy do ich tłumaczenia.
- Poprawiono niezgrabne lub błędne sformułowania, m.in. `Host` -> `Gospodarz`, `Arcade, postać` -> `Tryb Arcade`, `Lewy/Prawy drążek naciśnięcie` -> `Naciśnięcie lewego/prawego drążka`, `Poczekalnia pokoju` -> `Poczekalnia` oraz komunikaty kopiowania stroju.
- Poprawiono polskie opisy profilu: ukończenie galerii, fabuły i epizodów postaci, Tekken Power, łączną liczbę walk i łącznie zdobyte pieniądze.
- Poprawiono komunikaty walki: `Rage aktywny/nieaktywny/zakończony`, `Automatyczne komunikaty o zmianie stron`, `Nie można odczytać pozycji/stanu...` oraz `Gracz 1/2: już nie jest powalony`. F10 mówi teraz naturalniej `Odległość między graczami`.
- Poprawiono komunikaty zdrowia i HUD: `Komunikaty o zdrowiu`, `Komunikaty o czasie, Rage i rundach`, `Brak danych o zdrowiu/czasie i Rage`.
- Dodano prawidłową polską odmianę czasu: `1 sekunda`, `2 sekundy`, `5 sekund`, `1 sekundę temu` itd.
- Poprawiono nazwy sterowania: `Krzyżak w górę/dół/lewo/prawo` oraz `Naciśnięcie lewego/prawego drążka`.
- Poprawiono komunikat nieznanej ikony QTE na `Nierozpoznana ikona polecenia` i kilka innych etykiet interfejsu.
- Usunięto jeden komunikat runtime wpisany na sztywno po angielsku: komunikat o zbyt długim opisie ma teraz pełną wersję polską.
- README PL/EN dokumentuje teraz `Ctrl+L`, który przełącza polskie/angielskie komunikaty moda; wybór jest zapisywany w `%LOCALAPPDATA%\TekkenAccessibility\settings.ini`.
- Dodano `test_polish_language.cpp`, obejmujący kluczowe polskie etykiety, Online, Combat i odmianę sekund. Zmiany językowe nie dodają hooków ani nie zmieniają potwierdzonych offsetów gry.
- Numer wersji podniesiono do `V2.74.1`; dodano `BUILD_RELEASE_V2.74.1.bat`.

## 2.74 — potwierdzony odczyt stanu walki — 2026-09-08

- Dodano `Ctrl+Shift+F12`, który na żądanie odczytuje stan obu natywnych rekordów fighterów. Komunikat podaje potwierdzony przez grę procent zdrowia, natywny stan powalenia oraz Rage dla gracza 1 i gracza 2.
- Dodano automatyczne komunikaty zmiany natywnego `IsDown2`: po stabilnych 80 ms mod mówi `Gracz 1/2: powalony` albo `powalenie zakończone`. Krótkie stany przejściowe są odrzucane, a po 500 ms nieważnych/brakujących rekordów fighterów tracker resetuje bazę, żeby nie przenosić stanu między rundami lub ekranami. Ten monitor korzysta wyłącznie z `ReadProcessMemory` i nie dodaje hooka.
- Rozebrano natywne `IsDown2`: wrapper `0x006774E0` woła funkcję `0x00254320`, która czyta `dword [fighter+0x428]` i zwraca prawdę dokładnie dla stanów `13, 15, 17, 19`. Dlatego V2.74 mówi tylko `powalony / nie jest powalony`; dla pozostałych wartości celowo nie wymyśla `stoi`, `kuca` ani `jest w powietrzu`.
- Rozebrano natywne `IsRage`: wrapper `0x00677D50` woła `0x00254820`, które zwraca `byte [fighter+0x781] != 0`.
- Rozebrano natywne `GetNormalizedHP`: wrapper `0x00674D10` woła `0x00253C40`, zamienia `dword [fighter+0x1508]` na float i mnoży przez `0.01`. Niezależny kod gry porównuje to samo pole z `100`, co potwierdza skalę procentową 0–100 używaną przez odczyt.
- Nowy odczyt stanu używa już potwierdzonego battle context / fighter table oraz `ReadProcessMemory`; worker dostępności nie wywołuje funkcji silnika i nie dodano żadnego nowego hooka. Po odczycie wskaźniki fighterów są ponownie sprawdzane, żeby przejście między walkami nie połączyło danych dwóch różnych obiektów.
- Dodano test połączenia runtime, który sprawdza, że F10 pozycja, F11 orientacja/monitor oraz F12 stan walki są osiągalne przez `DescriptionRuntime::Run()` uruchamiane z `InitThread`. Potwierdza to też, że F10/F11 były już rzeczywiście podłączone w V2.73 przez `DescriptionRuntime.h`, mimo że nie występują bezpośrednio w `TekkenAccessibility.cpp`.
- Dalej zbadano dane ścian/podłogi. `GetWallAttribute` to potwierdzone `dword [object+0x398]`, `GetFloorNo` to `dword [object+0x390]`, a `GetStagePositionType` to `byte [object+0x3B8]`. Są to obiekty sceny/kolizji, których bezpiecznego przypisania do konkretnego fightera jeszcze nie potwierdzono, dlatego V2.74 celowo nie mówi odległości ani strony ściany na ich podstawie.
- Zlokalizowano rodziny zdarzeń `OnReceivedHit`, `OnGuard`, `OnWallHit`, `OnPlayerDown` i `OnJumpLanding`. W V2.74 nie są jeszcze hookowane, bo przypisanie obiektu odbiorcy zdarzenia do fightera nie jest dostatecznie potwierdzone; zachowujemy zasadę bez zgadywania i minimalizowania hooków.
- Sprawdzono także `IsCrouching`: pierwszy natywny wrapper jest zarejestrowany pod `/Script/Engine` i wywołuje ogólną wirtualną metodę silnika (`vtable+0x4B8`), a drugi ślad jest metadanymi refleksji. Nie ma potwierdzenia, że jest to stan rekordów fighterów Tekkena, więc V2.74 celowo nie ogłasza kucania.
- Publiczny numer wersji podniesiono do `V2.74`; `TekkenAccessVersion.txt`, testy startu i `BUILD_RELEASE_V2.74.bat` korzystają z tego samego numeru.

## 2.73 — Online Completion + Combat Orientation + nowa numeracja wydań — 2026-09-08

- Pierwsze duże publiczne wydanie po V2.72 otrzymuje nowy numer wersji zamiast kolejnego oznaczenia „Build”. Numer źródłowy jest od teraz trzymany w `ModVersion.h`, a plik dla auto-updatera zawiera dokładnie `V2.73`.
- Domknięto duży etap Online: rozdzielono prawdziwy `SW_UI_RankMatch_MatchList` od Player Match Session Room, dodano prawdziwy 6-wierszowy kursor Session Room i 7-wierszowy kursor listy turniejów oraz opisane pola graczy/sesji, jakość połączenia i obszar.
- Zachowano wcześniejsze poprawki Sound Options: prawdziwe pola ekranu, zakresy 0–10 dla czterech suwaków i 0–1 dla przełącznika.
- Zachowano utwardzenie hooków z Build A: relokacja krótkiego `JE` StandardDialog oraz rollback modułów wielohookowych.
- Dialogi i ekrany Options resetują cache po ponownym wejściu, co ogranicza ciche ponowne otwarcia i podwójne komunikaty.
- Customization korzysta z potwierdzonej siatki 72 próbek (8×9) i 15 zapisanych kolorów bez wymyślania nazw RGB/HSV.
- Combat Accessibility: `Ctrl+Shift+F10` odczytuje natywne pozycje obu fighterów, dystans i lewo/prawo; `Ctrl+Shift+F11` włącza automatyczny komunikat o stabilnej zmianie stron.
- Przeanalizowano binarnie obecny `TekkenAccessUpdater.exe`: akceptuje `v`/`V`, parsuje numery po kropkach jako liczby, dopełnia brakujące części zerami i porównuje wersje numerycznie. Sekwencje `V2.72 -> V2.73 -> V2.73.1 -> V2.74` są zgodne z obecnym updaterem.
- Dodano `BUILD_RELEASE_V2.73.bat`, który po pełnych testach i kompilacji tworzy gotowy binarny ZIP do GitHub Release.

## 2.72 Build E.1 — domknięcie Online / rozdzielenie Ranked i Session Room — 2026-09-08

- Naprawiono błędną klasyfikację dwóch starych hooków V2.72: `0x005258D0` i `0x00528000` należą do `SW_UI_RankMatch_MatchList`, a nie do Player Match Session Room. `0x005258D0` przechodzi dokładnie po 10 panelach i ustawia natywne stany `Select`/`Normal`, więc dotychczasowy działający odczyt został zachowany jako osobny moduł **Ranked MatchList**.
- Dodano prawdziwy Player Match Session Room na podstawie funkcji kursora `0x0050FD30`. Kod gry przechodzi dokładnie po 6 panelach i ustawia `Select`/`Normal`; rekordy lobby mają rozmiar `0x60`, licznik jest pod `self+0x450`, a tablica rekordów pod `self+0x558`.
- Session Room składa teraz jeden opis zaznaczonego gracza z potwierdzonych danych: Gracz (`$PlayerName0..5`), Postać (`rec+0x38`), Ranga (`+0x3C`), Wygrane (`$Wins0..5`, źródło `+0x40`), Procent wygranych (`$WinRate0..5`, liczony przez grę z `+0x40/+0x48`), Tytuł (`$Shogo0..5`, `+0x4C`), Język (`$Language0..5`, `+0x54`), Jakość połączenia (`+0x04`, 1–6) i Obszar (`+0x58`, 1–8).
- Dodano ochronę przed wyciekiem danych poprzedniego gracza: wybór pustego/nieistniejącego slotu czyści cache tego wiersza zamiast wypowiadać dane starego użytkownika.
- Odczyt wskaźnika filmu, liczby graczy, tablicy rekordów i pól ikonowych prawdziwego Session Room korzysta z `ReadProcessMemory`; chwilowo nieważny obiekt podczas przejścia/ładowania resetuje zaznaczenie zamiast być bezpośrednio dereferencjonowany.
- Dodano prawdziwy kursor `Tournament Session List` pod `0x004F02B0`. Funkcja przechodzi dokładnie po 7 panelach i ustawia `Select` tylko zaznaczonemu wierszowi, pozostałym `Normal`. Dzięki temu odświeżenie listy nie powinno już wypowiadać siedmiu turniejów po kolei; pełny opis jest mówiony tylko dla aktualnie zaznaczonego wiersza.
- E.1 dodaje dokładnie dwa nowe, potwierdzone hooki względem Build E: `0x0050FD30` (Player Match Session Room) i `0x004F02B0` (Tournament Session List). Oba hooki kopiują cztery kompletne 5-bajtowe instrukcje `mov` i zostały sprawdzone byte-for-byte na przesłanym EXE.
- Statusy `Loading/Stand/Skip/Off` z funkcji `0x0050EBF0` pozostają celowo nieprzypisane do sześciu graczy: natywny kod clampuje indeks statusu do tylko dwóch slotów `0/1`, więc nie ma bezpiecznej podstawy, by mapować je na wszystkie wiersze lobby. `Battle/Pause` również pozostają do dalszego reverse zamiast zgadywania.
- Dodano `SessionRoomReader.h`, `TournamentSelectionReader.h` i `test_build_e1_online_completion.cpp`; test E.1 sprawdza 6-wierszowy cache Session Room, czyszczenie pustych slotów, dokładne ścieżki `$PlayerName0..5` oraz 7-wierszowy tracker zaznaczenia turnieju.
- Regresja po finalnej korekcie położenia kodu kursora Tournament: 16 testów przenośnych PASS / 0 FAIL. Pięć testów zależnych od `Windows.h` oraz finalna kompilacja DLL pozostają do wykonania przez `BUILD_X64.bat` / `BUILD_DLL_ONLY.bat` na Windowsie.

## 2.72 Build E — pełny etap Online — 2026-09-08

- Player Match Session List ma teraz czytelne etykiety pól zaznaczonego pokoju: Host, Postać, Ranga, Sesja, Język, Jakość połączenia i Obszar. Zamiast serii nieopisanych wartości NVDA dostaje jeden uporządkowany opis wiersza.
- Dodano potwierdzony natywny obszar/region Player Match Session List. Builder w bieżącym EXE czyta `rec+0xA8`, wykonuje `value-1`, porównuje z `7` i wybiera jedną z ośmiu pozycji `Rep_CMN_AREA_ICON%d`; mod mówi `Obszar 1 z 8` … `Obszar 8 z 8`. Wartości spoza zakresu nie są wypowiadane.
- Player Match Session Room ma teraz czytelne etykiety pól wybranego gracza: Gracz, Postać, Ranga, Wygrane, Tytuł, Język, Jakość połączenia i Obszar. Natywny obszar jest czytany z `rec+0x44`; kod gry stosuje ten sam zakres 1–8.
- Ustawienia pokoju Player Match łączą teraz natywną nazwę opcji z natywną wartością. Gra najpierw renderuje rodziny `$PanelName0..5` / `$PanelName0..2`, a wybraną wartość zapisuje jako `$PanelValue4` lub `$PanelValue2`; mod nie mówi już samego `On/Off` bez kontekstu.
- Tournament Session List przechwytuje brakującą nazwę sesji użytkownika `$SessionName0..6` przez już istniejący custom-name writer `0x00457DD0` (return `0x004F2E15`). Opis wiersza składa potwierdzone pola: Sesja, Gracz, Eliminacja, Zasada, Czas walki, Nagroda i Język.
- Stały nagłówek Tournament Session List został opisany semantycznie: Ekran, Tryb, Sortowanie, Nazwa wartości oraz pięć wartości sortowania.
- Leaderboard `Wins/Losses` korzysta teraz z dwujęzycznych etykiet moda zamiast sztywnego angielskiego tekstu.
- Zaktualizowano testy Session List, Session Room/Lobby oraz Online Identity pod nowy format z etykietami. Dodano `test_build_e_online.cpp` i włączono go do `BUILD_X64.bat`.
- Build E nie dodaje nowego hooka. Liczba wywołań `Patch::Install` pozostaje 42, a `Patch::InstallRel8Jcc` 1 — identycznie jak w Build D.2.
- Celowo nie przypisano jeszcze statusów `Loading/Stand/Battle/Pause` do konkretnego członka lobby ani kursora Ranked/Tournament tam, gdzie reverse nie daje jednoznacznego powiązania z zaznaczonym wierszem. Te pola pozostają do dalszego potwierdzenia zamiast zgadywania.

## 2.72 Build D.2 — orientacja i automatyczna zmiana stron — 2026-09-08

- Dodano potwierdzony odczyt lewej/prawej strony fighterów bez heurystyki współrzędnych. Reflektowana funkcja gry `PlayerOnRightSide` jest zarejestrowana z wrapperem `0x0067A940`, który wywołuje natywną funkcję `0x0024B650`. Ta funkcja pobiera fightera przez resolver `0x00759120` i zwraca prawdę dokładnie wtedy, gdy `dword [fighter+0x14D4] == 1`. Resolver `0x00759120` indeksuje tę samą tabelę fighterów RVA `0x034E9970` używaną już przez Build D.
- `Ctrl+Shift+F10` podaje teraz, oprócz dystansu i X/Y/Z, także potwierdzoną orientację: `Gracz 1 po lewej / Gracz 2 po prawej` albo odwrotnie. Jeśli oba pola strony nie tworzą prawidłowej pary 0/1, orientacja jest pomijana zamiast zgadywana.
- Dodano `Ctrl+Shift+F11` do włączania/wyłączania automatycznych komunikatów zmiany stron. Funkcja jest domyślnie wyłączona. Po włączeniu odczytuje bieżącą orientację, a później mówi tylko po faktycznej zmianie.
- Automatyczny monitor działa w istniejącym wątku pomocniczym i używa wyłącznie `ReadProcessMemory`; nie wywołuje funkcji silnika i nie dodaje hooka. Kandydat zmiany musi utrzymać się przez 80 ms, co filtruje chwilowe stany przejściowe podczas cross-upów/ładowania.
- Krótkie stany przejściowe (brak poprawnej pary 0/1) są ignorowane, aby cross-up nie został zgubiony. Dopiero nieprawidłowe dane utrzymujące się przez 500 ms resetują bazę monitora jako przejście/ładowanie; po powrocie poprawnych danych nowa baza jest ustawiana cicho.
- Dodano `CombatOrientationReader.h`, `test_build_d2_combat_orientation.cpp` oraz test do `BUILD_X64.bat`. Test obejmuje dekodowanie 0/1, obie orientacje, 80 ms debounce, reset po danych przejściowych i toggle F11.
- Build D.2 nie dodaje żadnego nowego `Patch::Install`; liczba hooków pozostaje bez zmian względem D.1.

## 2.72 Build D.1 — poprawka budowania DLL — 2026-09-08

- Naprawiono workflow `BUILD_X64.bat`: programy testowe `.exe` są budowane wyłącznie w katalogu `.build_tests`, uruchamiane i usuwane; nie zaśmiecają głównego katalogu źródeł.
- Gotowa biblioteka jest teraz jednoznacznie zapisywana jako `bin\TekkenAccessibility.dll`, a następnie kopiowana także jako `TekkenAccessibility.dll` obok skryptu.
- Dodano `BUILD_DLL_ONLY.bat` do szybkiej kompilacji samej biblioteki bez tworzenia jakichkolwiek testowych `.exe`. Błędy kompilacji DLL trafiają do `BUILD_LOG.txt`.
- Ta zmiana dotyczy wyłącznie procesu budowania; kod runtime Combat Accessibility i liczba hooków pozostają bez zmian względem Build D.

## 2.72 Build D — fundament Combat Accessibility — 2026-09-08

- Dodano pierwszy potwierdzony odczyt rzeczywistej pozycji zawodników podczas walki pod `Ctrl+Shift+F10`. Odczyt podaje dystans w płaszczyźnie oraz współrzędne X/Y/Z dla fightera 1P i 2P.
- Dane nie pochodzą z HUD ani z pozycji elementów Scaleform. Reverse bieżącego EXE potwierdził reflektowaną funkcję `GetFighterOrgPos`: wrapper `0x00672D80` wywołuje natywną funkcję `0x002531E0`.
- `GetFighterOrgPos` sprawdza natywny kontekst walki pod RVA `0x034CE030`, pobiera fightera z tabeli wskaźników RVA `0x034E9970`, a następnie czyta pola `+0xE0`, `+0xE4`, `+0xE8`. Wynik gry jest dokładnie: `X=(+E8)*0.1`, `Y=-(+E0)*0.1`, `Z=(+E4)*0.1`.
- Indeksy 0 i 1 jako podstawowa para fighterów potwierdzono niezależnym kodem gry `0x00252D90`, który kolejno pobiera wpis 0 i wpis 1 przez ten sam resolver `0x00759120`.
- Mod nie wywołuje wewnętrznych funkcji gry z własnego wątku. Odczytuje te same potwierdzone pola przez bezpieczne `ReadProcessMemory`, tylko po naciśnięciu F10. Zniknięcie obiektu, brak kontekstu, nieprawidłowy wskaźnik, NaN lub nieskończoność kończą się komunikatem „Pozycja w walce niedostępna”, a nie odczytem śmieci.
- Dystans jest liczony jako odległość 2D pomiędzy natywnymi X/Y. Celowo nie przypisano jednostek, etykiet „blisko/daleko”, strony ekranu, ściany ani postawy — tych semantyk nie uznajemy jeszcze za potwierdzone.
- Dodano `CombatPositionReader.h`, `test_build_d_combat_position.cpp` i test do `BUILD_X64.bat`. Test potwierdza transformację osi, dystans 3-4-5, format PL/EN i odrzucanie NaN.
- Build D nie dodaje żadnego nowego hooka. To etap pomiarowy przed automatyczną orientacją, ścianami i stanami postaci.

## 2.72 Build C — online, kolory i QTE — 2026-09-08

- Player Match Session List odczytuje teraz natywny sześciostopniowy wskaźnik połączenia wybranego pokoju. W istniejącym builderze rekord ma poziom `0..5` pod `rec+0x28`; gra mapuje go na `PingIcon_00..05`. Mod mówi bez zgadywania jakości opisowej: `Jakość połączenia X z 6`.
- Player Match Session Room odczytuje ten sam sześciostopniowy wskaźnik dla zaznaczonego gracza. Natywny builder `0x00528000` pobiera `rec+0x00`, sprawdza `<=5` i przekazuje `raw+1` do renderera ikony. Odczyt został dodany do już istniejącego hooka wierszy.
- Customization Palette wykorzystuje potwierdzony układ zasobów: dokładnie 72 próbki `Rep_EXSKIN_COLOR_01..72` w siatce 8×9 oraz 15 zapisanych kolorów `Rep_CUSTOMCOLOR_01..15`. NVDA mówi teraz m.in. `Próbka 27 z 72, kolumna 3, wiersz 4` i `Zapisany kolor 15 z 15`; wartości poza tymi granicami są ignorowane.
- Nazwy RGB/HSV nadal nie są wymyślane. Gradient pozostaje odczytywany przez rzeczywiste współrzędne natywnego eventu 45, dopóki nie zostanie potwierdzona struktura danych koloru.
- QTE `Right` jest wypowiadane jako `Kierunek w prawo`, a nie niejednoznaczne `Prawo`. Po `Success`/`Failed` zerowany jest również obiekt poprzedniego QTE, co blokuje dziedziczenie stanu między sekwencjami. Nie zgadujemy, czy ikona oznacza D-pad czy analog.
- Dodano `test_build_c_online_customization.cpp` do `BUILD_X64.bat`. Testuje poziomy połączenia 1/6 i 6/6, odrzucanie wartości spoza zakresu, QTE Right, próbkę 72/72 i zapisany kolor 15/15.
- Build C nie dodaje żadnego nowego hooka; wykorzystuje istniejące buildery Player Match, dispatcher Character Customize i istniejącą ścieżkę QTE.

## 2.72 Build B — podstawowy UI i popupy — 2026-09-08

- Naprawiono lifecycle popupów: identyczny `SW_UI_Dialog_InputText`, `SW_UI_Dialog_IconHelp` i mały `SW_UI_Dialog_Unlock` są ponownie czytane po zamknięciu i ponownym otwarciu zamiast zostać odrzucone przez cache poprzedniego okna.
- EULA/License czyta teraz finalny, już złożony przez grę tekst z natywnego pola `$license` (setter `0x00458250`, return `0x0049B772`) zamiast składać go ponownie w warstwie mowy. Główny `$t2` rozpoczyna świeży lifecycle przy każdym wejściu, `$t2g` pozostaje tłumionym duplikatem wizualnym, a przyciski resetują cache przy nowym `$b1`.
- Usunięto możliwą podwójną mowę początkowego `SW_UI_Dialog_Steam`: początkowy `$message` jest wypowiadany przez StandardDialog tylko raz, podczas gdy osobny natywny setter nadal obsługuje późniejsze zmiany tekstu.
- Button Mapping Panel25..28 nie może już wypowiedzieć technicznych tokenów `$Operation1..4`. Jeśli cache renderera nie jest jeszcze gotowy, mod używa potwierdzonych w EXE natywnych kluczy `opt_menu_203..206`; jeśli lokalizacja chwilowo nie działa, techniczny klucz nie wycieka do NVDA.
- Dodatkowo znane klucze Button Mapping/Controller Setup nie są już zamieniane na surowe `opt_menu_*`/`story_menu_*`, gdy resolver lokalizacji jest chwilowo niedostępny; techniczne identyfikatory nie są wypowiadane.
- Graphics Options, Game Options i Sound Options resetują pamięć ostatniego wyboru po zmianie natywnego obiektu `self`, dzięki czemu ponownie utworzony ekran z tą samą pozycją/wartością nie jest błędnie traktowany jako stary duplikat.
- Dodano `test_build_b_ui.cpp` do `BUILD_X64.bat`: ponowne popupy, Steam dedupe, EULA/glow, Sound `0–10`/`0–1`, reset obiektu Options, Button Mapping 25–28 oraz Controller Setup P1/P2. Test modelu Build B: PASS.
- Audyt `BUILD_B_AUDIT.txt` potwierdza na bieżącym EXE returny wspólnego renderera i cztery klucze Button Mapping. Nie dodano żadnego nowego hooka.

## 2.72 Build A — stabilność hooków + Controller Setup — 2026-09-08

- Naprawiono krytyczny błąd trampoliny StandardDialog przy RVA `0x0049F290`. Skradziony prolog zawiera krótkie `JE +0x2B`; zwykłe kopiowanie zmieniało cel skoku na adres względem trampoliny. Nowy `InstallRel8Jcc` zachowuje warunek przez odwrócony Jcc i 14-bajtowy skok absolutny do natywnego celu `0x14049F2C4`.
- Dodano `Patch::Uninstall` i rollback instalacji wielohookowych modułów. Jeśli drugi/kolejny hook nie przejdzie, wcześniejsze hooki tej samej funkcji są przywracane zamiast pozostawiać moduł częściowo zainstalowany. Dotyczy Practice, Standard Dialog, Character Customize Selected Item, Player Match Session List oraz Player Match Session Room.
- Dodano współdzielony `PatchRelocation.h` oraz test `test_hook_relocation.cpp`; `BUILD_X64.bat` uruchamia go przed pozostałymi testami. Test potwierdza `JE 0x14049F297 + 0x2B -> 0x14049F2C4`, odwrócenie `JE`/`JNE` oraz rozmiar trampoliny 44 bajty.
- Controller Setup używa teraz istniejących natywnych kluczy `chasel_msg_034` / `chasel_msg_035`, aby przed nazwą operacji wypowiadać właściwego gracza/kolumnę. Klucze występują w przesłanym EXE; nie dodano nowego hooka ani wymyślonych etykiet.
- Sound Options Hotfix 2 pozostaje w tej gałęzi bez zmian: cztery suwaki `0–10`, przełącznik `0–1`, zakres pobierany z tabeli gry `0x02859640`.
- Ponowny skan 45 obszarów prologów potwierdził, że poza StandardDialog jedyny warunkowy skok w skradzionych bajtach to `JE rel32` w Graphics Options `0x004BDFF0`; istniejący relokator 32-bitowego displacementu już obsługuje go prawidłowo.
- Uwaga audytowa: bieżąca V2.72 już składa treść ekranu License/EULA z siedmiu potwierdzonych kluczy `license_msg_*`; wcześniejsze stwierdzenie, że odczytywany jest wyłącznie tytuł/przyciski, było nieaktualne.

## 2.72 Sound Options hotfix 2 — 2026-09-07

- Naprawiono zakres części suwaków Sound Options: wartości `7` zapisane w tabeli `0x02858C90` są wartościami domyślnymi/reset, a nie maksimami.
- Natywna obsługa wejścia `0x0052D0B0` korzysta z tabeli liczby stanów `0x02859640`: `11, 11, 11, 11, 2`. Oznacza to zakres `0–10` dla wszystkich czterech suwaków głośności i `0–1` dla przełącznika.
- Czytnik pobiera teraz liczbę stanów bezpośrednio z tej tabeli gry, więc wartości `8`, `9` i `10` nie są już odrzucane w wierszach, których wartość domyślna wynosi `7`. Hook pozostaje ten sam; nie dodano nowego hooka.

## 2.72 Sound Options hotfix — 2026-09-07

- Naprawiono całkowity brak odczytu Sound Options. Poprzedni kod odczytywał błędne pola `self+0xA8` / `self+0xB0` i był podpięty do jednorazowego renderera `0x0052C990`.
- Bieżący EXE potwierdza rzeczywisty układ Sound Options: zaznaczony wiersz `self+0x44`, wartości wierszy 0–4 w `self+0x48..0x58`, sześć natywnych kluczy etykiet w `0x028595F8`.
- Istniejący pojedynczy hook Sound Options przeniesiono na natywną funkcję obsługi wejścia `0x0052D0B0`, dzięki czemu NVDA może reagować na zmianę wiersza i wartości. Nie zwiększono liczby hooków.
- Wiersze 0–3 odczytują natywną wartość stopniową; wiersz 4 odczytuje natywny tekst dwóch stanów przez klucze `opt_menu_46` / `opt_menu_81`; wiersz 5 pozostaje akcją bez wymyślonej wartości.
- Weryfikacja statyczna: prolog `0x0052D0B0` zgodny z przesłanym `TekkenGame-Win64-Shipping.exe`; potwierdzono instrukcje korzystające z `+0x44`, `+0x48..+0x58`, tabelę sześciu etykiet oraz początkowo błędnie zinterpretowane wartości 10/7/7/7/1 z tabeli reset/default; Hotfix 2 koryguje je do zakresów 0–10/0–1. Wymagany jest test w uruchomionej grze z NVDA.

## 2.72 test — 2026-09-07

Naprawy potwierdzonych usterek audytu 2.70:
- Treasure Battle: kolory wszystkich skrzyń są zbierane przed natywnym Start i wypowiadane razem, bez przerywania sobie nawzajem. Pamięć jest zużywana po każdym wyniku; identyczne skrzynie w kolejnym wyniku znów są czytane.
- Rangi: odczyt po inicjalizacji ekranu pobiera właściwą stronę gracza i rekord rangi. Pamięć jest przypisana do rzeczywistego obiektu UI, resetowana przy inicjalizacji i zamknięciu. Poprzednia/następna ranga są ograniczone jak w natywnym kodzie gry. Dodano jedno podłączenie (łącznie 45).
- Kolejka: zdrowie, HUD i rangi są dodawane po komunikacie głównym. Nie są odrzucane tylko dlatego, że komunikat główny przerywa poprzednią mowę. Odczyty list oraz opisów czekają na swoją kolej zamiast być pobierane i tracone przy wyższym priorytecie.
- Uruchamianie: błąd jednego modułu nie zatrzymuje wspólnego czytnika. Komunikat startowy wymienia moduły, które nie uruchomiły się poprawnie; trafia też do OutputDebugString.
- Pozostałe generowane polskie komunikaty zostały przetłumaczone na angielski i częściowo skrócone. Zachowano język tekstów gry oraz nazwy graczy. Paleta wciąż odczytuje współrzędne, nie nazwy/RGB kolorów.
Weryfikacja: 14 zestawów testów, kompilacja DLL, 45 prologów i dodatkowe instrukcje oraz ścieżki UI w EXE. Testy nie potwierdzają pełnej dostępności gry ani całej kolejności NVDA podczas rozgrywki.

## 2.70 test — 2026-09-07

Select Side: odczyt Left/Right przy wejściu i podczas zmiany strony na podstawie zdarzeń natywnego ekranu. Usunięto błędny hook innego okna, odczyt dopiero po jego zakończeniu i mylne komunikaty Playing Stats dla statycznych etykiet stron. Ponowne wejście odczytuje zaznaczoną stronę. Wykorzystano dwa istniejące hooki wspólne; liczba hooków spadła z 45 do 44. Testy logiki i kontrola EXE nie zastępują testu z NVDA. Nie potwierdzono całego Treasure Battle.

## 2.69 test — 2026-09-07

Skrócony odczyt list sesji i lobby: nazwa gracza, postać, ranga bez etykiet. Usunięto polskie etykiety języka i zastąpiono komunikaty listy pokojów angielskimi. Kontekst samodzielnych komunikatów rang jest krótki i angielski: Current, Previous, Next, Left, Right. Zachowano grupowanie i kolejkę mowy. Teksty pobierane z gry zachowują język gry. Zmiana dotyczy tych czytników; nie jest pełnym audytem języka wszystkich starszych modułów.

## 2.68 test — 2026-09-07

Listy wyników wyszukiwania sesji i graczy pokoju: odczyt nazwy gracza przed postacią i rangą. Identyfikatory portretów postaci i rang pochodzą z rekordów używanych przez grę. Portret na liście nie musi oznaczać ostatecznej postaci wybranej do walki. Komunikaty rang bieżącej/poprzedniej/następnej oraz lewej/prawej strony HUD są grupowane po 350 ms bez zmian i dodawane do kolejki bez przerywania nazw. Tempo syntezatora pozostaje zgodne z ustawieniami użytkownika. Character Select pobiera identyfikator postaci z natywnej funkcji gry dla aktualnej pozycji kursora. Dziesięć zestawów testów, kompilacja, 45 prologów i 12 miejsc w EXE: PASS. Weryfikacja statyczna nie potwierdza działania wszystkich ekranów ani opcji wyboru postaci; wymagane testy w grze z NVDA.

## 2.67 test — 2026-09-07

Standardowe okna potwierdzeń: ponowne ustawienie pytania odczytuje je także przy identycznym tekście. Pierwsza zaznaczona odpowiedź jest dodawana do kolejki po pytaniu, kolejne zmiany wyboru przerywają poprzedni komunikat. Zmiana obiektu okna resetuje pamięć odpowiedzi. Testy produkcyjnego kodu obejmują powtórne pytanie, kolejność mowy, nawigację i zakres indeksów.

## 2.66 test — 2026-09-07

Grafika: usunięto powtórny odczyt tej samej pozycji po wejściu na stronę. Tytuł strony jest oddzielony od porównywanego tekstu pozycji. Zachowano odczyt zmian wartości, identycznych etykiet różnych pozycji i powrotu z podmenu. Dodano testy tego zachowania.

## 2.65 test — 2026-09-07

Dźwięk: ostatnia pozycja (indeks 5) nie odczytuje już liczby z pamięci jak suwak. Natywny interfejs ustawia dla niej OptionValue_mc stan None (0x52CAA8). Pozostaje odczyt etykiety. Pełne przebiegi ustawień grafiki, gry i sterowania nie zostały przetestowane.

## 2.64 test — 2026-09-07

Lista ciosów: reset zapamiętanego wyboru po zamknięciu oraz zmianie obiektu interfejsu. Native movie jest pobierane z self+0x180; zamknięcie potwierdzono przy powrocie 0x48DF9E z animacją End. Zapobiega wyciszeniu tego samego ciosu przy ponownym otwarciu. Nie dodano nowych tłumaczeń symboli przycisków.

## 2.63 test — 2026-09-07

Practice: zmiana strony lub wiersza menu nie jest wyciszana tylko dlatego, że tekst jest identyczny z poprzednim. Powtórne odświeżenie tej samej pozycji nadal jest wyciszane. Przegląd nie potwierdza pełnej dostępności treningu ani wszystkich symboli listy ciosów.

## 2.62 test — 2026-09-07

Lobby Player Match: zapamiętywanie wszystkich 10 wierszy graczy, odczyt po zmianie zaznaczenia oraz połączenie nazwy, zwycięstw, tytułu i języka. Przebudowanie listy usuwa stare dane. Gotowość i rozpoczęcie walki nie zostały potwierdzone w działającym lobby.

## 2.61 test — 2026-09-07

Create Session: odświeżenie wartości zapisuje dane bez odczytu niezaznaczonych pól. Po zakończeniu obsługi wejścia odczytywane jest bieżące ustawienie i jego końcowa wartość. Dodano kontrolę liczby pozycji oraz testy nawigacji, zmian zależnych pól i przycisku tworzenia.

## 2.60 test — 2026-09-07

Customization: dodano odczyt Kopiuj i Usuń przy wyborze opcji menu zestawu. Mapowanie potwierdzono w bieżącym zasobie GFX i zdarzeniach natywnych 15/16. Wymagany test z NVDA.

## 2.59 test — 2026-09-07

Usunięto prefiks Pokój i numer wiersza. Opóźnienie odczytu skrócono z 250 do 40 ms (plus cykl wątku). Nowe zaznaczenie przerywa wcześniejszy komunikat, dzięki czemu szybkie przewijanie nie tworzy kolejki starych pokojów.

## 2.58 test — 2026-09-07

- Search Sessions: zapamiętywanie nazw, gospodarzy i języków wszystkich 11 wierszy bieżącej strony wyników, również przed zaznaczeniem.
- Odczyt zaznaczonego pokoju łączy pola w jeden komunikat po krótkim oczekiwaniu na uzupełnienie danych. Powrót do wcześniej odczytanego pokoju ponawia komunikat.
- Obsługa osobnej funkcji gry dla własnych nazw pokojów.
- Przebudowanie strony usuwa stare wiersze; identyczne odświeżenie nie powtarza odczytu.
- Ctrl+Shift+F9: odczyt wszystkich zebranych pokojów na bieżącej stronie. Numer oznacza wiersz wyświetlania, nie globalny indeks wyniku wyszukiwania.
- Pięć zestawów testów logiki PASS; 44 prologi podpięć zgodne z EXE. Wymagane sprawdzenie podczas gry z NVDA.
- Poprawka dotyczy pól tekstowych wyników. Nie potwierdza pełnego odczytu ikon połączenia, ograniczeń wejścia ani wszystkich szczegółów pokoju.

# Tekken Accessibility — historia zmian

Wersje testowe 2.54–2.57, przygotowane 6 września 2026 r. Historia obejmuje zmiany wykonane w tym projekcie; nie rekonstruuje wcześniejszych wydań.

## 2.57 test

- Dodano odczyt czasu rundy i automatyczne komunikaty przy 30, 10, 5 oraz 0 sekundach. Specjalna wartość czasu jest opisywana jako brak odliczania; starsze dane są oznaczane wiekiem odczytu.
- Dodano informację o aktywacji i zakończeniu Rage po lewej i prawej stronie HUD.
- Dodano odczyt numeru włączanego znacznika wygranej rundy i jego strony HUD.
- Dodano komunikat wejścia w tryb kopiowania zestawu oraz oznaczenie wybieranego celu kopiowania w Customization.
- Dodano Ctrl+Shift+F7 do odczytu czasu i Rage oraz Ctrl+Shift+F8 do przełączania automatycznych komunikatów czasu, Rage i rund.
- Weryfikacja: cztery zestawy testów logiki przeszły, DLL x64 skompilowano, a 42 prologi podpięć porównano z plikiem EXE. Dodatkowo sprawdzono adresy wywołań, format argumentów liczbowych i zdarzenia kopiowania.

## 2.56 test

- Przywrócono dostęp do wcześniej wyciszanych opisów, pomocy, zasad i ostrzeżeń kontrolera, w tym 38 dodatkowych dróg przekazywania komunikatów.
- Dodano zbieranie opisów i odczyt po krótkiej przerwie, bez przerywania nazwy wybranej opcji. Długie opisy można czytać na żądanie lub fragmentami.
- Zachowano wypowiadane identyfikatory znaczników ikon `<#...>`, zamiast usuwać je razem ze znacznikami formatowania.
- Dodano odczyt QTE dla natywnych ikon Y, X, RB i kierunku w prawo oraz komunikaty sukcesu i niepowodzenia. Nieznana ikona nie powoduje powtórzenia starego polecenia.
- Dodano odczyt procentowego zdrowia obu pasków HUD oraz komunikaty progowe przy 50%, 25%, 10% i 0%. Poprawiono usuwanie nieaktualnych ostrzeżeń po regeneracji i rozpoczęciu nowej rundy.
- Dodano nawigację głosową po pozycjach palety: próbki, gradient, zapisane kolory i numer obszaru kolorowania. Próbki i gradient zachowują osobne współrzędne.
- Dodano numer zestawu stroju do jego nazwy, aby odróżniać zestawy o jednakowych nazwach.
- Dodano skróty Ctrl+Shift+F1–F6, opisane poniżej.
- Weryfikacja: trzy zestawy testów logiki przeszły, DLL x64 skompilowano, a 40 prologów podpięć porównano z EXE. Sprawdzono też wywołania QTE, argumenty zdrowia i zdarzenia palety.

## 2.55 test

- Rozszerzono poprawkę ustawień wyszukiwania na Ranked Match: wybrana opcja, jej wartość i przycisk rozpoczęcia.
- Poprawiono Story: odczyt wybranego rozdziału i epizodu postaci, zmian stron i zakładek, ukończenia, opisu trudności oraz tekstów prologu i plansz fabularnych.
- Połączono numer i tytuł rozdziału w jeden komunikat.
- Poprawiono Customization: odczyt wskazanej postaci zamiast całej listy oraz łączenie nazwy wybranego przedmiotu z ceną, licznikiem i rozpoznanym stanem.
- Rozszerzono odczyt przedmiotów Player Customization.
- Weryfikacja: testy logiki i kompilacja przeszły; 39 podpięć oraz 30 dodatkowych adresów wywołań sprawdzono względem EXE. W ramach analizy rozpakowano i zweryfikowano 26 467 wpisów zasobów UI, obejmujących 24 853 unikalne ścieżki. Nie oznacza to przetestowania wszystkich ekranów w grze.

## 2.54 test

- Naprawiono odczyt ustawień Quick Match i Search Session, wykorzystując właściwy natywny ekran ustawień online.
- Dodano odczyt wybranej opcji wraz z wartością i przyciskiem rozpoczęcia, obsługę zmian wartości oraz ponownego wejścia do menu.
- Ograniczono powtórzenia i mieszanie danych między trybami. Usunięto niewłaściwe podpięcie funkcji listy wyników używane wcześniej do ustawień wyszukiwania.
- Weryfikacja: testy logiki, kompilacja i sprawdzenie odpowiednich adresów w EXE przeszły.

## Skróty w wersji 2.72 Build D.2

Działają przy aktywnym oknie gry. Wszystkie używają modyfikatorów Ctrl+Shift.

- F1: odczyt zebranych opisów kontekstu UI.
- F2 / F3: następny / poprzedni fragment opisu.
- F4: przełączanie automatycznych opisów.
- F5: odczyt obu pasków zdrowia.
- F6: przełączanie komunikatów zdrowia.
- F7: odczyt czasu i Rage.
- F8: przełączanie komunikatów czasu, Rage i znaczników rund.
- F9: odczyt wszystkich zebranych wierszy wyników sesji na bieżącej stronie.
- F10: odczyt dystansu, X/Y/Z obu fighterów i — gdy potwierdzone — ich lewej/prawej strony.
- F11: przełączanie automatycznych komunikatów zmiany stron podczas walki.

Przełączniki obowiązują do zamknięcia gry. Dotychczasowe automatyczne komunikaty pozostają domyślnie włączone; automatyczne komunikaty zmiany stron z F11 są domyślnie wyłączone.

## Ograniczenia

Są to wersje testowe. Kontrole kodu i plików nie zastępują pełnego sprawdzenia z NVDA podczas grania. Lewy i prawy pasek odnoszą się do pozycji w HUD, nie automatycznie do własnej postaci i przeciwnika. QTE podaje natywne nazwy ikon, bez tłumaczenia na indywidualne przypisanie klawiszy.

Nie ukończono jeszcze pełnych etykiet okien podręcznych, rzeczywistych wartości RGB i nazw kolorów, pozostałych elementów HUD ani audiodeskrypcji filmów. Odczyt pozycji palety nie jest rozpoznawaniem koloru. Wtyczka nie jest jeszcze potwierdzona jako zapewniająca pełną dostępność całej gry.
