# Tekken 7 Access 3.20.32

NVDA announces the nickname of a player who joins or leaves the room. Players already present when the room opens aren't announced as new arrivals.

# 3.20.31

Room options opened with X: selected row, entry selection and changed value speech.
Room-name confirmation: native question with entered name and current Yes/No; arrow changes speak the selected answer.
Chat: capture actual sender/message records and browse spoken history via native scroll actions. The first scroll reads the newest captured message; subsequent up/down actions browse older/newer entries. This accessibility cursor is independent of visual pixel scrolling.

# 3.20.30

Graphics Options: announce the current value after left/right changes; suppress unchanged redraws.

## 3.20.29 — audit fixes

- Room search and lobby speech now cancels immediately on focus loss and expires after one second. Cached data remains available for manual reading.
- Leaderboard character filtering captures indexed names, including All characters, and announces only the current selection in the native nine-column grid. Grid population is silent.
- Rapid movement selects the latest cursor position. Closing cancels pending filter speech; reopening can announce the same selection again.
- Adds two signature-checked hooks: filter opening and cursor movement. Live game/NVDA validation is still required.

## 3.20.28 — complete room details while scrolling

- Fixed room-record selection during search-result scrolling. The native argument is an animation direction, not the first row index.
- Negative direction no longer skips character, rank, connection and area metadata. Records now follow the game's panel mapping, including later pages.
- Preserves host, session name, language and rapid navigation. No new hooks.
- Live game testing is still required: navigate down and up, including across page boundaries.

## 3.20.27 — Online leaderboard

- Fixed indexed player-name matching and added selected-row speech: nickname, leaderboard position and available numeric score.
- Selection follows the native Select1 event, including the native panel offset during scrolling. Briefly coalesced speech reads the latest selection.
- Filter text is handled through both existing text routes. Changed filters invalidate old rows; empty names clear row data.
- No new game hooks. Live game/NVDA testing remains required, especially page scrolling and filter changes. Row character/rank icons are outside this fix.

## 3.20.26 — dialogue subtitles

- Read native movie and battle subtitles when the game displays them, rather than when preloaded.
- Repeated frames do not repeat speech. Each new subtitle interrupts the previous utterance to avoid a stale speech queue.
- Respects Ctrl+Shift+F4 and the game foreground state. Enable subtitles in the game settings.
- Dialogue stays in the game's subtitle language. Ctrl+L changes mod language; it does not translate game dialogue.
- Does not add cinematic audio description or new special Story objectives. Live game/NVDA validation remains pending.

## Launcher / Updater v5 — PL

- Pobieranie changelogów PL/EN w formatach MD i TXT, z pierwszeństwem aktualnego MD.
- Możliwość uzupełnienia changelogów dla już zainstalowanej wersji bez podmiany DLL.
- Wybór paczki TekkenAccessibility-NUMER.zip zamiast archiwum źródeł.
- Przygotowanie plików i kopii zapasowych przed podmianą; brak oznaczenia nieudanej aktualizacji jako zakończonej.
- Launcher czeka na zakończenie updatera, także po przekroczeniu dwóch minut. Nie uruchamia gry po błędzie aktualizacji; brak sieci pozwala na uruchomienie istniejącej instalacji.
- Narzędzia nie podmieniają samych siebie. Wersja DLL moda pozostaje 3.20.25.

## Launcher / Updater v5 — EN

- Download PL/EN changelogs in MD and TXT formats, preferring the current Markdown files.
- Repair changelogs for an already installed release without replacing DLLs.
- Select TekkenAccessibility-VERSION.zip instead of a source archive.
- Stage files and backups before replacement; failed updates are not marked complete.
- Wait for the updater to finish, including runs longer than two minutes. Update failure blocks game launch; offline checking permits startup of the existing installation.
- The tools do not replace themselves. The mod DLL version remains 3.20.25.


# Tekken Accessibility 3.20.25 — Story reading controls

## Polski

- Ctrl+Shift+F1 powtarza przechwycony tekst Story, również tytuł i numer rozdziału.
- Ctrl+Shift+F2/F3 czyta następny/poprzedni fragment narracji, z numerem fragmentu. Fragmenty mają do 400 znaków; preferowane są granice słów i zdań. Po ostatnim następuje pierwszy.
- Ctrl+Shift+F4 obejmuje teraz automatyczną narrację Story oraz tytuły rozdziałów. Wyłączenie nie usuwa tekstu dostępnego ręcznie. Ustawienie obowiązuje w bieżącej sesji gry i domyślnie jest włączone.
- Zmiana tekstu lub języka rozpoczyna przeglądanie fragmentów od początku. Zwykłe odświeżenie nie zmienia pozycji.

Jeśli nie ma przechwyconej narracji Story, F1/F2/F3 obsługują dotychczasowe opisy ekranu. F4 nie wyłącza nawigacji menu ani poleceń QTE. Napisy dialogowe, specjalne cele walk i audiodeskrypcja filmów pozostają poza zakresem tej poprawki.

Przed podmianą DLL zamknij grę. Do sprawdzenia w Story: długi prolog, F2/F3, wyłączenie F4 przed kolejnym tekstem, ręczny odczyt F1 i powrót do menu.

## English

- Ctrl+Shift+F1 repeats captured Story text, including the chapter title and number.
- Ctrl+Shift+F2/F3 reads the next/previous narrative fragment with its position. Fragments contain up to 400 characters, preferring word and sentence boundaries. Navigation wraps around.
- Ctrl+Shift+F4 now controls automatic Story narration and chapter titles as well as descriptions. Muting preserves manual reading. This setting lasts for the current game session and defaults to on.
- New text or a language change resets fragment navigation. Identical redraws preserve the current position.

Without captured Story narration, F1/F2/F3 retain their existing description behavior. F4 does not disable menu navigation or QTE prompts. Dialogue subtitles, special battle objectives and cutscene audio description are outside this update.

Close the game before replacing the DLL. Live checks: a long prologue, F2/F3, disabling F4 before the next text, manual F1 reading and returning to menus.


# Tekken Accessibility 3.20.24 — Story text replay

## Polski

- Ctrl+Shift+F1 ponownie odczytuje ostatni przechwycony tekst prologu lub planszy fabularnej, dopóki ekran pozostaje aktywny.
- Identyczna treść na innym obiekcie ekranu lub w innym typie planszy nie jest już pomijana przez wspólną pamięć ostatniego tekstu.
- Zamknięcie bieżącego ekranu, rozpoczęcie ekranu i wyczyszczenie tekstu usuwają zapamiętaną narrację. Zwykłe odświeżenia identycznej treści pozostają ciche.

Dotyczy istniejących pól $prologue_text oraz $story. Nie dodaje audiodeskrypcji filmów ani rozpoznawania wszystkich specjalnych celów walki. QTE pozostaje przy wcześniejszym odczycie natywnych ikon; nie tłumaczy ich na własne przypisania klawiatury. Potrzebne są testy w grze: prolog epizodu, plansza fabularna, ponowny odczyt, powrót do menu i ponowne wejście.

Zamknij grę przed aktualizacją DLL. Wcześniejsze poprawki, w tym rewanże, pozostają dostępne.

## English

- Ctrl+Shift+F1 repeats the last captured prologue or story-panel text while its screen remains active.
- Identical text from a different screen object or narrative type is no longer suppressed by shared text deduplication.
- Closing the current screen, starting a screen or clearing the text discards the stored narrative. Identical redraws stay silent.

Applies to the existing $prologue_text and $story routes. This does not add cutscene audio description or recognition of every special battle objective. QTE retains its existing native icon announcements, without mapping custom keyboard bindings. Live checks are still needed for prologues, story panels, repeat reading, menu return and re-entry.

Close the game before updating the DLL. Earlier fixes, including revenge prompts, are retained.


# Tekken Accessibility 3.20.23

## Polski

Poprawiono odczytywanie znaczników koloru w pytaniu o rewanż. Zgłoszony komunikat „Request Revenge Match <font color = '#cc0000'>9</font> secs left, 1 z 4” jest teraz przekazywany do czytnika jako „Request Revenge Match 9 secs left, 1 z 4”. Liczba oznacza pozostały czas, nie nick gracza.

Usuwanie sparowanych znaczników font/color działa przed wysłaniem mowy do NVDA i Tolk, również dla komunikatów dopisywanych do kolejki. Nie zmienia tekstu wyświetlanego przez grę. Zachowuje liczby, treść komunikatu i zwykłe nazwy z nawiasami kątowymi. Obejmuje odczyt używany w Ranked i Quick Match; wymaga potwierdzenia obu trybów w grze.

Zamknij grę przed podmianą TekkenAccessibility.dll. Zachowano funkcje wersji 3.20.22.

## English

Fixed color markup being spoken in the revenge-match prompt. The reported text is now sent to the screen reader as “Request Revenge Match 9 secs left, 1 z 4”, without the font tags. The number is the countdown, not a player name.

Paired font/color tags are removed before speech reaches NVDA or Tolk, including appended speech. The game's display is unchanged. Numbers, message content and ordinary angle-bracket names are preserved. This covers the speech path used by Ranked and Quick Match; both modes still need live confirmation.

Close the game before replacing TekkenAccessibility.dll. Version 3.20.22 features are retained.


# Tekken Accessibility 3.20.22 — combat speech controls

## English

- Ctrl+Shift+F10 now reads a short distance and side summary. Add Alt for the full coordinates.
- Ctrl+Shift+Alt+F12 toggles automatic down-state announcements. The setting lasts for the current game session and defaults to on. Ctrl+Shift+F12 still reads combat status.
- Automatic side and down-state readers discard pending observations when the game loses focus, preventing an old transition from being announced on return.
- English and Polish speech remain available through Ctrl+L.

Distance uses the game's native position scale; it is not a claim about attack range or metres. Leaving the down state does not necessarily mean standing up.

These changes improve existing combat readers. Wall proximity, throw-break cues, attack height and complete combat audio guidance are not implemented in this release. Full accessibility is not yet verified; live testing with a screen reader is still required.

Close the game before updating TekkenAccessibility.dll in TekkenGame/Binaries/Win64. Keep a backup of your previous DLL.

## Polski

- Ctrl+Shift+F10 odczytuje krótką informację o odległości i stronach. Dodanie Alt odczytuje pełne współrzędne.
- Ctrl+Shift+Alt+F12 włącza lub wyłącza automatyczne komunikaty powalenia. Ustawienie obowiązuje do zamknięcia gry; domyślnie komunikaty są włączone. Ctrl+Shift+F12 nadal odczytuje stan walki.
- Czytniki zmiany stron i powalenia usuwają oczekujące obserwacje po opuszczeniu okna gry, aby nie ogłaszać starej zmiany po powrocie.
- Ctrl+L nadal przełącza odczyt polski i angielski.

Odległość korzysta z natywnej skali pozycji gry. Nie oznacza metrów ani zasięgu ciosu. Zakończenie stanu powalenia nie musi oznaczać stania.

Ta wersja usprawnia istniejące czytniki walki. Nie dodaje wykrywania bliskości ściany, podpowiedzi zrywania rzutów, wysokości ataków ani pełnego prowadzenia dźwiękiem podczas walki. Pełna dostępność pozostaje niepotwierdzona; potrzebne są testy w grze z czytnikiem ekranu.

Przed aktualizacją zamknij grę i zachowaj kopię starej DLL. Nową TekkenAccessibility.dll skopiuj do TekkenGame/Binaries/Win64.


## 3.20.21 — Pre-fight loading screens

- Direct VS names use the game's native fighter-key resolver instead of the handwritten roster.
- Fallback pairing uses explicit left/right fields, handles reverse arrival order and mirror matches, and ignores duplicate writes from the same side.
- Every native Makuai initialization resets pairing even when memory addresses are reused, preserving a valid Online handoff.
- Added exact Makuai_mc / End lifecycle handling through verified return 004D53EA and animation function 004557F0. This adds one hook (49 active); partial installation rolls back the new hook.
- Retains Online 3.20.20, Customization 3.20.19 and both languages. Offline tests and executable agreement do not establish complete live coverage of every loading screen, Story transition, asset variant, or Tekken Power display. Full NVDA mode-by-mode validation remains required.


## 3.20.20 — Online selection and speech lifecycle

- A selected row with missing character data no longer falls back to another row. Unique-opponent fallback is permitted only before the first cursor event; explicit invalidation is distinct from an unobserved cursor.
- Incomplete row refreshes do not supply a character. Empty/ambiguous selections invalidate the previous opponent from that list family.
- Queued VS speech is discarded on focus loss, matching screen close, or after five seconds. The existing 1.1-second settling delay remains.
- Closing the source list preserves an already captured direct VS pair. Closing an older VS screen does not erase a newer opponent. A fresh screen may reuse the previous memory address without suppressing the same fighter pair.
- Shared VS state is protected by a mutex; speech delivery occurs outside the lock. Added production-reader regression and concurrent producer/consumer tests.
- No new game address or hook; Customization 3.20.19 and Polish/English support are retained. Live NVDA testing of readiness, disconnections, rematches and complete sessions is still required.


## 3.20.19 — Customization

- Added deferred Copy/Delete speech and the actual copy destination cursor (native event 22, separate from ordinary outfit event 18).
- Added palette navigation: 72 swatches in an 8×9 grid, gradient coordinates, 15 saved colors and color area number, in English and Polish.
- New event capture copies integers without calling speech/localization from the native dispatcher. The existing accessibility worker speaks after native dispatch completes. Duplicate redraws are suppressed; rapid movement is coalesced.
- Unknown initial coordinates are not presented as the first color. Closed/background/stale pending speech is discarded.
- RGB/HSV and color names are not implemented. Copy/Delete selection does not confirm operation success. Full save/copy/delete workflows and live NVDA behavior still require testing. The legacy combined dispatcher remains disabled.

## 3.20.18 — 2026-09-09

Fix Tournament metadata refresh at an unchanged visible row, six audit test issues, and build failure handling. Add a production-function Tournament regression test, runtime dependencies, and a release builder gated on successful tests. Full-accessibility limitations remain documented.

## V3.20.17 SAFE — Tournament Session List connection quality and area — 2026-09-09

- Base is the live-confirmed V3.20.16. Online/Offline VS, fast Pause Menu, ULTIMATE TEKKEN BOWL, Online player names and Character Customization remain unchanged.
- The Online sweep found a useful Tournament Session List gap that can be filled without a new hook: the selected row did not announce the connection-quality or area icons.
- `tekken.zip` proves the native Tournament list record model. `self+0x480` is the record count, `self+0x484` is the absolute selected record (also used directly at `0x004F07C4` when entering the selected session), `self+0x510` is the record array, and each record is `0xE0` bytes.
- Connection quality is read from selected `record+0x28` exactly as the game does at `0x004F2D87` (native 0..5 => `Connection quality 1..6 of 6`). Area is read from `record+0xA8` exactly as the game does at `0x004F378B` (native 1..8 => `Area 1..8 of 8`).
- The existing Tournament cursor hook at `0x004F02B0` is reused. On every native cursor callback the mod refreshes only the selected row's icon-only metadata; this also handles scrolling where the visible cursor stays on an edge row while the absolute record changes.
- All native reads use guarded `ReadProcessMemory`. Invalid owner/count/index/pointer/range data clears/omits the metadata rather than reusing stale values or guessing.
- Per-member `Loading / Stand / Battle / Pause` status remains intentionally unmodified: the verified `0x0050EBF0` helper describes only two special status slots and does not prove a one-to-one mapping for all six Player Match room members.
- No hook or worker thread is added. `Patch::Install` remains `43`, Rel8 call sites remain `1`, and `InitThread` remains `36` installs. Named RVA/OFF definitions and values are unchanged from V3.20.16.
- Portable regression: **71 PASS, 0 FAIL**; 5 Windows/MSVC-only tests remain for the release builder.

## V3.20.16 SAFE — fighter speech on all Offline VS/loading screens — 2026-09-09

- Base is the live-confirmed V3.20.15. Fast Pause Menu, Online VS, ULTIMATE TEKKEN BOWL, Online player names and Character Customization remain unchanged.
- The Offline failure had a specific cause: the existing `SwfMakuai` hook at `0x004D55F0` already read native fighter IDs from `self+0x110` and `self+0x1D8`, but the whole detour was gated by `OnlineVersusLoadingReader::IsOnlineMode()`. Offline therefore discarded the direct pair.
- `tekken.zip` confirms that helper `0x004D55F0` belongs to shared `SW_UI_Makuai` initialization: `.text` contains exactly one call to it, from `0x004D42F7`. Inside the helper the two-side loop reads the first fighter from `self+0x110`, advances by the native `0xC8` side stride, then reads the second from `self+0x1D8`.
- V3.20.16 removes only the Online-only gate. The same already-installed hook now collects the fighter pair for Arcade/Practice/Treasure and other Offline fights using `SW_UI_Makuai`.
- The pair keeps the existing `1100 ms` settle and sentence pause, e.g. `Lili. Versus Kazuya.`, so NVDA has time to finish it.
- Once the direct Makuai helper owns the screen, the older immediate V3.20.9 setter collector is suppressed for that same owner, preventing duplicate speech. The old path remains as a fallback for an unexpected Makuai route not seen by the direct helper.
- No hook or thread is added. `Patch::Install` remains `43`, Rel8 `1`, `InitThread` `36`.
- Portable regression: **69 PASS, 0 FAIL**; 5 Windows/MSVC tests are run by the builder.

## V3.20.15 SAFE — fast Pause Menu in every verified mode — 2026-09-09

- Base is the live-confirmed V3.20.14. Online VS, ULTIMATE TEKKEN BOWL, Online names, offline VS and Character Customization remain unchanged.
- `tekken.zip` confirms that normal `SwfPauseMenu` cursor movement in every variant uses the same native `Select`: animation setter `RVA 0x00453950`, return `0x004F4AD1`.
- The existing immediate Treasure route is extended to every mode with a verified native cursor→action table: mode 0 `0x02845B48` (8), mode 1 `0x02845B68` (6), mode 2 `0x02845B80` (8), mode 3 `0x02845BA0` (8), mode 4 `0x02845BC0` (8), mode 5 `0x02845BE0` (4), mode 6 `0x02845BF0` (6), mode 8 `0x02845C08` (4).
- The selected item is announced **before** the original Scaleform animation, so NVDA no longer waits for the large Pause Menu input routine or selected-row redraw.
- Mode 7 intentionally stays on the legacy fallback: native helper `0x004F3F20` has no cursor→action table branch for mode 7, so the mod does not guess.
- No hook or thread is added. `Patch::Install` remains `43`, Rel8 `1`, `InitThread` `36`.
- Portable regression: **67 PASS, 0 FAIL**; 5 Windows/MSVC tests are run by the builder.

## V3.20.14 SAFE — paced Online VS fighter announcement — 2026-09-09

- Base is the live-confirmed V3.20.13. Direct native fighter IDs from `SwfMakuai` remain unchanged.
- The fighter pair is no longer spoken immediately inside the Makuai hook. It is queued and delivered by the **existing accessibility worker** after a `1100 ms` settle interval so the first VS-screen redraw can finish first.
- The announcement now includes a sentence pause, for example `Lili. Versus Kazuya.` instead of the faster `Lili versus Kazuya`.
- Later `$playername_L/$playername_R` account-name writes remain claimed and cannot trigger the old cached-opponent fallback once the direct pair is known.
- No hook or thread is added. `Patch::Install` remains `43`, Rel8 remains `1`, and `InitThread` remains at `36` installs.
- Online player names, ULTIMATE TEKKEN BOWL, Treasure Pause, offline VS and Character Customization are unchanged.
- Portable regression: **65 PASS, 0 FAIL**; 5 Windows/MSVC-only tests remain for the release builder.

## V3.20.13 SAFE
- Online VS/loading reads both fighters directly from native `SwfMakuai`.
- One isolated hook at `0x004D55F0`; fighter IDs are `self+0x110` and `self+0x1D8`.
- The V3.20.12 cache remains as fallback.
- Bowl, Pause, Online player names and Customization are unchanged.

## 3.20.12 — SAFE: Online VS/loading opponent character — 2026-09-09

- Base is the live-confirmed V3.20.11; working Treasure Pause, ULTIMATE TEKKEN BOWL, Online names, offline VS and Character Customization stay unchanged.
- Online VS never treats `$playername_L/$playername_R` account names as fighter names. Those fields are used only as the native Makuai loading-screen signal.
- Existing Ranked/Quick Match and Player Match readers feed a small cache only with a native, already-localized opponent character name.
- A proven selected row wins. Quick/automatic matchmaking may use the only available candidate; with multiple unselected candidates the mod stays silent rather than guessing.
- On Online VS/loading NVDA announces once, for example `Opponent: Kazuya`. Repeated redraw of the same Makuai owner is suppressed.
- No new hook or worker thread; the feature reuses existing Online readers and the shared Makuai setter.

## 3.20.11 — SAFE: Treasure Battle pause speech before Scaleform animation — 2026-09-09

- Fixed the remaining NVDA latency while rapidly moving through the Treasure Battle pause menu.
- `tekken.zip` confirms that after the cursor changes, the game calls the global animation setter at `RVA 0x00453950` with `Select` from `0x004F4ACC` (return `0x004F4AD1`). V3.20.10 announced only after that setter returned.
- V3.20.11 announces the new item **before** the original Scaleform animation runs, but only for the exact `Treasure mode 4 + Select + 0x004F4AD1` event. Every other consumer of the global animation hook keeps the stable existing order.
- The native action table at `RVA 0x02845BC0`, localization mapping and legacy PauseMenu fallback are unchanged.
- No new hooks or worker threads; Bowl, Online, VS and Customization are unchanged.

## 3.20.10 — SAFE: immediate Treasure Battle pause cursor — 2026-09-09

- Live testing showed that Treasure Battle pause navigation still reacted slowly during rapid cursor movement. The legacy `PauseMenu` reader spoke only after the large native input function at `RVA 0x004F4A00` had finished.
- `tekken.zip` confirms that after a cursor change the selected row calls the already-installed global animation setter at `RVA 0x00453950`; the exact return after the native `Select` state is `0x004F4AD1`.
- For Treasure Battle (`mode 4`), V3.20.10 reads the action immediately from the game's native cursor-to-action table at `RVA 0x02845BC0`, before the game later writes `self+0x460`. NVDA therefore reacts to the native cursor selection itself instead of waiting for the entire pause handler to finish.
- The legacy `PauseMenu` route remains as a fallback. The direct path writes the same cache state so the later fallback cannot duplicate the announcement.
- The change is restricted to Treasure Battle. Online, ULTIMATE TEKKEN BOWL, VS/loading speech and working Character Customization are unchanged.
- No new hook or thread is added. `Patch::Install` remains 42, Rel8 remains 1, and `InitThread` still has 35 `::Install()` calls.
- Portable regression: 57 PASS, 0 FAIL; 5 Windows-only tests remain for MSVC.

## 3.20.9 — SAFE: both fighter names on the VS / fight-loading screen — 2026-09-09

- Live-tested V3.20.8 is the code base. Working ULTIMATE TEKKEN BOWL, Online, and Character Customization paths remain unchanged.
- `tekken.zip` is the only game-data source (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- `tekken.zip` confirms that `SW_UI_Makuai` reads the fighter id from `Makuai + side*0xC8 + 0x110`, calls the fighter-name resolver at `0x004D45FD`, localization at `0x004D460C`, then sends the final display name through the already-hooked shared setter `0x00458250`. The exact VS return address is `0x004D4646`.
- V3.20.9 uses only that existing setter hook. It collects the two final localized fighter names and announces the pair once, for example `Lili versus Kazuya`.
- Local/opponent side ownership is deliberately not guessed; game display order is preserved. Mirror matches such as `Lili versus Lili` therefore remain valid.
- Same-pair redraws in the same Scaleform movie are suppressed.
- New hooks: 0. New threads: 0. The problematic full `CharacterCustomizeSlotSelect::Install()` remains disconnected.
- Portable regression: 55 PASS, 0 FAIL; 5 Windows-only tests remain for MSVC.
- Public version: V3.20.9.

## 3.20.8 — SAFE: direct native ULTIMATE TEKKEN BOWL cursor speech — 2026-09-09

- Stable V3.20.7 is the code base. Online is intentionally unchanged after the live test confirmed it is working. `tekken.zip` remains the only game-data source (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Live testing showed that V3.20.7 still felt slow in ULTIMATE TEKKEN BOWL. The 3-ms speech coalescer was not the main delay: the old Bowl speech path waited for later button-help/HUD redraw text before it had anything useful to announce.
- `tekken.zip` confirms that `SwfBowlingMenu` changes the main-menu cursor through the already-hooked animation setter `RVA 0x00453950`; its selected-item call returns at `0x0045A74A` with state `Select`. The submenu uses the same setter and returns at `0x0045A7FA`.
- V3.20.8 therefore speaks the selected Bowl entry directly from that native `Select` event. It does not wait for `DescriptionRuntime`, the 40-ms worker cadence, the 3-ms settle window, or the later button-help redraw.
- Labels are not guessed. They are cached from the game's already-hooked shared text renderer `RVA 0x004570E0`: main labels return at `0x0045BCAE`; verified submenu label branches return at `0x0045A95D` and `0x0045AAAD`. `$MainN_Glow` / `$SubN_Glow` companion fields are deliberately ignored.
- No new hook or thread is added. The five new RVAs are caller filters inside the two existing global hooks, not patch targets. No existing RVA/OFF value is changed.
- During direct cursor movement, stale pending Bowl speech is dropped and the newest secondary button-help redraw is deferred until the cursor settles, so it cannot overtake the newly selected item. Primary Bowl player/HUD information remains available.
- Stable Online behavior from V3.20.7 and stable Character Customization character/slot behavior remain unchanged.
- Portable regression: 53 PASS, 0 FAIL; 5 Windows-only tests remain for MSVC.
- Public version: V3.20.8.

## 3.20.7 — SAFE: Quick Match no longer speaks `online_other_088` and Ultimate Tekken Bowl wakes immediately — 2026-09-09

- Stable V3.20.6 is the code base. `tekken.zip` remains the only game-data source (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Live testing showed that Quick Match could still speak the internal id `online_other_088`. V3.20.7 blocks unresolved `online_other_###` at the final `T7Speech` layer, so that technical key can no longer reach NVDA/Tolk.
- The native final `$playername_l` and `$playername_r` fields now use the same `OnlinePlayerText::RawName` path as the other corrected player-name fields. A transient `online_other_###` is not cached as a nickname, while the next real nickname remains immediately speakable.
- Direct native Online `std::string` object reads also pass through `RawName`, and the Player Match Session Room player field ignores a transient placeholder instead of overwriting the real name with it.
- Ultimate Tekken Bowl no longer waits for the next 40-ms poll of the existing worker plus the old 20-ms debounce. `BowlNavigationReader::Put()` wakes that same existing worker through a `condition_variable`; after only a 3-ms same-redraw settle window it speaks the newest position.
- No new thread or hook was added. When Bowl publishes nothing, the rest of the accessibility runtime keeps its normal maximum 40-ms wait cadence.
- Stable Character Customization remains unchanged: full `CharacterCustomizeSlotSelect::Install()` still has 0 startup calls and `CharacterCustomizeCharacterCursorSafe::Install()` exactly 1.
- Production audit versus V3.20.6: `Patch::Install` 42 -> 42, Rel8 1 -> 1, `InitThread` 35 -> 35; 0 named RVA/OFF addresses added, removed or changed.
- Portable regression: 51 PASS, 0 FAIL; 5 Windows-only tests remain for MSVC.
- Public version: V3.20.7.

## 3.20.6 — SAFE: faster Ultimate Tekken Bowl scrolling and real Online player names — 2026-09-09

- Stable V3.20.5 is the code base. `tekken.zip` is the only game-data source (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`; EXE SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Ultimate Tekken Bowl no longer makes several synchronous NVDA calls from one rapid redraw burst. Existing native help/player fields publish only the newest value into a small `latest wins` buffer, and the existing 40-ms accessibility worker performs the actual speech call. Fast scrolling therefore discards stale pending positions.
- No Bowl hook is added. Only speech delivery from already-handled native callers changes, and the queue is reset on a real Bowl owner/screen change.
- Online account names are now separated from localization. `$PlayerName...` / `$HostPlayerName...` carry final account names and are no longer sent through the game localization resolver. Unresolved UI ids such as `online_other_083` are not spoken as player names.
- `tekken.zip` confirms three direct real-name sources: Ranked Match MatchList — native `std::string` at `record+0x08`, setter return `0x0052812F`; Player Match search rooms — host at `record+0x78`, setter return `0x0050D15C`; Player Match Session Room — member at `record+0x10`, setter return `0x0050F3B4`.
- Those fields are read inside already-existing row/cursor hooks. No hook, RVA, or existing game-address value is added or changed.
- Stable Character Customization behavior from V3.20.5 is preserved: `CharacterCustomizeSlotSelect::Install()` still has 0 startup calls and `CharacterCustomizeCharacterCursorSafe::Install()` exactly 1.
- Audit: `Patch::Install` 42 -> 42, Rel8 1 -> 1, named RVA/OFF 574 -> 574; 0 added, 0 removed, 0 changed values.
- Portable regression: 49 PASS, 0 FAIL; 5 Windows-only tests remain for the MSVC pass.
- Public version: V3.20.6.

## 3.20.5 — SAFE: Character Customization outfit-slot speech through the working V3.20.4 hook — 2026-09-09

- Stable live V3.20.4 is the code base. `tekken.zip` is the only game-data source for this change (SHA-256 `7cef03571e7e112c5d32ea7f1c057f719ba58476b006efbb98166676fab3f44e`).
- No new hook is added. The already-working `CharacterCustomizeCharacterCursorSafe` at `RVA 0x0046DF20` receives exactly one additional, tightly filtered native event: `18`.
- `tekken.zip` confirms event `18` lands at `RVA 0x0046E788`, moves `CharaSlot_Select_mc.Cursor_mc`, and after the original dispatcher stores slot column/row at `self+0xB8` / `self+0xBC`.
- The same EXE confirms the native `5 x 2` layout: slot position is calculated as `column + 1 + 5*row`. The constructor creates `Slot_01..Slot_10`, `$slot_01..$slot_10`, and maps them to `chasel_msg_002..chasel_msg_011`.
- The new path announces only the game's native localized slot label. It runs no `PaletteReader`, Copy/Delete, `NavigationContext`, or full `CharacterCustomizeSlotSelect` logic.
- `CharacterCustomizeSlotSelect::Install()` still has 0 startup calls; the safe hook is installed exactly once.
- `Patch::Install` remains 42 and Rel8 remains 1; named RVA/OFF values: 0 added, 0 removed, 0 changed.
- Portable regression: 47 PASS, 0 FAIL; 5 Windows-only tests remain for the MSVC pass.
- Public version: V3.20.5.

## 3.20.4 — HOTFIX: restore Character Customization fighter speech without the full slot module — 2026-09-09

- The live-working reference is V2.88: selected fighter names were announced from native Character Customization dispatcher `0x0046DF20`.
- V3.20.4 does NOT re-enable `CharacterCustomizeSlotSelect::Install()`. The later combined palette, outfit-slot, copy/delete and `NavigationContext` work remains detached after input/speech-lock regressions.
- A separate `CharacterCustomizeCharacterCursorSafe` uses the same verified RVA, calls the original dispatcher first, and then handles only events `1`, `2`, and verified cursor movement event `6`. Event `5` and all palette/slot logic are excluded.
- `tekken(4).zip` confirms event `6` lands at RVA `0x0046E2DA`, moves `Character_Select_mc.Cursor_mc`, and stores column/row at `self+0xB0` / `self+0xB4`.
- Fixed an important cache bug: same-movie batch repopulation beginning at `$chara_name_00` may refresh the name table but no longer clears `gLastCharacter`. Identical fighter speech therefore cannot be re-armed on every redraw.
- Other Customization modules remain enabled as in V3.20.3. The full slot module remains in source for later slow, one-piece-at-a-time restoration.
- Added `test_v3204_customization_character_restore.cpp`.
- Public version: V3.20.4.

## 3.20.3 — HOTFIX: full rollback of the blocking Character Customization observer — 2026-09-09

- Live V3.20.2 testing again showed a complete input lock after entering Character Customization. The minimal observer on dispatcher `0x0046DF20` is not safe even when it does not call NVDA/Tolk directly.
- V3.20.3 completely removes the production `CharacterCustomizeCharacterCursor` added in V3.20.2 and restores the `TekkenAccessibility.cpp`, `FocusedUi.h`, and `DescriptionRuntime.h` paths to the exact working V3.20.1 behavior.
- `CharacterCustomizeSlotSelect::Install()` remains disabled. No character or slot dispatcher observer is installed in Character Customization.
- The other Customization modules remain active: item count, selected item, categories, and rarity/UI states.
- The hotfix adds no hook, RVA, or OFF. Production `Patch::Install` count returns to the V3.20.1 state.
- Fighter-name speech is intentionally left disabled until a signal is found that does not pass through the input-locking dispatcher. Stable controls take priority.
- Added `test_v3203_customization_observer_rollback.cpp` to guard both forbidden installers and the remaining Customization accessibility.
- Public version: V3.20.3.

## 3.20.2 — HOTFIX: Character Customization fighter speech without restoring the input lock — 2026-09-09

- Live V3.20.1 testing confirmed that disabling `CharacterCustomizeSlotSelect::Install()` fixes controls, but also removes the only active signal that drove selected-fighter speech.
- `CharacterCustomizeSlotSelect::Install()` remains disabled. V3.20.2 adds a separate minimal `CharacterCustomizeCharacterCursor` that reuses the previously verified dispatcher at `RVA 0x0046DF20`.
- `tekken(4).zip` confirms the native events: `5` puts `Character_Select_mc.Cursor_mc` into `Normal_Select`, while `6` moves that cursor and stores column/row at `self+0xB0/self+0xB4`. The observer accepts only events `1/2/5/6`.
- The observer detour never calls NVDA/Tolk and runs none of the palette, slot, copy or delete logic. It only queues the selected name; the existing accessibility runtime drains that queue outside the game's dispatcher thread.
- Fighter names still come only from the native `$chara_name_%02d` batch at caller `0x00472E1F`; no guessed names and no new game-address value are introduced.
- Added `test_v3202_customization_character_cursor.cpp`; the V3.20.1 regression still verifies that the slot installer remains off.
- Public version: V3.20.2.

## 3.20.1 — HOTFIX: disable the blocking Character Customization slot hook — 2026-09-09

- Live testing of V3.20 found that entering Character Customization can completely lock controls.
- Disabled only the startup call to `CharacterCustomizeSlotSelect::Install()`. The module code remains in source, but its event-dispatch hook is no longer installed at mod startup.
- All other Customization accessibility remains enabled: item count, selected item, categories, and rarity/UI-state installers still run.
- No new hook, RVA or OFF was added and no game-address value was changed. The hotfix uses no new game-data source.
- Added `test_v3201_customization_slot_hotfix.cpp`, which checks the real `InitThread` and ensures only this one installer is disabled.
- Public version: V3.20.1.

## 3.20 — VERY HUGE: whole-mod speech-loop safety and verified Create Session navigation — 2026-09-08

- Added a central repeat-flood safety layer behind every NVDA/Tolk output entry. Two rapid identical rendered announcements are allowed; the third and later identical attempts are suppressed while the same activity stream continues. Different text or more than 1.5 seconds of quiet re-arms the same text.
- This guard is deliberately a last-resort backend safety net. Existing screen-specific semantic caches remain authoritative, including the V3.10.1 Character Customization fix.
- Completed Player Match Create Session positional context from already-verified native state: its 11 selectable entries are `Panel0..Panel9` plus the native action button, and the existing native cursor hook reads the selected index. Normal rows, the action button and the native panel-0 initial summary now announce `X of 11`.
- Added `SpeechRepeatGuard.h`, `test_v320_speech_repeat_guard.cpp` and `test_v320_navigation_completion.cpp`.
- No new hook was added and no game RVA/OFF value was added or changed. Unproven combat ownership/state, wall distance, true palette RGB/HSV/color names, anonymous command glyph meanings and ambiguous Online per-player states remain unguessed.
- Public version advanced from V3.10.1 to V3.20 as the next large milestone.
- Final portable regression: 42 PASS, 5 Windows-only tests skipped in this environment, 0 FAIL.

## 3.10.1 — HOTFIX: Character Customization NVDA speech loop — 2026-09-08

- This is an intentional emergency hotfix for V3.10 because live testing found a blocking regression: Character Customization could flood NVDA with repeated speech fast enough to make the screen unusable. The next normal milestone remains the large V3.20 VERY HUGE build.
- Removed the unsafe use of hot Customization renderer `self` addresses as speech-cache lifetime owners. Renderer recycling/alternation can no longer advance `generation` and re-arm identical speech on every redraw.
- `CharacterCustomizeItemCount` now advances generation only when the native item index/count really changes. `CharacterCustomizeSelectedItem` advances only when the selected icon or native item state changes.
- Category and outfit-slot navigation no longer clears duplicate suppression merely because a callback `self` pointer changed. Native indices, game text and `X of Y` context remain intact.
- Replayed Start/re-entry events `1/2` on the same Scaleform movie no longer clear `gLastCharacter`/item caches before every redraw. A real `movie` change still re-arms a fresh screen.
- The exact fighter-name resolver hook remains installed and byte-verified, but no longer speaks while Tekken batch-populates `$chara_name_%02d`. The actually selected fighter is still spoken by the existing name cache plus native cursor event.
- Added `test_v3101_customization_loop.cpp` and extended `test_focused_ui.cpp` with a repeated-Start/same-movie regression case. The historical V2.90 test was corrected so it no longer requires the unsafe hot-renderer owner assumption.
- The hotfix adds no new hook, RVA or OFF and changes no game-address value.

## 3.10 — VERY HUGE whole-game navigation expansion and legacy re-entry — 2026-09-08

- This milestone is intentionally a large build. V3.10 expands broad screen navigation and re-entry reliability for legacy UI families together; no small intermediate release was cut.
- Extended `X of Y` / `X z Y` position context, only from native game indices/counts, to additional verified surfaces: Play Side Select, Practice main/submenus, Standard Dialog, Rematch, Button Mapping, Controller Setup, Character Customization categories/outfit slots/native two-choice popup, Story photo/episode grid, Tournament Session List, Player Match Session List, and Ranked Match List/selected-player fields.
- Standard Dialog derives its button count from the real native `self+0/self+8` vector with `0x20` stride; Practice uses the `rowCount/itemCount` values supplied directly by the game's callback. Fixed totals are used only where they match an exact verified native/SWF table or panel set.
- Added route-scoped owner-aware re-entry for legacy renderer families: Story/PictureStory/chapter/prologue, Playing Stats, Profile, JukeBox, Ultimate Tekken Bowl, and News. Each family cache is cleared only after its exact caller RVA matches and the real Scaleform `movie` changes.
- Extended the same model to the shared setter: native Profile and Ultimate Tekken Bowl fields now have separate owner-aware caches, allowing the same real game text to speak again on a fresh screen without globally resetting unrelated UI.
- Button Mapping, Controller Setup, and Tournament Session List also gained native-owner/cursor re-entry protection.
- Corrected a source/RE identity error: four addresses `0x00515810/37/5E/85` were historically named `PLAYINGSTATS_*`, but the exact `SW_UI_PlaySideSelect` constructor proves `$Left/$Left_Effect/$Right/$Right_Effect` with `chasel_msg_012/013`. The constants are renamed to `RVA_PLAYSIDE_*`; address values are unchanged and the duplicate static labels remain intentionally silent because selected side is already read from native state.
- No new hook or new game address is introduced. V3.10 still does not guess unproven hit/guard/wall-hit ownership, stance/airborne state, wall distance, palette RGB/HSV, or anonymous Command List `$03..$34`.
- Final portable regression after functional changes: 39 PASS, 5 Windows-dependent tests skipped in this environment, 0 FAIL.

## 3.00 — VERY HUGE navigation context and route-scoped re-entry milestone — 2026-09-08

- Promoted the next accessibility milestone to V3.00 because it changes two broad foundations at once: blind navigation context and speech-cache lifetime across large native UI batches.
- Restored `X of Y` navigation context where both values come from Tekken's own selected index/count state: Main Menu, Offline/Options submenus, Online root/submenus, Graphics, Sound, Game Options, My Replays/Battle Log and Practice Command List.
- Main/Offline/Online/Options counts use the exact native menu tables or current native count fields already verified in the supported EXE. Graphics/Sound/Game Options use their verified row counts; Replay and Command List use the live native list/vector sizes. No item name or semantic is generated from position.
- Added route-scoped owner-aware cache lifetime to nine large exact-native batches: V248 current-package fields, customization/input, controller/viewer help, online/tournament reliability, residual native fields, large option/category blocks, Profile rank list, Playing Stats stage pairs and Playing Stats PanelValue10..16.
- Owner binding happens only after the exact caller/path route for that batch is recognized. Unrelated traffic through the shared renderer/setter does not reset these caches.
- Reopening a fresh native Scaleform movie can therefore speak the same real game text again instead of inheriting duplicate suppression from the previous screen instance.
- Added `NavigationContext.h`, `BatchOwnerReentry.h`, `test_v300_navigation_context.cpp` and `test_v300_batch_reentry.cpp`.
- Full portable regression: 37 PASS, 5 Windows-only tests skipped here, 0 FAIL.
- No new hook site and no new or changed game RVA/OFF value. Existing hook-install counts remain unchanged from V2.90.
- Public version advances from V2.90 to V3.00; updater numeric comparison explicitly verifies that V3.00 is newer than V2.90.

## 2.90 — very huge multi-area accessibility and re-entry build — 2026-09-08

- Consolidated the next work into a milestone-sized build instead of a one-feature release.
- Battle HUD timer: native `_root.SetBattleTime` final countdown now announces 30, 10, 5, 3, 2, 1 and 0 seconds; duplicate writes stay silent and timer increases/no-limit resets discard stale countdown speech.
- Re-verified the exact supported EXE timer caller `0x004C2C6E`: native code clamps seconds to `0..99`, uses `-1` for no-limit, constructs an integer GFx argument and sends it to `_root.SetBattleTime` through the existing queued invoke path.
- Expanded `Ctrl+Shift+F12`: the verified logical P1/P2 health/down/Rage snapshot now appends current battle time and the authoritative P1/P2 round score.
- Added owner-aware re-entry reset to My Replays/Battle Log, Rematch, Rank Promotion, final Revenge result message, Fight Money detail rows and Result Total.
- Extended owner-aware generation/reset logic through Character Customization category, outfit slot/copy UI, item count and selected-item/status layers. Reopening a fresh native screen/list on the same item re-arms speech without inventing item or color semantics.
- Result Fight Money/Total caches bind to the native movie only after an exact caller/path match, preventing unrelated shared renderer traffic from resetting those speech domains.
- No new hook, RVA or fighter-field offset is added by V2.90; all work reuses existing hook sites and already verified native owner/HUD data.
- Added `BattleTimerReader.h`, `test_v290_battle_timer.cpp` and `test_v290_mass_reentry.cpp`, and expanded HUD/runtime regression coverage.
- Final portable regression after all V2.90 changes: 35 PASS, 5 Windows-only tests skipped here, 0 FAIL. The expanded HUD path also passes a Windows-API stub compile/run test.
- Public version advances directly from V2.88 to V2.90 because this is a large milestone build; updater numeric comparison explicitly tests the skipped V2.89.

## 2.88 — logical down-state identity and current display side — 2026-09-08

- Automatic `down / down state ended` announcements keep the verified logical P1/P2 owner and add the current left/right display side when `PlayerOnRightSide` is available. A cross-up during the existing 80 ms stability window changes only the descriptive side, never the logical owner.
- `Ctrl+Shift+F12` now adds the current side to each valid P1/P2 health + down + Rage snapshot. If orientation is temporarily unavailable, the previous safe P1/P2 wording remains without guessing a side.
- Side reads use only the already-verified `fighter+0x14D4`; no new hook, RVA or fighter offset was added. Fighter pointers and battle context are re-verified after the read as before.
- Re-audited the Customization palette: native event 45 carries gradient cursor coordinates, while events 46/48/53 carry swatch/saved-color/color-area selection. No verified RGB/HSV value is exposed by those events, so V2.88 still does not invent color names.
- Added `test_v288_down_identity.cpp`; full portable regression: 33 PASS, 5 Windows-only tests skipped, 0 FAIL.
- Public version advanced to `V2.88`.

## 2.87 — logical P1/P2 health identity across cross-ups — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Confirmed existing health renderer `0x004C6930`: native arguments are current health, maximum health and display-side index, and the renderer sends those three values to `_root.SetHealth`.
- Confirmed native caller `0x004C36A4..0x004C36E6`: it iterates the logical fighter index, resolves that fighter, obtains current health through the fighter health object and maximum health from the same fighter, derives display side separately, then calls `0x004C6930`. This proves display side is presentation state, not permanent player identity.
- Refactored `HealthReader` so verified samples are stored by logical P1/P2 whenever the already-confirmed `PlayerOnRightSide` orientation is available. Speech resolves the player's current left/right side separately.
- Fixed the cross-up stale-snapshot bug: health captured before a side swap is no longer reinterpreted as belonging to the player who later occupies that display side. Native redraws on the new sides remain silent unless the logical player's health actually crosses an announcement band.
- If orientation is unavailable, the sample stays in an isolated side-only fallback cache and is never guessed into a logical player later. Queued side-only warnings are discarded when trustworthy orientation returns to prevent stale ownership.
- No new hook, RVA or fighter field offset was added; the existing `SetHealth` hook remains unchanged.
- Added `test_v287_health_logical_identity.cpp`. Portable regression after the logic change: 32 PASS, 5 Windows-dependent tests skipped here, 0 logic FAIL. The changed `_WIN32` HealthReader path also passes a Windows-API stub compile test.
- Public version advanced to `V2.87`.

## 2.86 — logical P1/P2 Rage identity across side swaps — 2026-09-08

- Re-audited the native Battle HUD Rage path in the supported `TekkenGame-Win64-Shipping.exe`. The HUD loops over two fighters, derives the current display side and passes that display-side index to `_root.RageOn` / `_root.RageOff`.
- Added a logical P1/P2 Rage tracker using the already-verified `PlayerOnRightSide` data. Real Rage start/end announcements now identify the player and refresh the player's current left/right side before speech.
- Cross-up HUD redraws such as old-side `RageOff` plus new-side `RageOn` no longer become false logical Rage transitions when the same player's Rage state did not change.
- If fighter orientation is temporarily unavailable during HUD construction, the existing safe side-only fallback remains.
- No new hook, RVA or fighter offset was added.

## 2.85 — verified native P1/P2 round score in Battle HUD — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Confirmed native caller `0x00307190`: it loads the table at `RVA 0x034CD500`, iterates exactly two player records with a `0xF0` stride, and uses dword `+0x00` as the number of visible round-win markers.
- The caller loops `markIndex = 0 .. wins-1` for each player and calls renderer `0x004C5850`; therefore a single redraw of score 3 can emit marker callbacks 0, 1 and 2.
- Confirmed `0x004C5850` receives the logical player index and only then maps it to the current display side before invoking `_root.TurnWinMarkOn`. The `0x034CD500` table is therefore the authoritative P1/P2 source rather than the physical HUD side.
- V2.85 treats the existing `TurnWinMarkOn` only as a refresh signal. Before speech it reads the authoritative P1/P2 counters and announces one final score such as `Round score. 1P: 3. 2P: 1.` instead of `1, 2, 3`.
- Repeated redraws with an unchanged score are silent. A lower rematch score followed by a new win is detected from current counters without assuming marker indexes only increase.
- `Ctrl+Shift+F7` now includes the verified round score when a valid battle identity and table read are available.
- If direct table reading is temporarily unavailable, a safe highest-marker-per-display-side fallback remains and is deduplicated.
- No new hook was added. Only one new byte-verified table RVA was introduced; existing hook sites and all previous RVA/OFF values remain unchanged.

## 2.84 — P1/P2 health identity across side switches — 2026-09-08

- Health speech from the existing `_root.SetHealth` hook is no longer limited to `Left/Right`; when verified fighter orientation is available, NVDA also identifies `1P` or `2P`.
- Mapping uses only the already-confirmed `PlayerOnRightSide` / fighter `+0x14D4` data. No hook, RVA or field offset was added.
- Identity is resolved at `Flush`, immediately before speech, so a cross-up during the 200 ms health burst delay cannot leave a stale pre-cross-up side assignment.
- Combat audit confirmed that `OnGuard`, `OnReceivedHit`, `OnPlayerDown` and `OnJumpLanding` are members of `BattleEventItemInterface`. The interface alone does not prove which fighter receives an event, so no unsafe event -> P1/P2 mapping is added.
- `GetFloorNo` / `GetStagePositionType` belong to `TekkenPlayerStart`, so they are not used as dynamic combat state. `GetWallAttribute` belongs to `TekkenWallActor`, but its numeric values have no verified name mapping in this EXE, so their semantics remain intentionally unguessed.

## 2.83 — native labels restored in Practice Attack Data summaries — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Confirmed the five native `SW_UI_AttackData` value families: `$TotalDamage_%s`, `$MaxComboDamage_%s`, `$Damage_%s`, `$HitCombo_%s` and `$ComboDamage_%s`.
- Confirmed setup RVA `0x0044D500` loads localization keys `prc_573`, `prc_574`, `prc_575`, `prc_576` and `prc_577` in that same native order.
- Fixed an accessibility loss in the existing V194 Attack Data summary: the mod already had the five verified values but discarded their labels and announced only a bare value sequence.
- Added `AttackDataSummarySpeech.h`: NVDA now announces native panel side L/R plus each available **game-localized label + value** pair. Localization is resolved from the real `prc_573..577` keys first; field-name fallbacks are used only if resolution is unavailable.
- No new hook, RVA/OFF definition or game-memory offset was added. Existing hook-install counts and all existing address values remain unchanged from V2.82.
- Added `test_v283_attackdata_summary.cpp`. Portable regression: 28 PASS, 5 Windows-dependent tests skipped here, 0 FAIL.
- The packaging hardening from V2.82 BUILD FIX 2 is preserved: CRLF/no-BOM batch files and no label-subroutine dependency in the release builder.
- Public version advanced to `V2.83`.

## 2.82 — Practice Frame Data labels restored in speech — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Confirmed the native Frame Data setup creates `$p1_item_1..4` / `$p2_item_1..4` and feeds them from game localization keys `S3_002_frm_000`, `S3_002_frm_001`, `S3_002_frm_004` and `S3_002_frm_005`.
- Confirmed the matching value paths are `$p1_number_1..4` / `$p2_number_1..4`. V2.81 already cached both the labels and values, but its final summary discarded the labels and announced only an ambiguous sequence of numbers.
- Added `FrameDataSpeech.h`: NVDA now announces the native panel identity (`player 1` / `player 2`) and each available **native game label + value** pair. Missing labels safely fall back to the value only; no frame-data semantic name is invented by the mod.
- No new hook, RVA, OFF value or game-memory field offset was added. All existing named RVA/OFF values are unchanged from V2.81; `Patch::Install` remains 41 and `Patch::InstallRel8Jcc` remains 1.
- Added `test_v282_frame_data_speech.cpp`. Portable regression: 27 PASS, 5 Windows-dependent tests skipped here, 0 FAIL.
- The V2.80 packaging fix is preserved: historical audit files remain optional and cannot block creation of the release ZIP.
- Public version advanced to `V2.82`.

## 2.81 — verified Practice Attack Data events — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Confirmed the native `SW_UI_AttackData` path table contains four live indicator families after the five numeric metrics: `CleanHit`, `CounterHit`, `WallHit` and `Punish`, for both native L/R panels. The matching game localization keys are `prc_578` through `prc_581`.
- Confirmed exact trigger helpers: Clean Hit RVA `0x0044E280` uses path offset `+0x600`; Counter Hit `0x0044E8C0` uses `+0x700`; Wall Hit `0x0044EDE0` uses `+0x800`; Punish `0x0044ED40` uses `+0x900`. Each uses side stride `0x1370`.
- All four helpers load the literal animation state `Start` and tail-jump to setter RVA `0x00453950`, which Tekken Accessibility already hooks. V2.81 therefore adds event speech by extending the existing hook only; no new hook is installed.
- NVDA now announces the native visual side plus the game-localized event label when the exact `Start` path is observed. `On`, `Off`, `End`, mixed-side and unrelated Attack Data paths are rejected to prevent false speech during screen construction/reset.
- No new RVA/OFF definition or game-memory field offset was added. All 577 named `RVA_*`/`OFF_*` definitions and their values remain unchanged from V2.80; existing hook-install counts remain unchanged.
- Reflection events such as `OnReceivedHit` / `OnGuard` remain deliberately unassigned until receiver-to-fighter identity is proven.
- Added `AttackDataEvents.h` and `test_v281_attackdata_events.cpp`. Portable regression: 26 PASS, 5 Windows-dependent tests skipped here, 0 FAIL; the modified FocusedUi integration also passes a Windows-API stub syntax/runtime test.
- Public version advanced to `V2.81`.

## 2.80 — corrected native Command List tokens — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Parsed the native 64-entry command-token formatter table at VA `0x14282F6F0`. It explicitly confirms `rs>` → `$RS`, `screw>` → `$ART_SCREW`, `lsb>` → `$L`, and `rsb>` → `$R`.
- Fixed a real V2.77–V2.79 speech error: `<#rs>` is not Tailspin; it is the right stick. NVDA now says `Right stick`, while Tailspin remains tied only to `<#screw>`.
- The native selected-command renderer confirms the existing meaning of `record+0x1C`: helper `0x1404C9870` returns exactly `<#screw>`. Neighboring flags still use `<#power>`, `<#homing>` and `<#wallbound>`.
- Added verified `$L` / `$R` image classes for left/right stick press and additional unambiguous tokens from the same native table, including Rage Art, Rage Drive, Infinity, Wall/Wall Break/Balcony Break/Floor Break, Assist, Difficulty, View and Save.
- Anonymous `GAIJI/$03..$34` classes are still **not assigned guessed meanings**. If encountered, they remain audible as their symbol identifier.
- No hook, RVA or game-memory offset was added. All 577 existing named `RVA_*`/`OFF_*` constants keep the same values as V2.79; `Patch::Install` remains 41 and `Patch::InstallRel8Jcc` remains 1.
- Added `test_v280_command_tokens.cpp` and expanded the Command List decoder test. Portable regression: 25 PASS, 5 Windows-dependent tests skipped here, 0 FAIL.
- Public version advanced to `V2.80`.

## 2.79 — verified dynamic Practice value text — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`) to resolve the last raw-number fallback on the main Practice settings page.
- Confirmed `prc_713` / native row type `0x09` is not a static enum. The game reads `settings+0x1C`, searches a runtime vector at `0x1434D6BD8..0x1434D6BE0`, and uses 0x20-byte entries.
- Confirmed exact entry semantics from native code: `+0x00` is the ID compared with `settings+0x1C`, while `+0x08` is the game-provided text pointer passed to shared renderer `0x1404570E0`.
- Main Practice speech now maps the current native ID to that exact game text. The corresponding value submenu maps its native selected ordinal through the same vector, so it no longer goes silent for type `0x09`.
- Added guarded `ReadProcessMemory` reads for the two vector globals, entries and string data. Corrupt/absent/incomplete data is rejected, and the main row retains the old numeric fallback while the dynamic list is temporarily unavailable.
- Added exactly two verified data RVAs (`0x034D6BD8`, `0x034D6BE0`) and **no new hook**. Existing Practice cursor hooks remain unchanged.
- Added `test_v279_practice_dynamic.cpp` and dedicated native/release audit files.
- Portable regression: 24 tests PASS, 5 Windows-dependent tests remain for MSVC/live validation, 0 portable failures.
- V2.78 Command List image/token handling and all earlier Online/Combat/re-entry/Polish behavior remain unchanged.
- Public version advanced to `V2.79`.

## 2.78 — native Command List image markup preserved — 2026-09-08

- Re-audited the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`) and followed the native `commandimage_struct` loader instead of assigning meanings from visual guesswork.
- Confirmed the command-image data class at vtable `0x1427BADD0`: parser `0x140322260` relocates records from `Binary/list/commandimage_struct.bin`, while path getter `0x14033A6A0` returns that exact game-data path.
- Confirmed native markup parser `0x140321F80` handles `<img src='...'>` command-image tags and searches `commandimage_struct`; V2.77 previously treated generic `<img>` as disposable HTML and could therefore lose a command symbol from speech.
- V2.78 now preserves Command List image tags in NVDA speech. Named controller classes verified in the game's `gfxgaijilib` export are spoken as their actual control names (Xbox/PlayStation buttons, sticks, D-pad/directions), and explicitly named Tekken art classes such as Homing/Screw/Power Crush/Rage Art/Rage Drive are also verbalized.
- Anonymous numeric image classes such as `$03..$34` are **not guessed**. If encountered they remain audible as `symbol $NN` until `commandimage_struct.bin` or the matching asset proves their exact meaning.
- Mirrored the native parser's explicit bypass list for `$01`, `$02`, `$35`, `$TRIANGLE_RIGHT` and `$TRIANGLE_LEFT`, avoiding decorative/navigation image noise.
- Added regression coverage for Xbox image tags, PlayStation image tags, Tekken property art, unknown numeric image fallback and the native bypass list.
- No new hook, RVA or game-memory offset was added. All existing `RVA_*` / `OFF_*` declarations and the hook-install call sites in `TekkenAccessibility.cpp` are unchanged from V2.77.
- Portable regression: 23 tests PASS, 5 Windows-dependent tests remain for MSVC/live validation, 0 portable failures.
- Public version advanced to `V2.78`.

## 2.77 — verified Practice Command List glyph speech — 2026-09-08

- Re-audited Practice Command List against the exact supported `TekkenGame-Win64-Shipping.exe` (SHA-256 `7f2b68727023ce9f4554b47f5442dad9dfb38c8a9b778f2aa758469e2c2d60ed`).
- Added a speech-only decoder for native `<#...>` markup already present in the game-provided `$command` text. Confirmed controller/help tags such as A/B/X/Y, bumpers, triggers, stick presses, Menu, confirm/cancel and direction helpers are now spoken as readable labels instead of raw markup.
- The selected command still comes from the already-confirmed Command List record `+0x08`; no external move database or guessed command mapping was introduced.
- Unknown `<#...>` tags remain audible as `symbol <token>`. Opaque command-image resources (`GAIJI` / `$03..$34`) deliberately remain semantically unnamed until their meanings can be proven from game data.
- Rechecked presentation-only record bytes: native renderer `0x14048E720` uses `+0x16` and `+0x1A` for row presentation/state, while `+0x19` controls the equipment icon. V2.77 does not announce these as move properties.
- Existing confirmed semantic flags remain unchanged: difficulty/repeat `+0x17/+0x18`, Power Crush `+0x1B`, Tailspin/Screw `+0x1C`, Homing `+0x1E`, Wall Bound `+0x1F`. The difficulty label is now bilingual.
- Added `PracticeCommandText.h` and `test_practice_command_text.cpp`, including English/Polish rendering, safe unknown-token fallback and markup cleanup.
- No hook, RVA or game-memory offset was added or changed. All 576 named `RVA_*`/`OFF_*` constants match V2.76; `Patch::Install` / Rel8 occurrence counts are unchanged.
- 23 portable tests pass, 5 Windows-dependent tests remain for MSVC, with 0 portable failures.
- Public version advanced to `V2.77`.

## 2.76 — more reliable Practice and selection-screen re-entry — 2026-09-08

- Extended native-screen-owner (`self`) cache protection to additional existing readers: Character Select, outfit/slot selection, Stage Select, the main Practice menu, Practice value submenus and Pause Menu.
- A newly created screen may now start on exactly the same character, stage, Practice row/value or pause action as the previous screen and still announce its first item instead of inheriting the previous duplicate-speech cache.
- Practice continues to use only the previously recovered native pages, rows, setting fields and value tables. V2.76 adds no guessed field names or meanings.
- Stage Select resets a replacement owner's speech state before calling the original function so its already-confirmed current-stage lock callback is preserved.
- Added a small `OwnerToken` helper to `ScreenOwnerCache.h` and `test_v276_reentry.cpp`, covering owner replacement and wiring across the six screen groups.
- This pass uses only existing hooks and the native `self` pointers already supplied to them. No hook, RVA or game-memory offset was added.
- All V2.75, V2.74.2, Online, Combat and Polish-language behavior remains unchanged.
- 22 portable tests pass, 5 Windows-dependent tests remain for MSVC, and the portable suite has 0 failures.
- Public version advanced to `V2.76`.

## 2.75 — reliable speech after menu re-entry — 2026-09-08

- Fixed a case where a newly created menu screen could remain silent when it opened on the same selected index that had been spoken on the previous screen instance.
- Main Menu, the shared Offline/Options submenu, Online root and Online secondary submenu now bind their last-selection duplicate cache to the native `self` pointer. A different screen object gets a fresh cache, so its initial selected row can be announced again.
- Shared submenus also remain separated by their confirmed native `mode`, so changing between supported menu branches re-arms speech even when the numeric row index is unchanged.
- Added `ScreenOwnerCache.h` and `test_screen_owner_cache.cpp`, covering duplicates within one instance, re-entry with a new owner, mode changes and explicit resets. The test also checks that the helper is wired into all four existing readers.
- The change reuses only the four existing cursor hooks and already-confirmed menu fields. No hook, RVA or game-memory offset was added.
- V2.74.2 fight-identity protection and all earlier Online/Combat/Polish fixes remain unchanged.
- 21 portable tests pass with 0 failures; five Windows-dependent tests and the final DLL build remain for `RUN_FULL_TESTS_V2.75.bat` / `BUILD_RELEASE_V2.75.bat`.
- Public version advanced to `V2.75`.

## 2.74.2 — cross-fight combat-state hotfix — 2026-09-08

- Fixed automatic combat trackers potentially carrying their baseline into the next fight when a new fight became valid before the existing 500 ms invalid-data reset elapsed.
- The side-change tracker now binds its stable state to the already-verified tuple: battle context + 1P fighter pointer + 2P fighter pointer. A changed tuple establishes a fresh silent baseline instead of producing a false `Side change`.
- The native `IsDown2` tracker uses the same guard, so a new fight cannot inherit `down / down state ended` from the previous fighter set.
- Real transitions within the same fight still use the existing 80 ms stability filter; sustained invalid data still clears the baseline after 500 ms.
- This uses only the previously confirmed battle context and fighter table. No hook, game RVA, fighter-field offset, posture semantic or wall semantic was added.
- Extended orientation/down regression tests with fighter-identity changes; all 20 Linux-portable tests pass. Five Windows/MSVC-dependent tests and the DLL build must still be run on Windows through `RUN_FULL_TESTS_V2.74.2.bat` / `BUILD_RELEASE_V2.74.2.bat`.
- Bumped the public version to `V2.74.2`.

## 2.74.1 — Polish language quality pass — 2026-09-08

- Fixed the release builder: the DLL is now built before optional full tests, so a test failure no longer prevents DLL/ZIP creation. Added separate `RUN_FULL_TESTS_V2.74.1.bat` and clearer build logs.

- Performed a dedicated review of Polish speech generated by the mod. Player names, character names and game-provided text are left untouched unless the mod has a verified basis for translating them.
- Reworked awkward Polish wording, including `Host` -> `Gospodarz`, `Arcade, postać` -> `Tryb Arcade`, stick-press labels, the room-lobby label and outfit-copy messages.
- Improved Polish Profile labels for Gallery/Story/Character Episode completion, Tekken Power, total battles and total earned Fight Money.
- Improved combat wording for Rage state, automatic side-change announcements, unavailable-state messages and the end of the confirmed down state. F10 now says the Polish equivalent of `Distance between players`.
- Improved health/HUD wording and added correct Polish second inflection: `1 sekunda`, `2 sekundy`, `5 sekund`, `1 sekundę temu`, etc.
- Improved Polish controller labels for D-pad directions and left/right stick press.
- Improved the unknown-QTE-icon message and several other mod-generated UI labels.
- Removed a remaining hard-coded English runtime message: the long-description notice now has a full Polish variant.
- README PL/EN now documents `Ctrl+L`, which toggles Polish/English mod-generated speech and persists the choice in `%LOCALAPPDATA%\TekkenAccessibility\settings.ini`.
- Added `test_polish_language.cpp` covering key Polish labels, Online, Combat and time inflection. This language pass adds no hooks and changes no verified game offsets.
- Bumped the release version to `V2.74.1` and added `BUILD_RELEASE_V2.74.1.bat`.

## 2.74 — verified combat state reader — 2026-09-08

- Added `Ctrl+Shift+F12` for an on-demand combat-state snapshot of both native fighter records. It reports the game's confirmed health percentage, native down predicate and Rage state for 1P/2P.
- Added automatic native `IsDown2` transition announcements: after 80 ms of stable state the mod says `1P/2P: down` or `down state ended`. Short transients are rejected, and 500 ms of invalid/missing fighter records resets the baseline so state is not carried across rounds/screens. The monitor is ReadProcessMemory-only and adds no hook.
- Reverse engineered native `IsDown2`: wrapper `0x006774E0` calls native `0x00254320`, which reads `dword [fighter+0x428]` and returns true exactly for states `13, 15, 17, 19`. V2.74 therefore says only `down / not down`; it deliberately does not invent standing, crouching or airborne semantics for the remaining values.
- Reverse engineered native `IsRage`: wrapper `0x00677D50` calls native `0x00254820`, which returns `byte [fighter+0x781] != 0`.
- Reverse engineered native `GetNormalizedHP`: wrapper `0x00674D10` calls native `0x00253C40`, converts `dword [fighter+0x1508]` to float and multiplies by `0.01`. Independent game code compares the same field with `100`, confirming the 0–100 percentage scale used by the reader.
- The new combat-state reader uses the already-confirmed battle context/fighter table and `ReadProcessMemory`; no engine function is called from the accessibility worker and no new hook is added. Fighter pointers are rechecked after the read so a battle transition cannot silently mix two different fighter objects.
- Added a runtime-wiring regression test that verifies F10 position, F11 orientation toggle/monitor and F12 state snapshot are all reachable through `DescriptionRuntime::Run()` from `InitThread`. This also confirms that F10/F11 were already wired in V2.73 through `DescriptionRuntime.h`, even though they are not referenced directly in `TekkenAccessibility.cpp`.
- Investigated wall/floor data further. `GetWallAttribute` is confirmed as `dword [object+0x398]`, `GetFloorNo` as `dword [object+0x390]`, and `GetStagePositionType` as `byte [object+0x3B8]`. These belong to stage/collision objects whose live per-fighter ownership has not yet been proven, so V2.74 intentionally does not announce wall distance or wall side from them.
- Located native/reflected combat event families including `OnReceivedHit`, `OnGuard`, `OnWallHit`, `OnPlayerDown` and `OnJumpLanding`. They remain unhooked in V2.74 because the receiving object-to-fighter mapping is not yet proven; this preserves the project's no-guessing / minimize-hooks rule.
- Audited `IsCrouching` as well: the first native wrapper is registered under `/Script/Engine` and calls a generic engine virtual method (`vtable+0x4B8`); the second occurrence is reflection metadata. Neither proves a Tekken fighter-record crouch field, so V2.74 deliberately does not announce crouching.
- Public version advanced to `V2.74`; `TekkenAccessVersion.txt`, startup tests and `BUILD_RELEASE_V2.74.bat` use the same number.

## 2.73 — Online Completion + Combat Orientation + new public versioning — 2026-09-08

- The first large public release after V2.72 now receives a real version bump instead of another internal “Build” label. The source version is centralized in `ModVersion.h`, while the updater version file contains exactly `V2.73`.
- Completed the large Online pass: separated the real `SW_UI_RankMatch_MatchList` from Player Match Session Room, added the true 6-row Session Room cursor and 7-row tournament-session cursor, plus labeled player/session fields, connection quality and area.
- Preserved the Sound Options fixes: real native screen fields, 0–10 ranges for four sliders and 0–1 for the toggle.
- Preserved Build A hook hardening: StandardDialog short-`JE` relocation and rollback for multi-hook modules.
- Dialog and Options readers reset stale speech caches when their native screen object changes, reducing silent re-entry and duplicate speech.
- Customization uses the confirmed 72-swatch (8×9) grid and 15 saved-color slots without inventing RGB/HSV names.
- Combat Accessibility: `Ctrl+Shift+F10` reads native fighter positions, distance and left/right orientation; `Ctrl+Shift+F11` toggles automatic stable side-change announcements.
- Statically audited the current `TekkenAccessUpdater.exe`: it accepts `v`/`V`, parses dot-separated numeric components, pads missing components with zeroes and compares numerically. Sequences such as `V2.72 -> V2.73 -> V2.73.1 -> V2.74` are compatible with the existing updater.
- Added `BUILD_RELEASE_V2.73.bat`, which runs the full test/build flow and creates a GitHub-ready binary ZIP.

## 2.72 Build E.1 — Online completion / Ranked and Session Room split — 2026-09-08

- Fixed a long-standing V2.72 misclassification: hooks `0x005258D0` and `0x00528000` belong to `SW_UI_RankMatch_MatchList`, not Player Match Session Room. `0x005258D0` iterates exactly 10 panels and writes native `Select`/`Normal` states, so the previously working reader is preserved as a dedicated **Ranked MatchList** module.
- Added the genuine Player Match Session Room using its native cursor routine at `0x0050FD30`. The game iterates exactly 6 panels and writes `Select`/`Normal`; room records are `0x60` bytes, the row count is at `self+0x450`, and the record array is at `self+0x558`.
- Session Room now produces one coherent selected-player description from confirmed data: Player (`$PlayerName0..5`), Character (`rec+0x38`), Rank (`+0x3C`), Wins (`$Wins0..5`, source `+0x40`), Win rate (`$WinRate0..5`, calculated by the game from `+0x40/+0x48`), Title (`$Shogo0..5`, `+0x4C`), Language (`$Language0..5`, `+0x54`), Connection quality (`+0x04`, 1–6) and Area (`+0x58`, 1–8).
- Added stale-row protection: selecting an empty/nonexistent room slot clears that cached row instead of allowing data from a previous occupant to be spoken.
- Added the genuine `Tournament Session List` cursor at `0x004F02B0`. It iterates exactly 7 panels, writes `Select` to only the selected row and `Normal` to the others. List refreshes therefore no longer need to speak all seven tournament rows; the combined description is announced only for the native selected row.
- E.1 adds exactly two verified hooks relative to Build E: `0x0050FD30` (Player Match Session Room) and `0x004F02B0` (Tournament Session List). Both copy four complete 5-byte `mov` instructions and were checked byte-for-byte against the supplied EXE.
- `Loading/Stand/Skip/Off` states from `0x0050EBF0` remain deliberately unmapped to the six players: native code clamps the status index to only two slots `0/1`, so there is no safe basis for assigning them to all lobby rows. `Battle/Pause` also remain pending further reverse-engineering rather than guessing.
- Added `SessionRoomReader.h`, `TournamentSelectionReader.h` and `test_build_e1_online_completion.cpp`; the E.1 test covers the 6-row Session Room cache, empty-slot clearing, exact `$PlayerName0..5` paths and the 7-row tournament selection tracker.
- Regression in this environment: 16 portable tests PASS / 0 FAIL. Five `Windows.h`-dependent tests and the final DLL build remain for `BUILD_X64.bat` / `BUILD_DLL_ONLY.bat` on Windows.

## 2.72 Build E — full Online pass — 2026-09-08

- Player Match Session List now labels the selected room fields: Host, Character, Rank, Session, Language, Connection quality and Area. NVDA receives one coherent row instead of a sequence of unlabeled values.
- Added the confirmed native Player Match Session List area/region. The current EXE builder reads `rec+0xA8`, computes `value-1`, compares it with `7` and selects one of eight `Rep_CMN_AREA_ICON%d` entries; the mod speaks `Area 1 of 8` … `Area 8 of 8`. Out-of-range values are suppressed.
- Player Match Session Room now labels the selected member fields: Player, Character, Rank, Wins, Title, Language, Connection quality and Area. The native area is read from `rec+0x44`; the game applies the same 1–8 range.
- Player Match room options now pair the native option name with the native value. The game first renders `$PanelName0..5` / `$PanelName0..2` families and writes the selected value as `$PanelValue4` or `$PanelValue2`, so the mod no longer speaks a bare `On/Off` without context.
- Tournament Session List now captures the missing user-created session name `$SessionName0..6` through the already-installed custom-name writer `0x00457DD0` (return `0x004F2E15`). Row speech combines confirmed fields: Session, Player, Elimination, Rule, Battle time, Reward and Language.
- The Tournament Session List fixed header is now semantically labeled: Screen, Mode, Sort, Value name and five sort values.
- Leaderboard `Wins/Losses` now uses bilingual mod labels instead of hard-coded English text.
- Updated Session List, Session Room/Lobby and Online Identity tests for the new labeled format. Added `test_build_e_online.cpp` and enabled it in `BUILD_X64.bat`.
- Build E adds no new hook. `Patch::Install` call sites remain 42 and `Patch::InstallRel8Jcc` remains 1, identical to Build D.2.
- `Loading/Stand/Battle/Pause` are intentionally not assigned to a specific lobby member yet, and Ranked/Tournament cursors are not inferred where reverse engineering does not provide an unambiguous selected-row link. Those fields remain pending rather than guessed.

## 2.72 Build D.2 — combat orientation and automatic side changes — 2026-09-08

- Added confirmed left/right fighter orientation without coordinate heuristics. The game's reflected `PlayerOnRightSide` function is registered with wrapper `0x0067A940`, which calls native `0x0024B650`. That function resolves a fighter through `0x00759120` and returns true exactly when `dword [fighter+0x14D4] == 1`. Resolver `0x00759120` indexes the same fighter table RVA `0x034E9970` already used by Build D.
- `Ctrl+Shift+F10` now reports the confirmed orientation in addition to distance and X/Y/Z: `1P left / 2P right` or the reverse. If the two side fields do not form a valid 0/1 pair, orientation is omitted instead of guessed.
- Added `Ctrl+Shift+F11` to toggle automatic side-change announcements. It is off by default. Enabling it reports the current orientation, then speaks only after a real side change.
- The automatic monitor runs in the existing worker thread and uses only `ReadProcessMemory`; it does not call engine functions or add a hook. A candidate orientation must remain stable for 80 ms, filtering transient states during cross-ups/loading.
- Short transitional states without a valid 0/1 pair are ignored so a cross-up is not lost. Only invalid data sustained for 500 ms resets the monitor baseline as a transition/loading state; the next valid pair establishes a fresh baseline silently.
- Added `CombatOrientationReader.h`, `test_build_d2_combat_orientation.cpp`, and a new `BUILD_X64.bat` test. The test covers 0/1 decoding, both orientations, the 80 ms debounce, transitional reset, and the F11 toggle.
- Build D.2 adds no new `Patch::Install`; hook count remains unchanged from D.1.

## 2.72 Build D.1 — DLL build workflow fix — 2026-09-08

- Fixed `BUILD_X64.bat` workflow: test `.exe` programs are created only inside `.build_tests`, executed, and removed instead of cluttering the source directory.
- The release library is now explicitly written to `bin\TekkenAccessibility.dll` and then copied to `TekkenAccessibility.dll` next to the build script.
- Added `BUILD_DLL_ONLY.bat` for compiling only the DLL without creating any test `.exe` files. DLL compiler errors are written to `BUILD_LOG.txt`.
- This change only affects the build workflow; Combat Accessibility runtime code and hook count are unchanged from Build D.

## 2.72 Build D — Combat Accessibility foundation — 2026-09-08

- Added the first confirmed real fighter-position reading during combat on `Ctrl+Shift+F10`. It reports planar distance and X/Y/Z coordinates for fighters 1P and 2P.
- The data does not come from the HUD or Scaleform element positions. Reverse engineering of the supplied EXE confirmed reflected `GetFighterOrgPos`: wrapper `0x00672D80` calls native function `0x002531E0`.
- `GetFighterOrgPos` checks the native battle context at RVA `0x034CE030`, resolves a fighter through the pointer table at RVA `0x034E9970`, then reads fields `+0xE0`, `+0xE4`, and `+0xE8`. The game's exact output transform is `X=(+E8)*0.1`, `Y=-(+E0)*0.1`, `Z=(+E4)*0.1`.
- Fighter indices 0 and 1 as the primary pair were independently confirmed by game code at `0x00252D90`, which resolves entry 0 and then entry 1 through the same `0x00759120` resolver.
- The mod does not call game internals from its worker thread. It reads the same confirmed fields with safe `ReadProcessMemory`, only when F10 is pressed. Missing context, disappearing objects, invalid pointers, NaN, or infinity produce “Combat position unavailable” instead of garbage speech.
- Distance is the 2D distance between native X/Y coordinates. No unit, near/far label, screen-side label, wall label, or posture is assigned yet because those semantics are not sufficiently confirmed.
- Added `CombatPositionReader.h`, `test_build_d_combat_position.cpp`, and the Build D test to `BUILD_X64.bat`. The test covers the axis transform, a 3-4-5 distance, PL/EN formatting, and NaN rejection.
- Build D adds no new hooks. This is the measurement foundation for later automatic orientation, walls, and fighter-state accessibility.

## 2.72 Build C — online, colors and QTE — 2026-09-08

- Player Match Session List now announces the selected room's native six-level connection indicator. In the existing row builder the record stores `0..5` at `rec+0x28`; the game maps this to `PingIcon_00..05`. The mod avoids invented quality labels and says `Connection quality X of 6`.
- Player Match Session Room now announces the same six-level indicator for the selected player. Native builder `0x00528000` reads `rec+0x00`, checks `<=5`, and passes `raw+1` to the icon renderer. This was added to the already existing row hook.
- Customization Palette now uses the confirmed asset layout: exactly 72 `Rep_EXSKIN_COLOR_01..72` swatches in an 8×9 grid and 15 `Rep_CUSTOMCOLOR_01..15` saved colors. Speech now includes e.g. `Swatch 27 of 72, column 3, row 4` and `Saved color 15 of 15`; out-of-range values are ignored.
- RGB/HSV color names are still not invented. Gradient navigation continues to announce the real coordinates supplied by native event 45 until the actual color-value structure is confirmed.
- QTE state `Right` is announced as `Right direction` instead of the ambiguous `Right`. `Success`/`Failed` also clear the previous QTE movie object to prevent state leaking between sequences. The mod does not guess whether the icon is D-pad or analog stick.
- Added `test_build_c_online_customization.cpp` to `BUILD_X64.bat`, covering connection levels 1/6 and 6/6, invalid range rejection, QTE Right, swatch 72/72, and saved color 15/15.
- Build C adds no new hooks; it reuses the existing Player Match row builders, Character Customize dispatcher, and QTE path.

## 2.72 Build B — core UI and popups — 2026-09-08

- Fixed popup lifecycle deduplication: identical `SW_UI_Dialog_InputText`, `SW_UI_Dialog_IconHelp`, and small `SW_UI_Dialog_Unlock` instances are announced again after closing and reopening instead of being suppressed by the previous dialog cache.
- EULA/License now reads the final game-built text directly from native `$license` (setter `0x00458250`, return `0x0049B772`) instead of rebuilding it again in the speech layer. Primary `$t2` starts a fresh lifecycle on every entry, visual duplicate `$t2g` stays suppressed, and the button block cache resets on a new `$b1`.
- Removed possible duplicate initial speech in `SW_UI_Dialog_Steam`: the initial `$message` is owned by StandardDialog and spoken once, while the separate native setter still handles later text refreshes.
- Button Mapping Panel25..28 can no longer leak technical `$Operation1..4` tokens. If renderer cache is not ready, the mod resolves the EXE-confirmed native keys `opt_menu_203..206`; if localization is unavailable, no internal key is spoken.
- Confirmed Button Mapping/Controller Setup localization keys are no longer converted to raw `opt_menu_*`/`story_menu_*` strings when the native resolver is temporarily unavailable; internal identifiers are not spoken.
- Graphics Options, Game Options, and Sound Options now reset selection/value dedupe when the native `self` object changes, so a newly created screen with the same row/value is not mistaken for the previous instance.
- Added `test_build_b_ui.cpp` to `BUILD_X64.bat`, covering popup reopen, Steam dedupe, EULA/glow, Sound `0–10`/`0–1`, Options object reset, Button Mapping 25–28, and Controller Setup P1/P2. Build B model test: PASS.
- `BUILD_B_AUDIT.txt` confirms the shared-renderer returns and the four Button Mapping keys against the current EXE. No new hook was added.

## 2.72 Build A — hook stability + Controller Setup — 2026-09-08

- Fixed a critical StandardDialog trampoline bug at RVA `0x0049F290`. The stolen prologue contains short `JE +0x2B`; raw copying made the branch target relative to the trampoline. New `InstallRel8Jcc` preserves the condition with an inverted Jcc and a 14-byte absolute jump to native target `0x14049F2C4`.
- Added `Patch::Uninstall` and transactional rollback for multi-hook modules. If a later hook fails, earlier hooks in the same feature are restored instead of leaving a partially installed feature. This covers Practice, Standard Dialog, Character Customize Selected Item, Player Match Session List and Player Match Session Room.
- Added shared `PatchRelocation.h` and `test_hook_relocation.cpp`; `BUILD_X64.bat` runs it before the existing tests. The test verifies `JE 0x14049F297 + 0x2B -> 0x14049F2C4`, JE/JNE inversion and the 44-byte trampoline size.
- Controller Setup now uses the existing native `chasel_msg_034` / `chasel_msg_035` keys to announce the correct player/column before the selected operation. Both keys are present in the supplied EXE; no new hook or invented label was added.
- Sound Options Hotfix 2 remains included unchanged: four sliders `0–10`, one `0–1` toggle, with counts read from game table `0x02859640`.
- A fresh scan of all 45 stolen prologue regions confirmed that, besides StandardDialog, the only conditional branch in stolen bytes is the `JE rel32` in Graphics Options at `0x004BDFF0`; its 32-bit displacement is already relocated correctly by the existing relocator.
- Audit correction: current V2.72 already assembles the License/EULA body from seven confirmed `license_msg_*` keys; the earlier statement that only the title/buttons were read was outdated.

## 2.72 Sound Options hotfix 2 — 2026-09-07

- Fixed the range of several Sound Options sliders: the `7` entries in table `0x02858C90` are reset/default values, not maxima.
- Native input routine `0x0052D0B0` uses the value-count table at `0x02859640`: `11, 11, 11, 11, 2`. This means `0–10` for all four volume sliders and `0–1` for the toggle.
- The reader now obtains the value count directly from that game table, so values `8`, `9`, and `10` are no longer discarded on rows whose default is `7`. The same hook is retained; no new hook was added.

## 2.72 Sound Options hotfix — 2026-09-07

- Fixed the completely silent Sound Options screen. The previous code read the wrong `self+0xA8` / `self+0xB0` fields and hooked the one-shot renderer at `0x0052C990`.
- The supplied EXE confirms the real Sound Options layout: selected row at `self+0x44`, row 0–4 values at `self+0x48..0x58`, and six native label keys at `0x028595F8`.
- The existing single Sound Options hook is moved to the native input routine at `0x0052D0B0`, so NVDA can react to both cursor and value changes. The hook count is not increased.
- Rows 0–3 announce their native stepped value; row 4 resolves the native two-state text through `opt_menu_46` / `opt_menu_81`; row 5 remains an action with no invented value.
- Static validation: the `0x0052D0B0` prologue matches the supplied `TekkenGame-Win64-Shipping.exe`; instructions using `+0x44`, `+0x48..+0x58`, the six-label table, and the initially misinterpreted 10/7/7/7/1 reset/default values were confirmed; Hotfix 2 corrects the actual ranges to 0–10/0–1. Live testing in the game with NVDA is still required.

## 2.72 test — 2026-09-07

Fixes for confirmed issues from the 2.70 audit:
- Treasure Battle: collect all box colors before the native Start event and announce them together. Consume the cache after each result so identical boxes are announced again on the next result.
- Ranks: capture the displayed player's rank after native gauge initialization, using the actual UI movie. Reset on initialization and close; apply native previous/next rank bounds. One hook added (45 total).
- Speech: append health, HUD and rank events after the primary announcement instead of dropping them when primary speech interrupts. Keep list and description updates pending while a higher-priority request is handled.
- Startup: a failed module no longer stops the shared speech worker. The startup announcement lists failed modules and is also sent to OutputDebugString.
- Remaining generated Polish speech is translated to English and partly shortened. Game text and player names keep their original language. The palette still announces coordinates rather than color names/RGB.
Validation: 14 test suites, DLL compilation, 45 hook prologues and additional native instruction/path checks. Full game accessibility and live NVDA speech ordering remain unverified.

## 2.70 test — 2026-09-07

Select Side: announces Left/Right on entry and cursor changes using native screen events. Removed an unrelated dialog hook, its delayed post-exit speech and incorrect Playing Stats announcements for static side labels. Reopening announces the current side. Reuses two shared hooks; total hook count drops from 45 to 44. Logic tests and EXE checks do not replace live NVDA testing. Full Treasure Battle accessibility is not verified.

## 2.69 test — 2026-09-07

Shortened session and lobby speech: player name, character, rank without field labels. Removed the Polish language label and switched room-list messages to English. Standalone rank context uses short English labels: Current, Previous, Next, Left, Right. Speech grouping and queuing are preserved. Game-provided text retains the game language. This change covers these readers, not a complete language audit of older modules.

## 2.68 test — 2026-09-07

Session search results and room player lists announce the player name before the character and rank. Portrait and rank identifiers come from the records used by the game. A list portrait does not necessarily identify the final character selected for a match. Current/previous/next rank and left/right HUD rank announcements are grouped after 350 ms without changes and appended without interrupting names. Synthesizer speed follows the user settings. Character Select obtains the character identifier from the native game function for the current cursor position. Ten test suites, compilation, 45 hook prologues and 12 EXE locations: PASS. Static verification does not confirm all screens or character selection options; live game testing with NVDA remains necessary.

## 2.67 test — 2026-09-07

Standard confirmation dialogs: an explicit message assignment reads the question even when its text repeats. The first selected answer is queued after the question; subsequent selection changes interrupt prior speech. Changing the dialog owner resets answer deduplication. Production-code tests cover repeated questions, speech order, navigation and index bounds.

## 2.66 test — 2026-09-07

Graphics: prevent duplicate selection speech after entering a page. The page title is separate from the cached row text. Changed values, distinct rows with identical labels and returning from submenus remain announced. Added behavior tests.

## 2.65 test — 2026-09-07

Sound settings: the final entry (index 5) no longer reads a memory value as a slider. The native UI sets its OptionValue_mc state to None (0x52CAA8). Its label remains spoken. Full graphics, game and controller settings flows have not been tested.

## 2.64 test — 2026-09-07

Move list: reset selection deduplication on close and when the UI movie changes. The native movie is read at self+0x180; the End animation at return address 0x48DF9E resets the cache. This addresses suppressed speech when reopening the same move. No new button-symbol translations were added.

## 2.63 test — 2026-09-07

Practice: changing menu page or row is no longer suppressed solely because its text matches the previous selection. Unchanged refreshes of the same row remain silent. This review does not establish full Practice or move-list symbol accessibility.

## 2.62 test — 2026-09-07

Player Match lobby: cache all 10 player rows, announce selection changes and combine name, wins, title and language. Rebuilding the list clears stale data. Readiness and match start have not been verified in a live lobby.

## 2.61 test — 2026-09-07

Create Session: value refreshes cache data without announcing unfocused fields. The selected setting and its final value are announced after native input processing. Added entry-count validation and tests for navigation, dependent field updates and the create button.

## 2.60 test — 2026-09-07

Customization: added Copy and Delete announcements when selecting slot popup options. Mapping verified against the current GFX asset and native events 15/16. Live NVDA verification is required.

## 2.59 test — 2026-09-07

Removed the room-number prefix. Reduced the settling delay from 250 to 40 ms (plus worker polling). New selection speech interrupts the previous utterance so rapid navigation does not queue stale room announcements.

## 2.58 test — 2026-09-07

- Search Sessions now caches names, hosts and languages for all 11 rows on the current results page, including rows populated before selection.
- Selected room fields are combined after a short settling delay. Revisiting a room reads it again.
- Added the separate native rendering path for user-entered room names.
- Rebuilding a page clears stale rows; unchanged refreshes remain silent.
- Ctrl+Shift+F9 reads all captured rooms on the current page. Numbers identify display rows, not absolute search-result indices.
- Five logic test suites pass; all 44 hook prologues match the EXE. Live NVDA verification is still required.
- This fixes text fields in search results. Connection icons, entry restrictions and complete room details have not been fully verified.

# Tekken Accessibility — changelog

Test versions 2.54–2.57, prepared on September 6, 2026. This history covers changes made in this project; it does not reconstruct earlier releases.

## 2.57 test

- Added round timer reading and automatic announcements at 30, 10, 5, and 0 seconds. The special timer value is described as no countdown; older data includes its age.
- Added Rage activation and ending announcements for the left and right sides of the HUD.
- Added announcements identifying the number and HUD side of an activated round win marker.
- Added an announcement when entering costume preset copy mode and a prefix identifying the selected copy destination in Customization.
- Added Ctrl+Shift+F7 to read the timer and Rage, and Ctrl+Shift+F8 to toggle automatic timer, Rage, and round announcements.
- Validation: four behavioral test suites passed, the x64 DLL compiled, and 42 hook prologues were checked against the game executable. Call sites, numeric argument formats, and copy events were also checked.

## 2.56 test

- Restored access to previously silenced descriptions, help, rules, and controller warnings, including 38 additional message routes.
- Added description collection and reading after a short delay, without interrupting the selected option name. Long descriptions can be read on demand or browsed in fragments.
- Preserved spoken identifiers from `<#...>` icon tokens instead of removing them along with formatting tags.
- Added QTE reading for the native Y, X, RB, and right-direction icons, plus success and failure announcements. An unknown icon does not repeat a stale command.
- Added percentage readings for both HUD health bars and threshold announcements at 50%, 25%, 10%, and 0%. Improved removal of outdated warnings after healing and round resets.
- Added spoken palette navigation: swatch positions, gradient coordinates, saved color positions, and the coloring area number. Swatches and the gradient retain separate coordinates.
- Added the costume preset number to its name to distinguish identically named presets.
- Added Ctrl+Shift+F1–F6 shortcuts, listed below.
- Validation: three behavioral test suites passed, the x64 DLL compiled, and 40 hook prologues were checked against the executable. QTE calls, health arguments, and palette events were also checked.

## 2.55 test

- Extended the search settings fix to Ranked Match: the selected option, its value, and the start button.
- Improved Story reading: selected chapters and character episodes, page and tab changes, completion status, difficulty descriptions, and prologue and story panel text.
- Combined the chapter number and title into one announcement.
- Improved Customization: reading the focused character instead of the entire list, and combining the selected item name with its price, count, and recognized status.
- Extended item reading in Player Customization.
- Validation: behavioral tests and compilation passed; 39 hooks and 30 additional call sites were checked against the executable. The investigation extracted and verified 26,467 UI resource entries covering 24,853 unique paths. This does not mean every screen was tested in the game.

## 2.54 test

- Fixed Quick Match and Search Session settings reading by using the correct native online settings screen.
- Added reading of the selected option, its value, and the start button, including value changes and re-entering the menu.
- Reduced repeated announcements and cross-mode data mixing. Removed the incorrect results-list hook previously used for search settings.
- Validation: behavioral tests, compilation, and checks of the relevant executable addresses passed.

## Shortcuts in version 2.72 Build D.2

These work while the game window is active. All use Ctrl+Shift as modifiers.

- F1: read collected descriptions for the UI context.
- F2 / F3: next / previous description fragment.
- F4: toggle automatic descriptions.
- F5: read both health bars.
- F6: toggle health announcements.
- F7: read the timer and Rage.
- F8: toggle timer, Rage, and round marker announcements.
- F9: read all captured session-result rows on the current page.
- F10: read distance, both fighters' X/Y/Z, and their confirmed left/right orientation when available.
- F11: toggle automatic combat side-change announcements.

Toggle settings last until the game closes. Existing automatic announcements remain enabled by default; F11 automatic side-change announcements are off by default.

## Limitations

These are test builds. Code and file checks do not replace full in-game testing with NVDA. Left and right refer to HUD positions, not automatically to the player and opponent. QTE announcements use native icon names without translating them to individual keyboard bindings.

Complete popup labels, actual RGB values and color names, remaining HUD elements, and cinematic audio description are not finished. Reading a palette position is not color recognition. The plugin has not yet been confirmed to provide full accessibility throughout the game.
